---
title: Capacities Role Explorer
type: Page
tags: everything-ai, import-directory
---

# Capacities Role Explorer

Use this directory to find a role after importing Pack 2.

| Family | Role |
|---|---|
| Experience Content and Automation | [[AI Automation Specialist]] |
| Experience Content and Automation | [[AI Content Designer]] |
| Experience Content and Automation | [[AI UX Researcher]] |
| Experience Content and Automation | [[AI UX and Product Designer]] |
| Experience Content and Automation | [[Conversation Designer]] |
| Experience Content and Automation | [[Prompt and Context Engineer]] |
| Generative Creative and Education | [[AI Audio and Music Specialist]] |
| Generative Creative and Education | [[AI Image and Graphic Creator]] |
| Generative Creative and Education | [[AI Trainer and Educator]] |
| Generative Creative and Education | [[AI Video Producer]] |
| Generative Creative and Education | [[Generative AI Creative Director]] |
| Governance Risk Policy and Ethics | [[AI Auditor and Assurance Specialist]] |
| Governance Risk Policy and Ethics | [[AI Compliance and Privacy Specialist]] |
| Governance Risk Policy and Ethics | [[AI Ethics Researcher]] |
| Governance Risk Policy and Ethics | [[AI Governance Specialist]] |
| Governance Risk Policy and Ethics | [[AI Policy Analyst]] |
| Governance Risk Policy and Ethics | [[AI Trust and Safety Operations Specialist]] |
| Governance Risk Policy and Ethics | [[Model Risk Manager]] |
| Governance Risk Policy and Ethics | [[Responsible AI Specialist]] |
| Human Data and Knowledge Operations | [[AI Data Operations Manager]] |
| Human Data and Knowledge Operations | [[AI Talent and Recruiting Specialist]] |
| Human Data and Knowledge Operations | [[Data Annotator and AI Rater]] |
| Human Data and Knowledge Operations | [[Human-Feedback Specialist]] |
| Human Data and Knowledge Operations | [[Knowledge Manager]] |
| Human Data and Knowledge Operations | [[Taxonomist and Ontology Specialist]] |
| Product Program and Business | [[AI Business Analyst]] |
| Product Program and Business | [[AI Product Manager]] |
| Product Program and Business | [[AI Program Manager]] |
| Product Program and Business | [[AI Strategy Consultant]] |
| Product Program and Business | [[AI Transformation Lead]] |
| Product Program and Business | [[Chief AI Officer and Head of AI]] |
| Product Program and Business | [[Technical AI Product Manager]] |
| Solutions Go-to-Market and Developer Relations | [[AI Customer Success Manager]] |
| Solutions Go-to-Market and Developer Relations | [[AI Developer Relations and Advocate]] |
| Solutions Go-to-Market and Developer Relations | [[AI Enterprise Account Executive]] |
| Solutions Go-to-Market and Developer Relations | [[AI Product Marketing Manager]] |
| Solutions Go-to-Market and Developer Relations | [[AI Sales Engineer]] |
| Solutions Go-to-Market and Developer Relations | [[AI Solutions Architect]] |
| Solutions Go-to-Market and Developer Relations | [[AI Strategic Partnerships Manager]] |
| Solutions Go-to-Market and Developer Relations | [[AI Technical Support and User Operations Specialist]] |
| Technical AI Safety and Security | [[AI Red Teamer]] |
| Technical AI Safety and Security | [[AI Safety and Alignment Researcher]] |
| Technical AI Safety and Security | [[AI Security Engineer]] |
| Technical Data Platform and MLOps | [[AI Platform Engineer]] |
| Technical Data Platform and MLOps | [[Data Scientist - AI ML]] |
| Technical Data Platform and MLOps | [[ML Data Engineer]] |
| Technical Data Platform and MLOps | [[MLOps Engineer]] |
| Technical Evaluation Knowledge and Data | [[AI Evaluation Engineer]] |
| Technical Evaluation Knowledge and Data | [[RAG and Knowledge Engineer]] |
| Technical Evaluation Knowledge and Data | [[Synthetic Data Engineer]] |
| Technical Infrastructure and Performance | [[AI Hardware and Accelerator Engineer]] |
| Technical Infrastructure and Performance | [[Inference and Performance Engineer]] |
| Technical Modality Engineering | [[Computer Vision Engineer]] |
| Technical Modality Engineering | [[NLP Engineer]] |
| Technical Modality Engineering | [[Robotics and Embodied AI Engineer]] |
| Technical Modality Engineering | [[Speech AI Engineer]] |
| Technical Model and Application Engineering | [[AI Engineer]] |
| Technical Model and Application Engineering | [[Agentic AI Engineer]] |
| Technical Model and Application Engineering | [[LLM Engineer]] |
| Technical Model and Application Engineering | [[ML Engineer]] |
| Technical Research and Applied Science | [[AI ML Research Scientist]] |
| Technical Research and Applied Science | [[Applied Scientist]] |
| Technical Research and Applied Science | [[Research Engineer]] |
