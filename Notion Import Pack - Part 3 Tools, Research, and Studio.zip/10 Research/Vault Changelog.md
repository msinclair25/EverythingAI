# Vault Changelog

> **Metadata:** Scope: United States · Status: active · Verified: 2026-08-25 · Review by: 2026-11-25 · Type: changelog
> **Tags:** ai-careers, changelog

## 2026-10-13 — Research refresh and applied technical depth

- Added [October 2026 Research Refresh](<October%202026%20Research%20Refresh.md>) with checked primary sources, cutoff handling, corrections, and explicit review limits.
- Added nine notes spanning model/service lifecycle, cloud identity/operations, MCP contract testing, two worked cases, all-technical-role practice, U.S. career/governance context, and a change-impact template.
- Added differentiated exercises to all 23 technical profiles and current career/governance entry points to all 40 nontechnical profiles; older verification dates remain intact.
- Corrected the OWASP LLM taxonomy to the canonical 2025 edition, including risk IDs and flashcards; Agentic 2026 remains a separate framework.
- Updated the Home and GitHub README, kept repository artwork, and corrected stale BLS and video API pointers.
- Added a read-only structural validator for frontmatter, code fences, note/local-file links, and reproducible inventory counts. This does not verify external URLs, claims, or visual rendering.
- Fixed the Notion export's hardcoded date and removed the promise that separate imports automatically repair cross-part links. Rebuilt the full and split packs.
- Inventory: 235 vault notes, 63 roles, 12 studio cases, 1,052 flashcard lines, 145 notes with explicit checks, and 148 Mermaid diagrams. See the validator for counting definitions.

## 2026-08-25 — Public repository artwork

- Added `assets/everything-ai-readme-hero.png` as the README hero image.
- Added `assets/everything-ai-github-social-preview.jpg` at 1280×640 and under 1 MB for GitHub's social-preview uploader.
- Kept repository-only artwork out of the Notion export; the vault's three teaching infographics remain the imported visual assets.

## 2026-08-25 — Diagram fit-to-viewport pass

- Updated `everything-ai.css` behavior for Mermaid blocks so diagrams use the available reading width, cap their height to the viewport, and keep overflow only for genuinely dense diagrams.
- Added responsive image framing for visual assets and a `diagram-focus` layout to the three infographic notes so they are legible without oversized horizontal spill.
- Regenerated the Notion import packs after the visual changes; the Obsidian vault remains canonical.

## 2026-08-25 — Notion bridge and import packs

- Added [Notion Import Guide](<../Notion%20Import%20Guide.md>) with the source-of-truth/sync model, import workflow, conversion rules, and official Notion limitations.
- Added scripts/export_notion.rb, which generates a full ZIP, three smaller import-safe ZIPs, static Role Explorer/Source Review pages, a Canvas replacement, copied image assets, and a Notion Note Catalog CSV.
- Preserved Obsidian as canonical; the bridge is a one-way derivative and does not overwrite vault notes.

## 2026-08-25 — Visual, language, sizing, spacing, and flow pass

- Tuned the everything-ai CSS snippet for a readable content width, editor/reader parity, heading rhythm, paragraph/list measure, calmer table headers, sticky table context, callout accents, responsive table sizing, and more consistent embed spacing.
- Added a quick-route table and recommended sequence to [AI DevOps and Cloud Engineering — 2026-08-24](<../05%20Tool%20Atlas/AI%20DevOps%20and%20Cloud%20Engineering%20%E2%80%94%202026-08-24.md>).
- Added a visible infrastructure/DevOps learning route to [Everything AI - Home](<../00%20Start%20Here/Everything%20AI%20-%20Home.md>) and updated the assessment entry points.
- Static QA remains clean: 225 Markdown notes, frontmatter parses, and wikilinks resolve. Live Obsidian/desktop rendering could not be captured because the local Obsidian/Orca runtime was not reachable.

## 2026-08-24 — Current tools, practices, and technical-role evidence

- Added [AI Tools and Practices Update — 2026-08-24](<AI%20Tools%20and%20Practices%20Update%20%E2%80%94%202026-08-24.md>) with current primary-source signals, eight cross-role practices, a role technique map, a knowledge check, flashcards, study drills, and four project briefs.
- Added [Tool Atlas — 2026-08-24 Update](<../05%20Tool%20Atlas/Tool%20Atlas%20%E2%80%94%202026-08-24%20Update.md>) with free/open and managed paths, current tool decisions, a reusable tool card, a 90-minute proof-of-concept protocol, and a scored selection rubric.
- Added a dated practice overlay to all 23 notes in the technical role folder, so each role profile now points from its work anatomy to current evidence expectations.
- Updated [Everything AI - Home](<../00%20Start%20Here/Everything%20AI%20-%20Home.md>) to release 2 with an August 24, 2026 research cutoff while retaining the August 12 baseline as a dated release snapshot.
- Sources checked: MCP roadmap/authorization, OpenAI Agents SDK tracing/testing, Gemini Interactions/caching, Microsoft Foundry evaluation/observability, vLLM, OpenTelemetry GenAI semantic conventions, and NIST TEVV.
- Added [Microsoft Azure DevOps and Foundry](<../05%20Tool%20Atlas/Microsoft%20Azure%20DevOps%20and%20Foundry.md>) with current Azure DevOps MCP, WIF service connections, environments, Foundry hosted agents, Toolboxes, networking, evaluation gates, azd command-surface caveat, traces, free-first paths, and role study sequence.
- Added [Case - Azure DevOps Foundry Release Gate](<../12%20Technical%20Studio/Case%20-%20Azure%20DevOps%20Foundry%20Release%20Gate.md>) and indexed it in [Technical Studio](<../12%20Technical%20Studio/Technical%20Studio.md>) as a worked release decision with constructed thresholds, failure injects, interview drill, quiz, flashcards, and a capstone extension.
- Added [Azure DevOps Foundry Release Dossier Template](<../09%20Templates/Azure%20DevOps%20Foundry%20Release%20Dossier%20Template.md>) so learners can turn the case into a reusable release, approval, and rollback evidence record.
- Added [Cloudflare and Vercel AI](<../05%20Tool%20Atlas/Cloudflare%20and%20Vercel%20AI.md>) with current edge/web AI platform research: Workers AI, AI Gateway, Agents, AI Search, Workflows, AI SDK 7, WorkflowAgent, Sandbox, Connect, Fluid Compute, free/paid paths, role mapping, interview prep, quiz, flashcards, and projects.
- Added [Case - Edge AI Platform Choice](<../12%20Technical%20Studio/Case%20-%20Edge%20AI%20Platform%20Choice.md>) and indexed it in [Technical Studio](<../12%20Technical%20Studio/Technical%20Studio.md>) as a worked multi-tenant platform decision with constructed budgets, recovery tests, sandbox controls, fallback evaluation, and cross-vendor trace requirements.
- Added [AI Expansion Atlas — 2026-08-24](<../05%20Tool%20Atlas/AI%20Expansion%20Atlas%20%E2%80%94%202026-08-24.md>) covering twelve next-wave AI domains: agent interoperability/identity, AI SRE, on-device/private AI, provenance/AIBOM, reasoning compute, document intelligence, privacy, infrastructure sustainability, coding agents, physical AI, AI for science, and realtime interaction.
- Added [OWASP and AI Security — 2026](<../05%20Tool%20Atlas/OWASP%20and%20AI%20Security%20%E2%80%94%202026.md>) with the current LLM and Agentic Top 10 boundaries, GenAI Data Security, secure MCP, AIBOM, COMPASS, governance, control stack, quizzes, flashcards, interview prompts, and safe portfolio projects.
- Added [Case - OWASP Agentic Security Review](<../12%20Technical%20Studio/Case%20-%20OWASP%20Agentic%20Security%20Review.md>) and indexed it in [Technical Studio](<../12%20Technical%20Studio/Technical%20Studio.md>) as a ship/stop assessment for injection, identity, tools, memory, MCP, output handling, denial-of-wallet, cascading failure, recovery, and release gates.
- Added [MCP Deep Dive — 2026-08-24](<../05%20Tool%20Atlas/MCP%20Deep%20Dive%20%E2%80%94%202026-08-24.md>) as a dedicated protocol-to-production study layer covering the 2026 release line, legacy migration, primitives, transports, OAuth, security threats, conformance, registry provenance, operations, interviews, flashcards, and projects.
- Added [AI DevOps and Cloud Engineering — 2026-08-24](<../05%20Tool%20Atlas/AI%20DevOps%20and%20Cloud%20Engineering%20%E2%80%94%202026-08-24.md>) as the AI × DevOps/cloud engineering study layer: AI for DevOps, DevOps for AI, cloud comparison, IaC, CI/CD, OIDC/WIF, evaluation, Kubernetes, OTel/MCP observability, supply chain, FinOps, role practice, projects, interview prep, quiz, and flashcards.
- Updated [Security and Red Teaming](<../05%20Tool%20Atlas/Security%20and%20Red%20Teaming.md>), [AI Tool Atlas](<../05%20Tool%20Atlas/AI%20Tool%20Atlas.md>), four technical role overlays, dated research updates, and source registries with the expansion and OWASP layers.

## 2026-08-12 — Use layer: syllabus, exam, overlays, visuals

- Frozen the concept spine at 16 ([Concept Spine Freeze](<../12%20Technical%20Studio/Concept%20Spine%20Freeze.md>)).
- Added [Builder 4-Week Syllabus](<../00%20Start%20Here/Builder%204-Week%20Syllabus.md>), [Technical Cumulative Check](<../06%20Assessment%20Center/Technical%20Cumulative%20Check.md>) (20 items, pass 16/20), [Case - Vision Field Slice](<../12%20Technical%20Studio/Case%20-%20Vision%20Field%20Slice.md>).
- Thickened [Healthcare and Life Sciences AI](<../08%20Industry%20Overlays/Healthcare%20and%20Life%20Sciences%20AI.md>), [Financial Services and Insurance AI](<../08%20Industry%20Overlays/Financial%20Services%20and%20Insurance%20AI.md>), [US Government and Public Sector AI](<../08%20Industry%20Overlays/US%20Government%20and%20Public%20Sector%20AI.md>) to teaching length.
- Polish: [How an AI Assistant Should Use This Vault](<../00%20Start%20Here/How%20an%20AI%20Assistant%20Should%20Use%20This%20Vault.md>); renumbered [Flashcard Index](<../06%20Assessment%20Center/Flashcard%20Index.md>).
- Visuals: [Visual Maps Hub](<../11%20Visual%20Maps/Visual%20Maps%20Hub.md>) plus three Grok Imagine 2K PNGs (builder path, spine, RAG autopsy) and HTML/SVG fallbacks.

## 2026-08-12 — Sampling, calibration, quantization, vision

- Added [Sampling and Decoding](<../12%20Technical%20Studio/Sampling%20and%20Decoding.md>), [Calibration](<../12%20Technical%20Studio/Calibration.md>), [Quantization](<../12%20Technical%20Studio/Quantization.md>), [Vision and Multimodal Systems](<../12%20Technical%20Studio/Vision%20and%20Multimodal%20Systems.md>).
- Linked [Computer Vision Engineer](<../04%20Role%20Tracks/Technical/Computer%20Vision%20Engineer.md>), [Inference and Performance Engineer](<../04%20Role%20Tracks/Technical/Inference%20and%20Performance%20Engineer.md>), [LLM Engineer](<../04%20Role%20Tracks/Technical/LLM%20Engineer.md>); interview drill 10; glossary terms (temperature, top-p, IoU, mAP, VLM, ECE, PTQ).

## 2026-08-12 — Concept spine 9–12 + split case

- Added [Embeddings and Similarity](<../12%20Technical%20Studio/Embeddings%20and%20Similarity.md>), [The Training Loop](<../12%20Technical%20Studio/The%20Training%20Loop.md>), [The Agent Loop](<../12%20Technical%20Studio/The%20Agent%20Loop.md>), [Untrusted Context and Injection](<../12%20Technical%20Studio/Untrusted%20Context%20and%20Injection.md>).
- Added [Case - Split Integrity](<../12%20Technical%20Studio/Case%20-%20Split%20Integrity.md>) (honest customer/time split vs a dirty 0.94).
- Added interview drill 9; linked [ML Engineer](<../04%20Role%20Tracks/Technical/ML%20Engineer.md>); expanded [AI Glossary](<../AI%20Glossary.md>).

## 2026-08-12 — Technical concept spine

- Added [Technical Skills Hub](<../12%20Technical%20Studio/Technical%20Skills%20Hub.md>) and eight concept notes that teach the idea, why it exists, the jargon, and a worked teaching example: tokens/cost, leakage, metrics, attention/KV, context engineering, contracts, retrieval quality, adaptation methods.
- Expanded [AI Glossary](<../AI%20Glossary.md>) with the same terms, linked back to the concept notes.
- Builder path is now: foundations → concept spine → two studio cases → role.

## 2026-08-12 — Technical Studio (practice layer)

- Added `12 Technical Studio`: study method, five worked decision cases, eight interview drills, and a case template.
- Cases cover adaptation choice, evaluation gates, agent permissions, serving capacity, and retrieval failure analysis. All numbers are labeled teaching envelopes.
- Wired the studio into Home, How to Use, Learning Path Builder (Layer 2b for builders), Technical AI Careers, Core Skills Hub, Assessment Center, interview hub, and flashcard/quiz indexes.
- Did not add prescriptive labs. Code appears only as inspectable artifacts.

## 2026-08-12 — Release 1

- Created native Obsidian navigation, visual career map, Bases explorers, templates, and CSS.
- Established an August 12, 2026 research cutoff, U.S. scope, source policy, registry, and review queue.
- Added universal beginner-to-advanced AI foundations with quizzes and flashcards.
- Added role bridge skills, career taxonomy/title crosswalk, role profiles, tool atlas, interviews, project suggestions, and industry overlays.
- Added current federal landmarks EO 14365, EO 14409, and NSPM-11 with actor/scope caveats; distinguished policy instruments, recommendations, and enacted law.
- Expanded to 63 full role tracks, including trust and safety operations, enterprise sales, product marketing, strategic partnerships, technical support/user operations, and CAIO/Head of AI feeder paths.
- Release inventory: 176 Markdown notes, 620 flashcards, 98 quiz/knowledge-check notes, 117 Mermaid diagrams, one Canvas, and two Bases.
- Normalized career-role metadata for Bases, replaced a low-information Canvas embed with an interactive link, and cleaned Mermaid labels for native Obsidian rendering.
- Labeled volatile policy, tools, prices, agents, and evaluation material for recurring review.

## Update entry template

### YYYY-MM-DD — topic

- Changed:
- Reason/source:
- Notes affected:
- Next review:
