# Visual Maps Hub

> **Metadata:** Scope: United States · Status: current · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: hub
> **Tags:** ai-careers, visual-map, hub

Pictures for the technical path. They are teaching graphics, not evidence.

> **Easier diagram reading**
> Mermaid diagrams now fit the available note width and cap their height to the reading viewport. Dense diagrams keep an internal scroll only when necessary. Open the three infographic notes directly for a wider, screen-safe focus layout.

## Infographics (HTML)

- [Builder Path Infographic](<Builder%20Path%20Infographic.md>) — four-week sequence
- [Concept Spine Infographic](<Concept%20Spine%20Infographic.md>) — frozen 16 questions
- [RAG Autopsy Infographic](<RAG%20Autopsy%20Infographic.md>) — packing vs authority fail

Open the `.html` files in a browser for the full layout.

## Other maps

- Interactive career landscape
- [Free-First Tool Paths](<Free-First%20Tool%20Paths.md>)
- [AI System Lifecycle Map](<../03%20Career%20Map/AI%20System%20Lifecycle%20Map.md>)

## Style

Dark, monospace, vault-native. New graphics go in `11 Visual Maps/` and get a markdown wrapper so they wikilink.
