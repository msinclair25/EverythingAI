# Image and Design

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: published · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: tool-category
> **Tags:** atlas/tools, ai/image, ai/design

> **October 13, 2026 update**
> Model and product names do not guarantee endpoint availability. Use [Model and Agent Lifecycle Management](<Model%20and%20Agent%20Lifecycle%20Management.md>) and current provider lifecycle tables before planning a paid workflow.

Image tools cover ideation, generation, editing, layout, compositing, typography, brand systems, and production export. Judge the whole workflow: controllability and editability often matter more than the first generated image.

## Representative comparison

| Tool | Access posture | Best fit | Watch closely | Official |
|---|---|---|---|---|
| ComfyUI | GPL-3.0 open source; local/cloud compute and third-party models may cost | Node-based, reproducible local image/video pipelines | Workflow complexity, custom-node supply chain, model licenses | [GitHub](https://github.com/comfyanonymous/ComfyUI) · [docs](https://docs.comfy.org/) |
| Stable Diffusion models | Downloadable weights under model-specific Stability licenses; hosting/enterprise options vary | Local experimentation and customizable generation | Each model/license differs; hardware and safety responsibility | [models](https://stability.ai/stable-image) · [license](https://stability.ai/license) |
| Adobe Firefly | Limited free generative credits plus paid plans/enterprise | Adobe creative workflow, editing, brand production | Credit consumption, model choice, output/indemnity terms by plan | [plans](https://www.adobe.com/products/firefly/plans.html) · [FAQ](https://helpx.adobe.com/firefly/web/get-started/learn-the-basics/adobe-firefly-faq.html) |
| Canva Magic Studio | Canva Free access with limits plus paid/enterprise plans | Fast social, presentation, and template-based design | AI usage limits, asset licenses, brand/admin needs | [pricing](https://www.canva.com/pricing/) · [Magic Studio](https://www.canva.com/magic-studio/) |
| Midjourney | Paid subscriptions; trials/promotions only when officially offered | High-aesthetic ideation and image/video exploration | Public/private generation settings, rights, GPU/credit limits | [plans](https://docs.midjourney.com/hc/en-us/articles/27870484040333-Comparing-Midjourney-Plans) · [terms](https://docs.midjourney.com/hc/en-us/articles/32083055291277-Terms-of-Service) |
| Ideogram | Free limited plan plus paid plans | Text rendering, posters, brand/graphic ideation | Credit limits, privacy and rights by plan | [pricing](https://ideogram.ai/pricing) · [terms](https://ideogram.ai/tos) |
| OpenAI image generation | Paid API usage; ChatGPT access depends on current plan/limits | Conversational generation/editing and application integration | API vs ChatGPT entitlements, data and output terms | [API pricing](https://openai.com/api/pricing/) · [image guide](https://platform.openai.com/docs/guides/image-generation) |

> **Clear rights before publishing**
> Check input licenses, model terms, trademarks, likeness/publicity rights, privacy, client confidentiality, disclosure requirements, and plan-specific commercial terms. Never clone a real person's identity or style for deceptive use.

## Selection criteria

- Generation vs precise editing/layout; masks, layers, vectors, typography, and export formats.
- Reference images, character/product consistency, style controls, and batch/API support.
- Local/private workflow, data retention/training use, and public gallery defaults.
- Model and asset provenance, content credentials, commercial terms, and indemnity.
- Accessibility: alt-text workflow, contrast, legibility, and human review.
- Credit/GPU consumption, resolution/upscaling, storage, collaboration, and revision cost.

## Free-first path

1. Create a written brief and a rights-safe reference set.
2. Prototype with Canva/Firefly/Ideogram free access or ComfyUI with a clearly licensed model.
3. Test five repeatable prompts plus editing, text accuracy, and export—not one lucky output.
4. Finish in a conventional editor and conduct accessibility/rights review.
5. Pay for control, privacy, collaboration, higher limits, API use, or contractual protection.

```mermaid
flowchart TD
    A["Visual task"] --> B{"Need precise layout/brand editing?"}
    B -->|"Yes"| C["Canva or Adobe workflow"]
    B -->|"No"| D{"Need local/custom pipeline?"}
    D -->|"Yes"| E["ComfyUI + licensed model"]
    D -->|"No"| F{"Aesthetic exploration or text-heavy graphic?"}
    F -->|"Aesthetic"| G["Midjourney / Firefly / OpenAI"]
    F -->|"Text-heavy"| H["Ideogram / Canva / Firefly"]
    C --> I["Human edit, accessibility, rights review"]
    E --> I
    G --> I
    H --> I
```

## Role connections

[Generative AI Designer](<../04%20Role%20Tracks/Nontechnical/AI%20Image%20and%20Graphic%20Creator.md>), [AI Creative Director](<../04%20Role%20Tracks/Nontechnical/Generative%20AI%20Creative%20Director.md>), [Graphic Designer](<../04%20Role%20Tracks/Nontechnical/AI%20Image%20and%20Graphic%20Creator.md>), [Marketing Content Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Content%20Designer.md>), [UX Designer](<../04%20Role%20Tracks/Nontechnical/AI%20UX%20and%20Product%20Designer.md>), and [Prompt and Context Engineer](<../04%20Role%20Tracks/Nontechnical/Prompt%20and%20Context%20Engineer.md>).

## Official-source record

Verified **2026-08-12**. See [Tool Source Registry — Image and design](<../10%20Research/Tools/Tool%20Source%20Registry.md>).
