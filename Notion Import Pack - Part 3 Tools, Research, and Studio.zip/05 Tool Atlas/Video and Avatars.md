# Video and Avatars

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: published · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: tool-category
> **Tags:** atlas/tools, ai/video, ai/avatars

> **October 13, 2026 update**
> API availability and consumer-app availability are different. See [Model and Agent Lifecycle Management](<Model%20and%20Agent%20Lifecycle%20Management.md>) for lifecycle changes; current consumer Sora access was not verified in this pass.

Video tools span generative shots, editing, effects, translation/dubbing, presenters, avatars, and programmatic rendering. Choose by deliverable and revision workflow rather than demo quality.

## Representative comparison

| Tool | Access posture | Best fit | Watch closely | Official |
|---|---|---|---|---|
| DaVinci Resolve | No-fee Resolve plus paid Studio | Professional editing, color, audio, and AI-assisted postproduction | Hardware demands and Studio-only features | [product comparison](https://www.blackmagicdesign.com/products/davinciresolve) |
| Runway | Free limited plan plus paid/enterprise | Generative shots, effects, editing, creative production | Credit burn, model/version changes, rights/privacy | [pricing](https://runwayml.com/pricing) · [help](https://help.runwayml.com/) |
| Adobe Firefly Video | Limited free credits plus paid plans/enterprise | Adobe-integrated generation and production editing | Generative credits and model-specific terms | [plans](https://www.adobe.com/products/firefly/plans.html) · [video](https://www.adobe.com/products/firefly/features/ai-video-generator.html) |
| HeyGen | Free limited plan plus paid team/enterprise/API | Presenter avatars, translation, business videos | Avatar/voice consent, credits, API separate billing | [pricing](https://www.heygen.com/pricing) · [API pricing](https://developers.heygen.com/docs/pricing) |
| Synthesia | Free entry plus paid self-serve/enterprise | Corporate training and multilingual avatar video | Minute/feature limits and custom-avatar governance | [pricing](https://www.synthesia.io/pricing) · [help](https://help.synthesia.io/) |
| Pika | Free limited plan plus paid plans | Short creative generation and effects | Credits, watermark/resolution, consistency | [pricing](https://pika.art/pricing) |
| Luma Dream Machine | Free limited access plus paid plans/API | Generative video ideation and shots | Credit/priority queue and output consistency | [plans](https://lumalabs.ai/dream-machine/pricing) · [API](https://lumalabs.ai/api/pricing) |
| OpenAI Sora / Videos API | Historical API entry; do not assume current access | See [Model and Agent Lifecycle Management](<Model%20and%20Agent%20Lifecycle%20Management.md>) for API retirement | Consumer product access not verified in this refresh | [API lifecycle](https://developers.openai.com/api/docs/deprecations) |

> **Obtain explicit identity consent**
> Do not create deceptive impersonations. Document consent for faces and voices, intended uses, duration, revocation, languages, and distribution. Label synthetic media where required or appropriate and protect avatar credentials/assets.

## Selection criteria

- Generative shot, editor, avatar presenter, translation, or programmatic API.
- Shot length, resolution, aspect ratio, camera/motion control, consistency, and editability.
- Brand kit, collaboration, captions, accessibility, localization, and review workflow.
- Identity verification, consent records, watermark/content credentials, moderation, and audit.
- Input/output ownership, training use, music/stock licensing, and commercial terms.
- Credits per generation, failed-generation policy, render queue, storage, export, and API limits.

## Free-first path

1. Storyboard with still frames and a timecoded script.
2. Edit real/public-domain footage in DaVinci Resolve; use limited generation only where it adds value.
3. Test one short shot or avatar segment on free access with a consented/synthetic identity.
4. Evaluate continuity, captions, pronunciation, artifacts, disclosure, and revision time.
5. Pay after estimating usable seconds—not generated seconds—and the human postproduction load.

```mermaid
flowchart TD
    A["Video deliverable"] --> B{"Avatar presenter?"}
    B -->|"Yes"| C["HeyGen or Synthesia"]
    B -->|"No"| D{"Generate shots/effects?"}
    D -->|"Yes"| E["Verify a currently available video tool"]
    D -->|"No"| F["DaVinci Resolve editing"]
    C --> G["Consent and identity review"]
    E --> H["Continuity and rights review"]
    F --> I["Caption and accessibility review"]
    G --> J["Human edit and publish gate"]
    H --> J
    I --> J
```

## Role connections

[AI Video Producer](<../04%20Role%20Tracks/Nontechnical/AI%20Video%20Producer.md>), [Instructional Designer](<../04%20Role%20Tracks/Nontechnical/AI%20Trainer%20and%20Educator.md>), [Video Editor](<../04%20Role%20Tracks/Nontechnical/AI%20Video%20Producer.md>), [Localization Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Content%20Designer.md>), [AI Creative Director](<../04%20Role%20Tracks/Nontechnical/Generative%20AI%20Creative%20Director.md>), and [Marketing Content Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Content%20Designer.md>).

## Official-source record

Verified **2026-08-12**. See [Tool Source Registry — Video and avatars](<../10%20Research/Tools/Tool%20Source%20Registry.md>).
