# Evaluation and Observability

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: published · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: tool-category
> **Tags:** atlas/tools, ai/evaluation, ai/observability

> **October 13, 2026 update**
> See [Model and Agent Lifecycle Management](<Model%20and%20Agent%20Lifecycle%20Management.md>) for hosted evaluation lifecycle and export planning. Hosted OpenAI Evals and the open-source evals repository are distinct.

Evaluation asks whether an AI system is good enough; observability explains what happened in development and production. Effective programs combine deterministic checks, task metrics, human rubrics, adversarial cases, trace review, and business outcomes.

> **Foundry delivery overlay · 2026-08-24**
> [Microsoft Azure DevOps and Foundry](<Microsoft%20Azure%20DevOps%20and%20Foundry.md>) connects Foundry evaluations to Azure Pipelines gates, hosted-agent traces, and protected Azure DevOps environments. Foundry evaluation targets can include an agent, model, dataset, responses, or traces. Version the dataset, rubric, evaluator, threshold, model, agent/toolbox, and command extension together.

> **Edge/web delivery overlay · 2026-08-24**
> [Cloudflare and Vercel AI](<Cloudflare%20and%20Vercel%20AI.md>) teaches why gateway fallbacks, AI Search ACLs, Durable Object/Workflow recovery, AI SDK provider routing, WorkflowAgent approvals, Sandbox isolation, and cross-vendor trace correlation all belong in the evaluation set.

## Representative comparison

| Tool | Access posture | Best fit | Main trade-off | Official |
|---|---|---|---|---|
| promptfoo | Open-source CLI plus paid cloud/enterprise offerings | CI regression tests, red teaming, provider comparisons | You must design valid tests and graders | [docs](https://www.promptfoo.dev/docs/) · [pricing](https://www.promptfoo.dev/pricing/) |
| Arize Phoenix / Arize AX | Open-source self-hosted Phoenix; free cloud entry plus paid plans | Local-first tracing/evals with managed upgrade path | Cloud ingestion/retention plan limits | [pricing](https://arize.com/pricing) · [Phoenix docs](https://arize.com/docs/phoenix) |
| LangSmith | Free developer entry plus paid/enterprise | Tracing, datasets, experiments, evals, especially LangChain/LangGraph | Platform units, retention, ecosystem coupling | [pricing](https://www.langchain.com/pricing) · [docs](https://docs.langchain.com/langsmith/home) |
| Langfuse | Open-source/self-host option plus free/paid cloud | Provider-neutral LLM tracing, prompts, evals | Self-host responsibility or cloud limits | [pricing](https://langfuse.com/pricing) · [docs](https://langfuse.com/docs) |
| Braintrust | Free entry plus paid/enterprise | Dataset-driven experiments, scorers, prompt management, production logs | SaaS workflow and usage meters | [pricing](https://www.braintrust.dev/pricing) · [docs](https://www.braintrust.dev/docs) |
| Weights & Biases Weave | Open-source SDK with free/paid W&B platform posture | Evals and tracing alongside ML experiments | Platform/seat/usage considerations | [Weave](https://weave-docs.wandb.ai/) · [W&B pricing](https://wandb.ai/site/pricing) |
| DeepEval / Confident AI | Open-source framework plus managed platform | Python test-style LLM evaluation and CI | Metric validity and managed-service dependency | [DeepEval](https://deepeval.com/docs/getting-started) · [Confident AI pricing](https://www.confident-ai.com/pricing) |

## Build an evaluation stack in layers

| Layer | Examples |
|---|---|
| Contract | JSON/schema validity, required citation, tool arguments, refusal policy |
| Task | Exact match, classification F1, retrieval recall, groundedness, rubric |
| Safety | Prompt injection, harmful output, PII, bias, misuse, excessive agency |
| System | Latency, error/retry rate, token/tool cost, cache hit, availability |
| Human | Blind pairwise preference, domain-expert rubric, accessibility/usability |
| Business | Resolution rate, review time, conversion, escalation, loss avoided |

## Selection criteria

- Offline/CI evaluation, online monitoring, or both.
- Trace standard and ability to redact, sample, export, and set retention.
- Dataset/version support, human annotation, custom scorers, and statistical comparison.
- Model-judge controls: calibration, position bias, reference answers, and judge drift.
- Agent/tool/retrieval visibility and causal debugging.
- Access control, tenancy, region, SSO, audit, and cost allocation.

## Free-first path

1. Create a versioned CSV/JSONL evaluation set and plain-language rubric.
2. Add deterministic assertions in the normal test suite.
3. Use promptfoo, Phoenix, Langfuse, Weave, or DeepEval locally.
4. Compare automated scores with blinded human ratings.
5. Pay for collaboration, retention, production monitoring, or governance after the test design is trustworthy.

```mermaid
flowchart LR
    A["Versioned dataset"] --> B["Candidate system"]
    B --> C["Deterministic checks"]
    B --> D["Task and safety metrics"]
    B --> E["Human rubric"]
    B --> F["Trace, latency, and cost"]
    C --> G{"Release gate"}
    D --> G
    E --> G
    F --> G
    G -->|"Pass"| H["Canary and monitor"]
    G -->|"Fail"| I["Diagnose and revise"]
    I --> B
```

> **A judge model is evidence, not truth**
> Validate LLM-as-judge scores against domain experts and test sensitivity to prompt, ordering, model version, and reference-answer quality.

## Role connections

[AI Evaluation Engineer](<../02%20Core%20Skills/AI%20Assurance%20Evidence.md>), [MLOps Engineer](<../04%20Role%20Tracks/Technical/MLOps%20Engineer.md>), [AI Quality Assurance Engineer](<../02%20Core%20Skills/AI%20Assurance%20Evidence.md>), [Data Scientist](<../04%20Role%20Tracks/Technical/Data%20Scientist%20-%20AI%20ML.md>), [AI Product Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Product%20Manager.md>), and [Responsible AI Lead](<../03%20Career%20Map/Nontechnical/Governance%2C%20Risk%2C%20Policy%20and%20Ethics%20Careers.md>).

## Official-source record

Verified **2026-08-12**. See [Tool Source Registry — Evaluation and observability](<../10%20Research/Tools/Tool%20Source%20Registry.md>).
