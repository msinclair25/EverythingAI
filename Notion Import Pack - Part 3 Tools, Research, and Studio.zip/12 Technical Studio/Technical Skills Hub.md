# Technical Skills Hub

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: current · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: hub
> **Tags:** technical-studio, technical-skills, hub
> **Aliases:** Technical Concepts, Builder Concept Spine

> **October 13, 2026 update**
> The sixteen-concept spine is unchanged. Apply it through [Technical Role Practice Workbook — October 2026](<Technical%20Role%20Practice%20Workbook%20%E2%80%94%20October%202026.md>), [Case - Agent Memory Incident](<Case%20-%20Agent%20Memory%20Incident.md>), and [Case - Routing Quality and Capacity](<Case%20-%20Routing%20Quality%20and%20Capacity.md>).

> **Outcome**
> Learn the technical concepts that every builder-track role reuses, in plain language first: what the idea is, **why it exists**, what the jargon actually names, and what goes wrong when you skip it. Cases in [Technical Studio](<Technical%20Studio.md>) then force a decision with those ideas.

Foundations give you a map. These notes teach the machinery. They are still not labs: you read, recompute the teaching numbers, and explain the term aloud. You do not follow a tutorial.

## Why this spine exists

A title like “LLM engineer” is a pile of reused ideas. If you cannot explain **token**, **held-out**, **precision**, **KV cache**, **grounding**, and **authority**, you will memorize tool menus and fail the first design review.

```mermaid
flowchart TB
    F["Foundations: name the idea"] --> C["Concepts: why it exists + jargon"]
    C --> K["Cases: decide under a contract"]
    K --> R["Role: own the loop"]
```

## Study order

Do them in this order unless a role note tells you to skip. Each note should take 25–40 minutes: read, hide the flashcards, recompute one table, explain one term to an imaginary non-engineer.

| # | Concept | The question it answers |
|---:|---|---|
| 1 | [Tokens, Context, and Cost](<Tokens%2C%20Context%2C%20and%20Cost.md>) | What is the model actually counting, and why does that become money and latency? |
| 2 | [Leakage and Contamination](<Leakage%20and%20Contamination.md>) | Why can a beautiful score be fake? |
| 3 | [Metrics That Decide](<Metrics%20That%20Decide.md>) | Which number should change a ship/stop choice? |
| 4 | [Attention, Memory, and Inference](<Attention%2C%20Memory%2C%20and%20Inference.md>) | Why is generation slow, and what is a KV cache? |
| 5 | [Context Engineering](<Context%20Engineering.md>) | What goes in the window, in what order, and what gets dropped? |
| 6 | [Structured Outputs and Contracts](<Structured%20Outputs%20and%20Contracts.md>) | Why is model JSON untrusted? |
| 7 | [Retrieval Quality](<Retrieval%20Quality.md>) | How do you know the right document was found and used? |
| 8 | [Adaptation Methods](<Adaptation%20Methods.md>) | Prompt, retrieve, fine-tune, or train — which gap are you closing? |
| 9 | [Embeddings and Similarity](<Embeddings%20and%20Similarity.md>) | What does “close” mean, and why is it not truth? |
| 10 | [The Training Loop](<The%20Training%20Loop.md>) | What is the optimizer actually minimizing? |
| 11 | [The Agent Loop](<The%20Agent%20Loop.md>) | When is the next step chosen at run time? |
| 12 | [Untrusted Context and Injection](<Untrusted%20Context%20and%20Injection.md>) | Why is a system prompt not a lock? |
| 13 | [Sampling and Decoding](<Sampling%20and%20Decoding.md>) | Why doesn’t lower temperature add facts? |
| 14 | [Calibration](<Calibration.md>) | When the system says 80%, does the event happen 80% of the time? |
| 15 | [Quantization](<Quantization.md>) | What quality did we trade for bits? |
| 16 | [Vision and Multimodal Systems](<Vision%20and%20Multimodal%20Systems.md>) | Why isn’t a VLM caption a detector? |

After 1–3, you can sit [Case - Evaluation Harness](<Case%20-%20Evaluation%20Harness.md>) and [Case - Split Integrity](<Case%20-%20Split%20Integrity.md>). After 4–5 and 15, sit [Case - Serving Capacity](<Case%20-%20Serving%20Capacity.md>). After 5–7 and 9, sit [Case - Retrieval Failure Autopsy](<Case%20-%20Retrieval%20Failure%20Autopsy.md>) and [Case - Prompt RAG Fine-Tune](<Case%20-%20Prompt%20RAG%20Fine-Tune.md>). After 6, 11, and 12, sit [Case - Agent Permissions](<Case%20-%20Agent%20Permissions.md>). After 2 and 10, sit [Case - Split Integrity](<Case%20-%20Split%20Integrity.md>) if you skipped it. After 13, reread any eval that did not name \(T\) / top-p. After 16, open [Computer Vision Engineer](<../04%20Role%20Tracks/Technical/Computer%20Vision%20Engineer.md>).

## How each note is built

1. **Plain idea** — one paragraph with no vendor names.
2. **Why it exists** — the failure that created the term.
3. **Jargon** — each word, then the misconception.
4. **Worked teaching numbers** — constructed, labeled, checkable.
5. **Quiz and flashcards** — retrieve, do not reread.
6. **Transfer** — which case and role use this.

If a sentence in a role profile uses a word you cannot unpack, come back here. Then add it to [AI Glossary](<../AI%20Glossary.md>) if it is still missing.

## What this is not

- Not a Python course. Use [03 Python SQL Git and Software Foundations](<../01%20Foundations/03%20Python%20SQL%20Git%20and%20Software%20Foundations.md>) plus official docs.
- Not a research derivation course. Use [02 Math and Statistics for AI](<../01%20Foundations/02%20Math%20and%20Statistics%20for%20AI.md>) and the linked textbooks when you need proofs.
- Not a substitute for a portfolio. Concepts make the project honest; they are not the project.

## Next

Start [Tokens, Context, and Cost](<Tokens%2C%20Context%2C%20and%20Cost.md>) or, if you want a calendar, [Builder 4-Week Syllabus](<../00%20Start%20Here/Builder%204-Week%20Syllabus.md>). Keep [AI Glossary](<../AI%20Glossary.md>) open. Spine policy: [Concept Spine Freeze](<Concept%20Spine%20Freeze.md>).
