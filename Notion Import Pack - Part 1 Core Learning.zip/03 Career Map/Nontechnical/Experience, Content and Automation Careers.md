# Experience, Content and Automation Careers

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: current · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: career-map
> **Tags:** ai-careers/nontechnical, career-family/experience-automation
> **Aliases:** AI UX Conversation Content and Automation Career Family

These roles shape how people understand, control, and recover from probabilistic systems—and how work moves through them.

```mermaid
flowchart LR
    Research["AI UX Researcher\nneeds and behavior"] --> Design["AI UX and Product Designer\ninteraction and control"]
    Design --> Conv["Conversation Designer\ndialogue and repair"]
    Design --> Content["AI Content Designer\nwords and comprehension"]
    Conv --> Prompt["Prompt and Context Engineer\ninstructions, context, evals"]
    Prompt --> Auto["AI Automation Specialist\nworkflow and operations"]
```

| Role | Optimizes | Typical evidence |
|---|---|---|
| [AI UX and Product Designer](<../../04%20Role%20Tracks/Nontechnical/AI%20UX%20and%20Product%20Designer.md>) | Whole human-AI interaction | Prototype with uncertainty, override, feedback, and recovery states |
| [AI UX Researcher](<../../04%20Role%20Tracks/Nontechnical/AI%20UX%20Researcher.md>) | Understanding of people and context | Research plan, moderated study, findings linked to decisions |
| [Conversation Designer](<../../04%20Role%20Tracks/Nontechnical/Conversation%20Designer.md>) | Turns, voice, clarification, repair, escalation | Dialogue map and adversarial test transcript |
| [AI Content Designer](<../../04%20Role%20Tracks/Nontechnical/AI%20Content%20Designer.md>) | Clarity, guidance, labels, error and consent language | Content system and comprehension test |
| [Prompt and Context Engineer](<../../04%20Role%20Tracks/Nontechnical/Prompt%20and%20Context%20Engineer.md>) | Reproducible model behavior | Versioned prompt/context package and evaluation set |
| [AI Automation Specialist](<../../04%20Role%20Tracks/Nontechnical/AI%20Automation%20Specialist.md>) | Reliable movement of work across systems | Diagram, workflow, test matrix, logs, runbook |

## Non-negotiables

- Design the human’s authority: review, edit, override, retry, escalate, and exit.
- Test with representative users and realistic failures—not only happy paths.
- Meet accessibility needs; WCAG 2.2 remains the practical baseline for web content and interaction.
- Treat prompts, retrieved context, tools, and output handling as one system.

## Sources

Checked **2026-08-12**.

- [NIST — Human Centered Design](https://www.nist.gov/itl/iad/human-centered-technologies/human-factors-human-centered-design).
- [W3C — WCAG 2.2 Overview](https://www.w3.org/WAI/standards-guidelines/wcag/).
- [NIST — AI RMF FAQs](https://www.nist.gov/itl/ai-risk-management-framework/ai-risk-management-framework-faqs) — trustworthiness across design, deployment, use, and evaluation.
