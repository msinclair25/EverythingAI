# Solutions, Go-to-Market and Developer Relations Careers

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: current · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: career-map
> **Tags:** ai-careers/nontechnical, career-family/solutions-gtm
> **Aliases:** AI Solutions and GTM Career Family

This family makes technical capability understandable, adoptable, and valuable to customers or developers.

```mermaid
flowchart LR
    Market["Market need"] --> PMM["AI Product Marketing Manager\npositioning and launch"]
    PMM --> AE["AI Enterprise Account Executive\ncommercial process"]
    AE --> SE["AI Sales Engineer\ndiscovery and proof"]
    SE --> SA["AI Solutions Architect\nfeasible design"]
    SA --> CSM["AI Customer Success Manager\nadoption and outcomes"]
    CSM --> Support["AI Technical Support and User Operations Specialist\ndiagnosis and recovery"]
    Partner["Ecosystem opportunity"] --> Partnerships["AI Strategic Partnerships Manager\njoint value and operation"]
    Partnerships --> PMM
    Developer["Developer problem"] --> DX["AI Developer Relations and Advocate\ndocs, samples, feedback"]
```

| Role | Primary audience | Signature artifact |
|---|---|---|
| [AI Solutions Architect](<../../04%20Role%20Tracks/Nontechnical/AI%20Solutions%20Architect.md>) | Customer engineering and architecture | Reference architecture and evaluation/security plan |
| [AI Sales Engineer](<../../04%20Role%20Tracks/Nontechnical/AI%20Sales%20Engineer.md>) | Buyer, evaluator, procurement team | Discovery-backed demo and proof-of-value plan |
| [AI Customer Success Manager](<../../04%20Role%20Tracks/Nontechnical/AI%20Customer%20Success%20Manager.md>) | Deployed customer and executives | Adoption/outcome plan with risk escalation |
| [AI Developer Relations and Advocate](<../../04%20Role%20Tracks/Nontechnical/AI%20Developer%20Relations%20and%20Advocate.md>) | Developers and product teams | Runnable sample, tutorial, talk, feedback synthesis |
| [AI Product Marketing Manager](<../../04%20Role%20Tracks/Nontechnical/AI%20Product%20Marketing%20Manager.md>) | Defined market segments, field, and partners | Positioning brief, claims matrix, launch and enablement system |
| [AI Enterprise Account Executive](<../../04%20Role%20Tracks/Nontechnical/AI%20Enterprise%20Account%20Executive.md>) | Enterprise buying group and executives | Account plan, mutual action plan, commercial decision and handoff |
| [AI Strategic Partnerships Manager](<../../04%20Role%20Tracks/Nontechnical/AI%20Strategic%20Partnerships%20Manager.md>) | Ecosystem counterpart and internal partner teams | Partner thesis, joint operating model, scorecard, renewal/exit decision |
| [AI Technical Support and User Operations Specialist](<../../04%20Role%20Tracks/Nontechnical/AI%20Technical%20Support%20and%20User%20Operations%20Specialist.md>) | Users, developers, deployed customers, and responders | Reproduction, case/escalation record, knowledge and incident improvement |

> **Portfolio rule**
> A generic chatbot is weak evidence. Show one audience, one real workflow, explicit success criteria, failure handling, data boundaries, and a clear handoff.

## Sources

Checked **2026-08-12**.

- [O*NET — Sales Engineers](https://www.onetonline.org/link/summary/41-9031.00) — transferable U.S. occupation analog.
- [NIST — AI Resource Center](https://airc.nist.gov/) — AI evaluation and risk resources.
- [OpenAI — API documentation](https://developers.openai.com/api/docs/) — an example of the official documentation surface these roles must learn to navigate; vendor-specific features change quickly.
- [O*NET — Computer User Support Specialists](https://www.onetonline.org/link/summary/15-1232.00) — U.S. occupational support analog, updated 2026.
- [FTC — Advertising and Marketing](https://www.ftc.gov/business-guidance/advertising-marketing) — official U.S. truth-in-advertising and claim-evidence baseline.
- [NIST — AI RMF Core](https://airc.nist.gov/airmf-resources/airmf/5-sec-core/) — lifecycle, third-party, monitoring, response, and accountability vocabulary.
