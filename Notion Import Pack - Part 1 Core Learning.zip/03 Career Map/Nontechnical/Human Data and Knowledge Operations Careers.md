# Human Data and Knowledge Operations Careers

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: current · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: career-map
> **Tags:** ai-careers/nontechnical, career-family/human-data-knowledge
> **Aliases:** AI Human Operations and Knowledge Career Family

This family supplies the structured human judgment and organized information that make AI systems trainable, evaluable, retrievable, and maintainable.

```mermaid
flowchart LR
    Recruit["AI Talent and Recruiting Specialist\npeople and fair process"] --> Work["Human work system"]
    Annotate["Data Annotator and AI Rater\nlabels and ratings"] --> HF["Human-Feedback Specialist\nrubric and preference design"]
    HF --> Ops["AI Data Operations Manager\nquality, throughput, welfare"]
    Tax["Taxonomist and Ontology Specialist\nconcept structure"] --> KM["Knowledge Manager\ntrusted lifecycle"]
    KM --> Context["Search, retrieval, and grounded assistance"]
```

| Role | Unit of responsibility | Signature artifact |
|---|---|---|
| [AI Talent and Recruiting Specialist](<../../04%20Role%20Tracks/Nontechnical/AI%20Talent%20and%20Recruiting%20Specialist.md>) | Candidate/employee process and capability | Skills-based role profile, structured interview, tool-risk review |
| [Data Annotator and AI Rater](<../../04%20Role%20Tracks/Nontechnical/Data%20Annotator%20and%20AI%20Rater.md>) | One label/rating with rationale | Calibrated sample set and error analysis |
| [Human-Feedback Specialist](<../../04%20Role%20Tracks/Nontechnical/Human-Feedback%20Specialist.md>) | Rubric, task, calibration, ambiguity | Annotation guide, gold set, agreement/quality report |
| [AI Data Operations Manager](<../../04%20Role%20Tracks/Nontechnical/AI%20Data%20Operations%20Manager.md>) | Production system and workforce | Capacity/quality dashboard, lineage, escalation and worker-welfare plan |
| [Taxonomist and Ontology Specialist](<../../04%20Role%20Tracks/Nontechnical/Taxonomist%20and%20Ontology%20Specialist.md>) | Concepts, labels, relations, constraints | Governed taxonomy or ontology with validation report |
| [Knowledge Manager](<../../04%20Role%20Tracks/Nontechnical/Knowledge%20Manager.md>) | Trusted knowledge lifecycle | Source inventory, metadata model, permissions, freshness and retrieval test |

> **Human data is not “cheap ground truth”**
> Labels are judgments under instructions. Quality depends on clear constructs, representative tasks, calibration, disagreement handling, privacy/security, domain expertise, and humane working conditions. Measure agreement where appropriate, but do not erase legitimate ambiguity.

## Sources

Checked **2026-08-12**.

- [W3C — SKOS Reference](https://www.w3.org/TR/skos-reference/) — concepts, labels, schemes, and semantic relations.
- [NIST — AI RMF](https://www.nist.gov/itl/ai-risk-management-framework) — data, human oversight, evaluation, and lifecycle risk.
- [EEOC — Artificial Intelligence and the ADA](https://www.eeoc.gov/eeoc-disability-related-resources/artificial-intelligence-and-ada).
- [U.S. Department of Labor — AI & Inclusive Hiring Framework announcement](https://www.dol.gov/newsroom/releases/odep/odep20240924).
- [NYC DCWP — Automated Employment Decision Tools](https://www.nyc.gov/site/dca/about/automated-employment-decision-tools.page).
