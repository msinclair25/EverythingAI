# Job Title Crosswalk

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: reference
> **Tags:** ai-careers, job-titles, reference

Titles are clues, not definitions. Map a posting by deliverables, decision rights, stakeholders, and required evidence.

| Posting title or phrase | Usually start with | Check this boundary |
|---|---|---|
| Machine Learning Scientist, AI Scientist | [Applied Scientist](<../04%20Role%20Tracks/Technical/Applied%20Scientist.md>) or [AI ML Research Scientist](<../04%20Role%20Tracks/Technical/AI%20ML%20Research%20Scientist.md>) | novel research vs product experiments |
| Research Software Engineer, ML Research Engineer | [Research Engineer](<../04%20Role%20Tracks/Technical/Research%20Engineer.md>) | research velocity vs production ownership |
| GenAI Engineer, Foundation Model Engineer | [AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>) or [LLM Engineer](<../04%20Role%20Tracks/Technical/LLM%20Engineer.md>) | API application vs model adaptation/training |
| Full-Stack AI Engineer, AI Application Developer | [AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>) | frontend/backend breadth does not remove evaluation duties |
| Forward-Deployed Engineer, Deployment Engineer | [AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>), [AI Solutions Architect](<../04%20Role%20Tracks/Nontechnical/AI%20Solutions%20Architect.md>), or [AI Sales Engineer](<../04%20Role%20Tracks/Nontechnical/AI%20Sales%20Engineer.md>) | embedded production delivery vs architecture, pre-sale proof, or core product engineering |
| AI Implementation Consultant, Deployment Strategist | [AI Business Analyst](<../04%20Role%20Tracks/Nontechnical/AI%20Business%20Analyst.md>), [AI Transformation Lead](<../04%20Role%20Tracks/Nontechnical/AI%20Transformation%20Lead.md>), or [AI Solutions Architect](<../04%20Role%20Tracks/Nontechnical/AI%20Solutions%20Architect.md>) | workflow/adoption ownership vs technical design and implementation depth |
| AI Agent Engineer, Agent Engineer | [Agentic AI Engineer](<../04%20Role%20Tracks/Technical/Agentic%20AI%20Engineer.md>) | autonomous tool use vs ordinary workflow automation |
| Prompt Engineer | [Prompt and Context Engineer](<../04%20Role%20Tracks/Nontechnical/Prompt%20and%20Context%20Engineer.md>) | standalone content role vs engineering, design, or evaluation function |
| Conversational AI Designer, Voice UX Designer | [Conversation Designer](<../04%20Role%20Tracks/Nontechnical/Conversation%20Designer.md>) | experience design vs speech-model engineering |
| NLP Scientist, Computational Linguist | [NLP Engineer](<../04%20Role%20Tracks/Technical/NLP%20Engineer.md>) or [Applied Scientist](<../04%20Role%20Tracks/Technical/Applied%20Scientist.md>) | language expertise vs production engineering |
| Vision Scientist, Imaging ML Engineer | [Computer Vision Engineer](<../04%20Role%20Tracks/Technical/Computer%20Vision%20Engineer.md>) | research depth and domain credentials vary |
| Autonomous Systems Engineer | [Robotics and Embodied AI Engineer](<../04%20Role%20Tracks/Technical/Robotics%20and%20Embodied%20AI%20Engineer.md>) | controls/robotics vs software agent autonomy |
| AI Data Engineer, Feature Platform Engineer | [ML Data Engineer](<../04%20Role%20Tracks/Technical/ML%20Data%20Engineer.md>) | training/serving data vs general analytics data |
| Retrieval Engineer, Search/GenAI Engineer | [RAG and Knowledge Engineer](<../04%20Role%20Tracks/Technical/RAG%20and%20Knowledge%20Engineer.md>) | retrieval quality vs broader AI application ownership |
| Knowledge Graph Engineer | [RAG and Knowledge Engineer](<../04%20Role%20Tracks/Technical/RAG%20and%20Knowledge%20Engineer.md>) or [Taxonomist and Ontology Specialist](<../04%20Role%20Tracks/Nontechnical/Taxonomist%20and%20Ontology%20Specialist.md>) | implementation vs semantic modeling |
| Model Serving Engineer, ML Performance Engineer | [Inference and Performance Engineer](<../04%20Role%20Tracks/Technical/Inference%20and%20Performance%20Engineer.md>) | serving optimization vs general platform operations |
| ML Compiler Engineer, GPU Kernel Engineer | [Inference and Performance Engineer](<../04%20Role%20Tracks/Technical/Inference%20and%20Performance%20Engineer.md>) or [AI Hardware and Accelerator Engineer](<../04%20Role%20Tracks/Technical/AI%20Hardware%20and%20Accelerator%20Engineer.md>) | compiler/runtime optimization vs hardware architecture and co-design |
| ML Platform Engineer | [AI Platform Engineer](<../04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>) | shared developer platform vs model-specific delivery |
| ML Reliability Engineer | [MLOps Engineer](<../04%20Role%20Tracks/Technical/MLOps%20Engineer.md>) or [AI Platform Engineer](<../04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>) | service reliability vs lifecycle automation |
| LLM Evaluator, Model Behavior Engineer | [AI Evaluation Engineer](<../04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>) | measurement engineering vs data rating |
| AI Quality Analyst, Model Quality Specialist | [AI Evaluation Engineer](<../04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>), [Human Feedback Specialist](<../04%20Role%20Tracks/Nontechnical/Human-Feedback%20Specialist.md>), or [Data Annotator and AI Rater](<../04%20Role%20Tracks/Nontechnical/Data%20Annotator%20and%20AI%20Rater.md>) | evaluation-system design vs expert rubric/feedback work vs task-level rating |
| AI Safety Engineer | [AI Evaluation Engineer](<../04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>), [AI Security Engineer](<../04%20Role%20Tracks/Technical/AI%20Security%20Engineer.md>), or [AI Safety and Alignment Researcher](<../04%20Role%20Tracks/Technical/AI%20Safety%20and%20Alignment%20Researcher.md>) | behavior safety, security, and research are different mandates |
| Adversarial ML Engineer | [AI Security Engineer](<../04%20Role%20Tracks/Technical/AI%20Security%20Engineer.md>) | defense engineering vs authorized red-team testing |
| AI Trust and Safety Specialist, Integrity Operations, Risk Operations | [AI Trust and Safety Operations Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Trust%20and%20Safety%20Operations%20Specialist.md>) or [Responsible AI Specialist](<../04%20Role%20Tracks/Nontechnical/Responsible%20AI%20Specialist.md>) | platform abuse operations and case response vs lifecycle impact/control design |
| Algorithmic Auditor | [AI Auditor and Assurance Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Auditor%20and%20Assurance%20Specialist.md>) | internal audit independence and legal remit vary |
| AI Risk Manager | [Model Risk Manager](<../04%20Role%20Tracks/Nontechnical/Model%20Risk%20Manager.md>) or [AI Governance Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Governance%20Specialist.md>) | model validation vs enterprise governance |
| AI Governance Lead, Responsible AI Program Lead | [AI Governance Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Governance%20Specialist.md>) or [Responsible AI Specialist](<../04%20Role%20Tracks/Nontechnical/Responsible%20AI%20Specialist.md>) | policy/control system vs implementation guidance |
| AI Policy Advisor | [AI Policy Analyst](<../04%20Role%20Tracks/Nontechnical/AI%20Policy%20Analyst.md>) | public policy vs internal governance |
| AI Legal Counsel, Product Counsel for AI | [AI Compliance and Privacy Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Compliance%20and%20Privacy%20Specialist.md>) plus the appropriate [Industry Overlay Hub](<../08%20Industry%20Overlays/Industry%20Overlay%20Hub.md>) | licensed legal practice is a credentialed profession; the vault supplies issue-spotting, not legal qualification |
| AI Procurement Manager, AI Vendor Manager | [AI Program Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Program%20Manager.md>), [AI Governance Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Governance%20Specialist.md>), or [AI Strategic Partnerships Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Strategic%20Partnerships%20Manager.md>) | buyer-side sourcing/vendor control vs program coordination, governance, or mutual strategic partnership |
| AI Privacy Engineer | [AI Compliance and Privacy Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Compliance%20and%20Privacy%20Specialist.md>) plus [AI Security Engineer](<../04%20Role%20Tracks/Technical/AI%20Security%20Engineer.md>) | engineering implementation vs compliance counsel |
| GenAI Product Manager | [AI Product Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Product%20Manager.md>) | product ownership vs technical platform ownership |
| AI Platform Product Manager | [Technical AI Product Manager](<../04%20Role%20Tracks/Nontechnical/Technical%20AI%20Product%20Manager.md>) | product role, not platform engineering |
| AI Project Manager | [AI Program Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Program%20Manager.md>) | single-project delivery vs multi-stream program outcomes |
| AI Transformation Consultant | [AI Strategy Consultant](<../04%20Role%20Tracks/Nontechnical/AI%20Strategy%20Consultant.md>) or [AI Transformation Lead](<../04%20Role%20Tracks/Nontechnical/AI%20Transformation%20Lead.md>) | external recommendations vs internal adoption accountability |
| Chief AI Officer, Head of AI, VP of AI | [Chief AI Officer and Head of AI](<../04%20Role%20Tracks/Nontechnical/Chief%20AI%20Officer%20and%20Head%20of%20AI.md>) | enterprise decision rights vs program delivery, platform leadership, or research leadership |
| Intelligent Automation Developer, AI Workflow Builder | [AI Automation Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Automation%20Specialist.md>) | no-/low-code workflows vs custom application engineering |
| GenAI Architect, AI Cloud Architect | [AI Solutions Architect](<../04%20Role%20Tracks/Nontechnical/AI%20Solutions%20Architect.md>) | pre-sales/customer architecture vs internal platform architecture |
| AI Solutions Engineer | [AI Sales Engineer](<../04%20Role%20Tracks/Nontechnical/AI%20Sales%20Engineer.md>) or [AI Solutions Architect](<../04%20Role%20Tracks/Nontechnical/AI%20Solutions%20Architect.md>) | demo/proof-of-value vs durable architecture |
| Enterprise Account Executive, Strategic Account Director | [AI Enterprise Account Executive](<../04%20Role%20Tracks/Nontechnical/AI%20Enterprise%20Account%20Executive.md>) | commercial ownership vs technical validation or post-sale adoption |
| AI Product Marketing, GTM Lead | [AI Product Marketing Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Product%20Marketing%20Manager.md>) | market narrative and launch/adoption strategy vs product roadmap ownership |
| AI Partnerships, Strategic Alliances, Business Development | [AI Strategic Partnerships Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Strategic%20Partnerships%20Manager.md>) | joint value and partner execution vs direct quota ownership or vendor procurement |
| AI Adoption Manager | [AI Customer Success Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Customer%20Success%20Manager.md>) or [AI Transformation Lead](<../04%20Role%20Tracks/Nontechnical/AI%20Transformation%20Lead.md>) | vendor/customer outcome vs internal change |
| AI Support Engineer, Technical Support, User Operations | [AI Technical Support and User Operations Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Technical%20Support%20and%20User%20Operations%20Specialist.md>) | incident/question resolution vs strategic customer success or core product engineering |
| AI Evangelist | [AI Developer Relations and Advocate](<../04%20Role%20Tracks/Nontechnical/AI%20Developer%20Relations%20and%20Advocate.md>) | developer audience vs general marketing |
| AI Technical Writer, AI Documentation Lead | [AI Content Designer](<../04%20Role%20Tracks/Nontechnical/AI%20Content%20Designer.md>) or [AI Developer Relations and Advocate](<../04%20Role%20Tracks/Nontechnical/AI%20Developer%20Relations%20and%20Advocate.md>) | product/interface content vs developer documentation and education |
| AI Learning Designer | [AI Trainer and Educator](<../04%20Role%20Tracks/Nontechnical/AI%20Trainer%20and%20Educator.md>) | instruction design vs model training |
| AI Experience Designer | [AI UX and Product Designer](<../04%20Role%20Tracks/Nontechnical/AI%20UX%20and%20Product%20Designer.md>) | product interaction vs conversation-only scope |
| Human-AI Interaction Researcher | [AI UX Researcher](<../04%20Role%20Tracks/Nontechnical/AI%20UX%20Researcher.md>) | user research vs academic HCI research |
| GenAI Content Strategist | [AI Content Designer](<../04%20Role%20Tracks/Nontechnical/AI%20Content%20Designer.md>) | interface content vs marketing content |
| AI Creative Technologist | [Generative AI Creative Director](<../04%20Role%20Tracks/Nontechnical/Generative%20AI%20Creative%20Director.md>) or an engineering role | creative direction vs prototype implementation |
| AI Artist, GenAI Designer | [AI Image and Graphic Creator](<../04%20Role%20Tracks/Nontechnical/AI%20Image%20and%20Graphic%20Creator.md>) | production design expectations still apply |
| Synthetic Media Producer | [AI Video Producer](<../04%20Role%20Tracks/Nontechnical/AI%20Video%20Producer.md>) or [AI Audio and Music Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Audio%20and%20Music%20Specialist.md>) | medium and rights/provenance duties |
| AI Data Trainer, AI Tutor, Model Trainer | [Human Feedback Specialist](<../04%20Role%20Tracks/Nontechnical/Human-Feedback%20Specialist.md>) or [Data Annotator and AI Rater](<../04%20Role%20Tracks/Nontechnical/Data%20Annotator%20and%20AI%20Rater.md>) | expert feedback design vs task execution |
| RLHF Operations Lead | [AI Data Operations Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Data%20Operations%20Manager.md>) | operations vs algorithm research |
| Knowledge Engineer | [Taxonomist and Ontology Specialist](<../04%20Role%20Tracks/Nontechnical/Taxonomist%20and%20Ontology%20Specialist.md>), [Knowledge Manager](<../04%20Role%20Tracks/Nontechnical/Knowledge%20Manager.md>), or [RAG and Knowledge Engineer](<../04%20Role%20Tracks/Technical/RAG%20and%20Knowledge%20Engineer.md>) | semantics, governance, and implementation differ |
| AI Recruiter | [AI Talent and Recruiting Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Talent%20and%20Recruiting%20Specialist.md>) | recruiting AI talent vs using AI in recruiting |

## A posting-mapping worksheet

1. **Outcome:** What changes if this person succeeds?
2. **Artifacts:** What do they repeatedly produce?
3. **Decisions:** What can they decide without approval?
4. **Interfaces:** Who consumes their work?
5. **Failure ownership:** Who responds when the system is wrong, slow, insecure, costly, or harmful?
6. **Evidence:** Code, research, product metrics, controls, creative work, operations quality, or customer outcomes?

The answers matter more than title similarity.
