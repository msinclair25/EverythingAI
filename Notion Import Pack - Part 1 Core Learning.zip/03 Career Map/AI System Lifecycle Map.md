# AI System Lifecycle Map

> **Metadata:** Scope: United States · Level: beginner · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: visual-map
> **Tags:** ai-careers, lifecycle, visual-map

AI work is cross-functional. The arrows are feedback loops, not a one-way assembly line.

```mermaid
flowchart LR
    S["Strategy + use-case selection"] --> D["Data + knowledge"]
    D --> M["Model or service choice"]
    M --> B["Build + integrate"]
    B --> E["Evaluate + red team"]
    E --> L["Launch + adoption"]
    L --> O["Observe + respond"]
    O --> R["Review + improve or retire"]
    R --> S
    G["Governance · privacy · security · accessibility"] --- S
    G --- D
    G --- M
    G --- B
    G --- E
    G --- L
    G --- O
    G --- R
```

| Lifecycle work | Roles that often lead | Roles that must contribute |
|---|---|---|
| strategy and problem framing | [Chief AI Officer and Head of AI](<../04%20Role%20Tracks/Nontechnical/Chief%20AI%20Officer%20and%20Head%20of%20AI.md>), [AI Product Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Product%20Manager.md>), [AI Strategy Consultant](<../04%20Role%20Tracks/Nontechnical/AI%20Strategy%20Consultant.md>), [AI Business Analyst](<../04%20Role%20Tracks/Nontechnical/AI%20Business%20Analyst.md>) | domain experts, UX, governance, engineering |
| data and knowledge | [ML Data Engineer](<../04%20Role%20Tracks/Technical/ML%20Data%20Engineer.md>), [RAG and Knowledge Engineer](<../04%20Role%20Tracks/Technical/RAG%20and%20Knowledge%20Engineer.md>), [AI Data Operations Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Data%20Operations%20Manager.md>) | privacy, ontology, domain experts, evaluation |
| model/service research and selection | [Applied Scientist](<../04%20Role%20Tracks/Technical/Applied%20Scientist.md>), [AI ML Research Scientist](<../04%20Role%20Tracks/Technical/AI%20ML%20Research%20Scientist.md>), [AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>) | product, security, finance, governance |
| application and workflow delivery | [AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>), [ML Engineer](<../04%20Role%20Tracks/Technical/ML%20Engineer.md>), [AI Automation Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Automation%20Specialist.md>) | UX, platform, evaluation, product |
| evaluation and adversarial testing | [AI Evaluation Engineer](<../04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>), [AI Red Teamer](<../04%20Role%20Tracks/Technical/AI%20Red%20Teamer.md>) | domain experts, UX research, responsible AI, security |
| deployment and reliability | [MLOps Engineer](<../04%20Role%20Tracks/Technical/MLOps%20Engineer.md>), [AI Platform Engineer](<../04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>), [Inference and Performance Engineer](<../04%20Role%20Tracks/Technical/Inference%20and%20Performance%20Engineer.md>) | application engineering, security, FinOps |
| adoption and customer outcomes | [AI Transformation Lead](<../04%20Role%20Tracks/Nontechnical/AI%20Transformation%20Lead.md>), [AI Customer Success Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Customer%20Success%20Manager.md>), [AI Trainer and Educator](<../04%20Role%20Tracks/Nontechnical/AI%20Trainer%20and%20Educator.md>) | product, UX, support, governance |
| market, revenue, and partner execution | [AI Product Marketing Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Product%20Marketing%20Manager.md>), [AI Enterprise Account Executive](<../04%20Role%20Tracks/Nontechnical/AI%20Enterprise%20Account%20Executive.md>), [AI Strategic Partnerships Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Strategic%20Partnerships%20Manager.md>) | product, sales engineering, solutions, legal, finance, customer success |
| monitoring, incidents, abuse, and change | platform/operations + product owner | [AI Technical Support and User Operations Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Technical%20Support%20and%20User%20Operations%20Specialist.md>), [AI Trust and Safety Operations Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Trust%20and%20Safety%20Operations%20Specialist.md>), evaluation, security, legal/privacy, domain owner |
| governance and assurance | [AI Governance Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Governance%20Specialist.md>), [Model Risk Manager](<../04%20Role%20Tracks/Nontechnical/Model%20Risk%20Manager.md>), [AI Auditor and Assurance Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Auditor%20and%20Assurance%20Specialist.md>) | every accountable system owner |
| retirement and records | product/system owner + governance | data, platform, security, legal, knowledge management |

> **Ownership rule**
> “The model did it” is not an ownership model. Every deployed system needs named human owners for purpose, data, technical operation, risk acceptance, incident response, and retirement.

## NIST frame

The NIST AI Risk Management Framework organizes risk work through **Govern, Map, Measure, and Manage**, designed to operate across the lifecycle. The framework is voluntary and AI RMF 1.0 was under revision as of August 12, 2026. Use the current [NIST AI RMF page](https://www.nist.gov/itl/ai-risk-management-framework) and [AI Resource Center](https://airc.nist.gov/), verified 2026-08-12.
