# AI Career Atlas

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: hub
> **Tags:** ai-careers, career-map, hub
> **Aliases:** AI Jobs Atlas

> **October 13, 2026 update**
> Use [US Career and Governance Update — October 2026](<../10%20Research/US%20Career%20and%20Governance%20Update%20%E2%80%94%20October%202026.md>) for the current BLS projection window and [Technical Role Practice Workbook — October 2026](<../12%20Technical%20Studio/Technical%20Role%20Practice%20Workbook%20%E2%80%94%20October%202026.md>) for all 23 technical role exercises.

The atlas organizes AI work by the outcome a person owns. It includes established occupations, AI specializations of established occupations, and emerging titles. See [Coverage, Evidence, and Limits](<../00%20Start%20Here/Coverage%2C%20Evidence%2C%20and%20Limits.md>) before interpreting the list as a census.

Open the interactive AI career landscape to pan, zoom, and follow its linked role cards.

## 1 · Research and applied science

- [AI ML Research Scientist](<../04%20Role%20Tracks/Technical/AI%20ML%20Research%20Scientist.md>) — creates and validates new methods or scientific knowledge.
- [Research Engineer](<../04%20Role%20Tracks/Technical/Research%20Engineer.md>) — turns research ideas into reliable experimental systems.
- [Applied Scientist](<../04%20Role%20Tracks/Technical/Applied%20Scientist.md>) — applies experimental and modeling depth to product or business problems.
- [AI Safety and Alignment Researcher](<../04%20Role%20Tracks/Technical/AI%20Safety%20and%20Alignment%20Researcher.md>) — studies and reduces harmful or misaligned model behavior.

## 2 · Model and application engineering

- [ML Engineer](<../04%20Role%20Tracks/Technical/ML%20Engineer.md>) — builds, integrates, and operates learned systems.
- [AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>) — ships applications using foundation models and AI services.
- [LLM Engineer](<../04%20Role%20Tracks/Technical/LLM%20Engineer.md>) — specializes in language-model application behavior and adaptation.
- [Agentic AI Engineer](<../04%20Role%20Tracks/Technical/Agentic%20AI%20Engineer.md>) — builds systems that plan, use tools, maintain state, and act.
- [NLP Engineer](<../04%20Role%20Tracks/Technical/NLP%20Engineer.md>) — develops systems for language understanding and generation.
- [Computer Vision Engineer](<../04%20Role%20Tracks/Technical/Computer%20Vision%20Engineer.md>) — develops systems that interpret or generate visual data.
- [Speech AI Engineer](<../04%20Role%20Tracks/Technical/Speech%20AI%20Engineer.md>) — works on speech recognition, synthesis, audio understanding, and voice systems.
- [Robotics and Embodied AI Engineer](<../04%20Role%20Tracks/Technical/Robotics%20and%20Embodied%20AI%20Engineer.md>) — connects perception, planning, learning, and control in physical systems.

## 3 · Data, retrieval, and knowledge

- [Data Scientist - AI ML](<../04%20Role%20Tracks/Technical/Data%20Scientist%20-%20AI%20ML.md>) — uses data, experiments, and models to answer decisions and build predictive solutions.
- [ML Data Engineer](<../04%20Role%20Tracks/Technical/ML%20Data%20Engineer.md>) — supplies reliable, governed, model-ready data and features.
- [RAG and Knowledge Engineer](<../04%20Role%20Tracks/Technical/RAG%20and%20Knowledge%20Engineer.md>) — builds retrieval and grounding systems around organizational knowledge.
- [Synthetic Data Engineer](<../04%20Role%20Tracks/Technical/Synthetic%20Data%20Engineer.md>) — designs and validates generated data for training, testing, privacy, or simulation.
- [Taxonomist and Ontology Specialist](<../04%20Role%20Tracks/Nontechnical/Taxonomist%20and%20Ontology%20Specialist.md>) — defines controlled concepts and relationships.
- [Knowledge Manager](<../04%20Role%20Tracks/Nontechnical/Knowledge%20Manager.md>) — makes organizational knowledge findable, governed, and reusable.

## 4 · Platform, operations, performance, and hardware

- [MLOps Engineer](<../04%20Role%20Tracks/Technical/MLOps%20Engineer.md>) — automates and governs model delivery and operations.
- [AI Platform Engineer](<../04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>) — builds shared infrastructure and paved roads for AI teams.
- [Inference and Performance Engineer](<../04%20Role%20Tracks/Technical/Inference%20and%20Performance%20Engineer.md>) — optimizes serving speed, throughput, memory, reliability, and cost.
- [AI Hardware and Accelerator Engineer](<../04%20Role%20Tracks/Technical/AI%20Hardware%20and%20Accelerator%20Engineer.md>) — designs or optimizes compute systems for AI workloads.

## 5 · Evaluation, security, safety, and assurance

- [AI Evaluation Engineer](<../04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>) — designs measurement systems and diagnoses behavior.
- [AI Security Engineer](<../04%20Role%20Tracks/Technical/AI%20Security%20Engineer.md>) — secures AI components, data flows, and integrations.
- [AI Red Teamer](<../04%20Role%20Tracks/Technical/AI%20Red%20Teamer.md>) — adversarially tests models and applications with authorization.
- [AI Trust and Safety Operations Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Trust%20and%20Safety%20Operations%20Specialist.md>) — investigates platform abuse, enforces safety policy, and improves operational controls.
- [Responsible AI Specialist](<../04%20Role%20Tracks/Nontechnical/Responsible%20AI%20Specialist.md>) — operationalizes trustworthy and responsible practices across the lifecycle.
- [Model Risk Manager](<../04%20Role%20Tracks/Nontechnical/Model%20Risk%20Manager.md>) — independently challenges and controls model risk, often in financial services.
- [AI Auditor and Assurance Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Auditor%20and%20Assurance%20Specialist.md>) — evaluates evidence against criteria and reports findings.
- [AI Ethics Researcher](<../04%20Role%20Tracks/Nontechnical/AI%20Ethics%20Researcher.md>) — analyzes normative questions, impacts, and decision frameworks.

## 6 · Product, program, strategy, and transformation

- [AI Product Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Product%20Manager.md>)
- [Technical AI Product Manager](<../04%20Role%20Tracks/Nontechnical/Technical%20AI%20Product%20Manager.md>)
- [AI Program Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Program%20Manager.md>)
- [AI Business Analyst](<../04%20Role%20Tracks/Nontechnical/AI%20Business%20Analyst.md>)
- [AI Strategy Consultant](<../04%20Role%20Tracks/Nontechnical/AI%20Strategy%20Consultant.md>)
- [AI Transformation Lead](<../04%20Role%20Tracks/Nontechnical/AI%20Transformation%20Lead.md>)
- [Chief AI Officer and Head of AI](<../04%20Role%20Tracks/Nontechnical/Chief%20AI%20Officer%20and%20Head%20of%20AI.md>) — owns enterprise AI direction, operating model, accountability, and portfolio outcomes; this is an executive destination, not an entry-level track.
- [AI Automation Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Automation%20Specialist.md>)

## 7 · Architecture, go-to-market, support, community, and education

- [AI Solutions Architect](<../04%20Role%20Tracks/Nontechnical/AI%20Solutions%20Architect.md>)
- [AI Sales Engineer](<../04%20Role%20Tracks/Nontechnical/AI%20Sales%20Engineer.md>)
- [AI Enterprise Account Executive](<../04%20Role%20Tracks/Nontechnical/AI%20Enterprise%20Account%20Executive.md>)
- [AI Product Marketing Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Product%20Marketing%20Manager.md>)
- [AI Strategic Partnerships Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Strategic%20Partnerships%20Manager.md>)
- [AI Customer Success Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Customer%20Success%20Manager.md>)
- [AI Technical Support and User Operations Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Technical%20Support%20and%20User%20Operations%20Specialist.md>)
- [AI Developer Relations and Advocate](<../04%20Role%20Tracks/Nontechnical/AI%20Developer%20Relations%20and%20Advocate.md>)
- [AI Trainer and Educator](<../04%20Role%20Tracks/Nontechnical/AI%20Trainer%20and%20Educator.md>)

## 8 · UX, conversation, and content

- [AI UX and Product Designer](<../04%20Role%20Tracks/Nontechnical/AI%20UX%20and%20Product%20Designer.md>)
- [AI UX Researcher](<../04%20Role%20Tracks/Nontechnical/AI%20UX%20Researcher.md>)
- [Conversation Designer](<../04%20Role%20Tracks/Nontechnical/Conversation%20Designer.md>)
- [AI Content Designer](<../04%20Role%20Tracks/Nontechnical/AI%20Content%20Designer.md>)
- [Prompt and Context Engineer](<../04%20Role%20Tracks/Nontechnical/Prompt%20and%20Context%20Engineer.md>) — a real function whose standalone title remains inconsistent.

## 9 · Creative and media

- [Generative AI Creative Director](<../04%20Role%20Tracks/Nontechnical/Generative%20AI%20Creative%20Director.md>)
- [AI Image and Graphic Creator](<../04%20Role%20Tracks/Nontechnical/AI%20Image%20and%20Graphic%20Creator.md>)
- [AI Video Producer](<../04%20Role%20Tracks/Nontechnical/AI%20Video%20Producer.md>)
- [AI Audio and Music Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Audio%20and%20Music%20Specialist.md>)

## 10 · Governance, policy, compliance, and privacy

- [AI Governance Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Governance%20Specialist.md>)
- [AI Policy Analyst](<../04%20Role%20Tracks/Nontechnical/AI%20Policy%20Analyst.md>)
- [AI Compliance and Privacy Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Compliance%20and%20Privacy%20Specialist.md>)

## 11 · Human data and talent operations

- [Data Annotator and AI Rater](<../04%20Role%20Tracks/Nontechnical/Data%20Annotator%20and%20AI%20Rater.md>)
- [Human Feedback Specialist](<../04%20Role%20Tracks/Nontechnical/Human-Feedback%20Specialist.md>)
- [AI Data Operations Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Data%20Operations%20Manager.md>)
- [AI Talent and Recruiting Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Talent%20and%20Recruiting%20Specialist.md>)

## Dynamic role table

[Notion Index - Role Explorer](<../Notion%20Index%20-%20Role%20Explorer.md>)

## Navigate ambiguity

- Compare title synonyms in [Job Title Crosswalk](<Job%20Title%20Crosswalk.md>).
- Compare ownership across the lifecycle in [AI System Lifecycle Map](<AI%20System%20Lifecycle%20Map.md>).
- Use [Choose Your AI Career](<../00%20Start%20Here/Choose%20Your%20AI%20Career.md>) if you are selecting a path.
- Apply [Industry Overlay Hub](<../08%20Industry%20Overlays/Industry%20Overlay%20Hub.md>) after choosing a functional role.

> **Market evidence**
> For current occupation-specific U.S. evidence, use [US Career and Governance Update — October 2026](<../10%20Research/US%20Career%20and%20Governance%20Update%20%E2%80%94%20October%202026.md>). The earlier August market synthesis remains in [August 2026 Research Brief](<../10%20Research/August%202026%20Research%20Brief.md>); do not apply an occupation’s median pay or growth rate to every AI title.
