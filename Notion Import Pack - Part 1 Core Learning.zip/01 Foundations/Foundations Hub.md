# Foundations Hub

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: hub
> **Tags:** ai-careers, foundations, hub

The goal is not equal depth for every learner. It is a shared language that lets technical and nontechnical specialists make sound decisions together.

```mermaid
flowchart TB
    A["AI systems + vocabulary"] --> B["Data + measurement"]
    B --> C["Machine learning"]
    C --> D["Deep learning + transformers"]
    D --> E["Generative systems"]
    E --> F["Prompt · context · retrieval · agents"]
    F --> G["Evaluation + operations + economics"]
    G --> H["Security · privacy · safety · responsibility"]
    H --> I["Product · UX · business · change"]
    J["Math + statistics"] --> C
    K["Python + SQL + Git + software"] --> C
```

## Modules

| # | Module | Central question |
|---:|---|---|
| 1 | [01 AI Systems and Vocabulary](<01%20AI%20Systems%20and%20Vocabulary.md>) | What is the system actually doing? |
| 2 | [02 Math and Statistics for AI](<02%20Math%20and%20Statistics%20for%20AI.md>) | How do we represent uncertainty and learning? |
| 3 | [03 Python SQL Git and Software Foundations](<03%20Python%20SQL%20Git%20and%20Software%20Foundations.md>) | How do technical teams express, connect, and control work? |
| 4 | [04 Data Foundations](<04%20Data%20Foundations.md>) | Is the evidence fit for the purpose? |
| 5 | [05 Machine Learning](<05%20Machine%20Learning.md>) | How does a model learn and generalize? |
| 6 | [06 Deep Learning](<06%20Deep%20Learning.md>) | How do neural networks learn representations? |
| 7 | [07 Transformers and Foundation Models](<07%20Transformers%20and%20Foundation%20Models.md>) | Why do modern foundation models behave as they do? |
| 8 | [08 Generative AI Systems](<08%20Generative%20AI%20Systems.md>) | How are text, images, audio, video, and code generated? |
| 9 | [09 Prompt Context and Tool Use](<09%20Prompt%20Context%20and%20Tool%20Use.md>) | How do instructions, information, and tools shape behavior? |
| 10 | [10 RAG and Knowledge Systems](<10%20RAG%20and%20Knowledge%20Systems.md>) | How do systems retrieve and ground organizational knowledge? |
| 11 | [11 Agents and Automation](<11%20Agents%20and%20Automation.md>) | How can a model plan and act safely across steps? |
| 12 | [12 Evaluation Testing and Observability](<12%20Evaluation%20Testing%20and%20Observability.md>) | How do we know it works, for whom, and under what conditions? |
| 13 | [13 Deployment MLOps and Economics](<13%20Deployment%20MLOps%20and%20Economics.md>) | How do we operate it reliably and affordably? |
| 14 | [14 Security Privacy Safety and Responsible AI](<14%20Security%20Privacy%20Safety%20and%20Responsible%20AI.md>) | How do we control harms and preserve trust? |
| 15 | [15 Product UX Business and Change](<15%20Product%20UX%20Business%20and%20Change.md>) | How does capability become a useful, adopted outcome? |

## Depth by pathway

| Pathway | Required depth |
|---|---|
| Research and engineering | Deep in 2–14; working fluency in 15 |
| Product, program, strategy | Deep in 1, 4, 8–15; conceptual + challenge questions for 2, 3, 5–7 |
| UX and creative | Deep in 1, 8, 9, 12, 14, 15; role-appropriate fluency elsewhere |
| Governance, policy, assurance | Deep in 1, 4, 12–15; enough technical depth to trace evidence and challenge claims |
| Human data and knowledge operations | Deep in 1, 4, 8–12, 14; tool-appropriate fluency in 3 |
| Customer-facing and education | Broad fluency across all; deeper in the products, architecture, and domain served |

## Assessment

Each module contains a closed-note quiz, answer explanations, and flashcards. Start with [Foundations Pretest](<../06%20Assessment%20Center/Foundations%20Pretest.md>), then use [Foundations Final Check](<../06%20Assessment%20Center/Foundations%20Final%20Check.md>) after the required modules for your pathway. Builders should then walk [Technical Skills Hub](<../12%20Technical%20Studio/Technical%20Skills%20Hub.md>) and two cases in [Technical Studio](<../12%20Technical%20Studio/Technical%20Studio.md>) before a role track.

> **Explain at two altitudes**
> For every concept, practice a precise practitioner explanation and a plain-language stakeholder explanation. AI work frequently fails at the boundary between those audiences.
