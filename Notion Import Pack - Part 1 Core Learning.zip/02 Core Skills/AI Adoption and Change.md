# AI Adoption and Change

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: skill
> **Tags:** ai-careers, core-skills, change-management

Adoption is a system outcome: usefulness × trust × access × ability × reinforcement, under real workflow constraints.

## Stakeholder map

Identify sponsors, daily users, reviewers, system/data owners, security/privacy/legal, labor/workforce representatives where relevant, support, affected non-users, and accountable leaders. Document who gains time, gains review work, loses discretion, or carries failure risk.

## Change sequence

1. baseline current work and pain;
2. involve representative users and affected groups early;
3. define allowed/prohibited use and data boundaries;
4. train on decisions and failure handling, not button clicks only;
5. provide examples, office hours, support, and escalation;
6. launch to a bounded cohort with feedback and outcome measures;
7. act visibly on failures and update materials;
8. retire old work only after evidence and continuity planning.

Resistance can signal poor product fit, added invisible labor, surveillance concerns, accessibility gaps, threatened expertise, or unclear accountability. Investigate rather than labeling it irrational.

## Metrics

Segment awareness, access, activation, repeated appropriate use, accepted task success, time/quality outcome, review burden, support demand, prohibited use, incidents, and abandonment reason.

## Quiz

1. Why is login count not adoption? 2. What should training emphasize? 3. Name two rational causes of resistance. 4. Why measure review burden?

> **Answers**
> 1. It does not show repeated appropriate use or outcomes. 2. Correct decisions, data rules, evaluation, failure recognition, escalation, and workflow—not only interface steps. 3. Added labor, poor fit, surveillance, accessibility, trust, or accountability concerns. 4. Automation may shift rather than reduce work and can undermine value or safety.

## Flashcards

Responsible adoption:: Repeated appropriate use that produces acceptable outcomes under clear rules and support.

Invisible labor:: Review, correction, data preparation, escalation, or emotional work omitted from the automation story.

Adoption cohort:: A bounded user group used to learn before broader rollout.

Next: [AI Transformation Lead](<../04%20Role%20Tracks/Nontechnical/AI%20Transformation%20Lead.md>), [AI Customer Success Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Customer%20Success%20Manager.md>), or [AI Trainer and Educator](<../04%20Role%20Tracks/Nontechnical/AI%20Trainer%20and%20Educator.md>).
