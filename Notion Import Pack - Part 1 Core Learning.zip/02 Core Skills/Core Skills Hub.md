# Core Skills Hub

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: hub
> **Tags:** ai-careers, core-skills, hub

Bridge skills connect universal foundations to daily role work. Complete the bridge recommended in [Learning Path Builder](<../00%20Start%20Here/Learning%20Path%20Builder.md>), then add only what your target postings demand.

```mermaid
mindmap
  root((AI bridge skills))
    Product and change
      Product discovery
      Economics
      Adoption
      Communication
    Human experience
      UX
      Conversation/content
      Accessibility
      Provenance/rights
    Trust
      U.S. law/policy
      Controls
      Assurance
      Threat modeling
    Knowledge and operations
      Data quality
      Knowledge architecture
      Workflow automation
      Human feedback
    Customer-facing
      Solution discovery
      Demonstration
      Enablement
```

## Product, decision, and change

- [AI Product Discovery and Delivery](<AI%20Product%20Discovery%20and%20Delivery.md>)
- [AI Economics and FinOps](<AI%20Economics%20and%20FinOps.md>)
- [AI Adoption and Change](<AI%20Adoption%20and%20Change.md>)
- [Communicating AI Decisions](<Communicating%20AI%20Decisions.md>)

## Human experience and creative operations

- [AI Interaction and UX](<AI%20Interaction%20and%20UX.md>)
- [Conversation and Content Design](<Conversation%20and%20Content%20Design.md>)
- [AI Accessibility](<AI%20Accessibility.md>)
- [Creative AI Provenance and Rights](<Creative%20AI%20Provenance%20and%20Rights.md>)

## Trust, policy, and assurance

- [US AI Law and Policy Orientation](<US%20AI%20Law%20and%20Policy%20Orientation.md>)
- [AI Risk and Control Design](<AI%20Risk%20and%20Control%20Design.md>)
- [AI Assurance Evidence](<AI%20Assurance%20Evidence.md>)
- [AI Threat Modeling](<AI%20Threat%20Modeling.md>)

## Data, knowledge, and human operations

- [Data Quality and Annotation](<Data%20Quality%20and%20Annotation.md>)
- [Knowledge Architecture](<Knowledge%20Architecture.md>)
- [Workflow Analysis and Automation](<Workflow%20Analysis%20and%20Automation.md>)
- [Human Feedback Operations](<Human%20Feedback%20Operations.md>)

## Customer-facing delivery

- [AI Solution Discovery](<AI%20Solution%20Discovery.md>)
- [AI Demonstration and Enablement](<AI%20Demonstration%20and%20Enablement.md>)

> **T-shaped depth**
> Build broad enough understanding to collaborate across the lifecycle and deep enough skill to own one outcome. Collecting shallow familiarity with every tool is not a substitute for role depth. Technical builders should add [Technical Studio](<../12%20Technical%20Studio/Technical%20Studio.md>) after the builder foundation modules; those cases practice the judgment these bridge notes describe.
