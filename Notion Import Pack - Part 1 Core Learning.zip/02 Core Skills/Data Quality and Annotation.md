# Data Quality and Annotation

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: skill
> **Tags:** ai-careers, core-skills, annotation, data-quality

Annotation converts a construct into operational judgments. The main work is definition, calibration, uncertainty, and quality—not clicking labels quickly.

## Design process

1. define task purpose, population, unit, label ontology, and prohibited use;
2. sample representative and important rare cases;
3. write rules with positive, negative, boundary, abstain, and escalation examples;
4. train and calibrate annotators;
5. run a pilot and analyze disagreement by category;
6. revise guidelines before scaling;
7. use blind overlap, gold/known cases carefully, audits, adjudication, and drift checks;
8. document versions, worker conditions, provenance, and limitations.

## Quality signals

Agreement can reveal consistency but is not truth. Measure guideline violations, adjudication rate, class balance, response patterns, slice coverage, time anomalies, expert review, and downstream utility. Protect workers from harmful content with informed task design, breaks, support, exposure limits, and escalation.

## Quiz

1. Why include an abstain label? 2. What can disagreement reveal? 3. Why pilot before scale? 4. Why can gold cases be misleading?

> **Answers**
> 1. Some cases are unknowable, out of scope, or require expertise; forced labels add noise/harm. 2. Ambiguity, multiple valid views, poor rules, missing context, or uneven expertise. 3. To repair construct and guideline failures before they multiply. 4. Their answers may be disputable, memorized, unrepresentative, or leak.

## Flashcards

Annotation guideline:: Versioned operational rules turning a construct into decisions with boundaries and escalation.

Adjudication:: A process for resolving disputed or ambiguous labels.

Inter-annotator agreement:: A consistency measure whose interpretation depends on task, prevalence, and method.

Next: [Data Annotator and AI Rater](<../04%20Role%20Tracks/Nontechnical/Data%20Annotator%20and%20AI%20Rater.md>), [Human Feedback Specialist](<../04%20Role%20Tracks/Nontechnical/Human-Feedback%20Specialist.md>), and [AI Data Operations Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Data%20Operations%20Manager.md>).
