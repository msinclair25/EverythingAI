# AI Product Discovery and Delivery

> **Metadata:** Scope: United States · Level: intermediate, advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: skill
> **Tags:** ai-careers, core-skills, product

AI product work converts uncertain capability into a measurable, controlled user outcome.

## Core method

1. Observe the current job, decision, workarounds, failure cost, and baseline.
2. Separate desirability, feasibility, viability, usability, and responsibility assumptions.
3. Choose the least complex intervention; include non-AI alternatives.
4. Write an evaluation contract before the prototype: users, cases, metrics, slices, thresholds, stop criteria.
5. Prototype the riskiest assumption—not the most impressive screen.
6. Design review, escalation, recovery, monitoring, and retirement with the happy path.
7. Stage rollout and connect adoption to acceptable outcomes.

## AI product artifacts

- problem statement and baseline;
- system boundary and ownership map;
- capability/risk assumptions;
- representative evaluation set and release criteria;
- model/data/tool decision record;
- UX states for uncertainty, refusal, review, and failure;
- cost/value model and launch/rollback plan;
- system card and post-launch learning log.

> **Demo-to-product gap**
> A prototype shows possibility under selected conditions. A product must perform for real users under distribution change, misuse, outages, cost limits, legal constraints, and support obligations.

## Quiz

1. What should a prototype test first? 2. Why write evaluation criteria before model selection? 3. Name four non-happy-path UX states. 4. What connects adoption to value?

> **Answers**
> 1. The highest-risk assumption. 2. It prevents capability theater and anchors selection to the real task. 3. Uncertainty, refusal, error, escalation, recovery, permission denial, or source conflict. 4. Demonstrated acceptable task success leading to an operational outcome, net of cost and risk.

## Flashcards

AI product hypothesis:: A testable link between a user/workflow change, acceptable AI behavior, and measurable outcome.

Release criterion:: A pre-defined evidence threshold and stop condition for moving a system to broader use.

Demo-to-product gap:: The reliability, evaluation, UX, security, operations, governance, and support work between a selected demonstration and durable value.

Next: [AI Product Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Product%20Manager.md>), [Technical AI Product Manager](<../04%20Role%20Tracks/Nontechnical/Technical%20AI%20Product%20Manager.md>), or [AI Program Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Program%20Manager.md>).
