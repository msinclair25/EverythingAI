# AI Solution Discovery

> **Metadata:** Scope: United States · Level: intermediate, advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: skill
> **Tags:** ai-careers, core-skills, solutions, discovery

Solution discovery converts customer language into a testable problem, architecture, success plan, and honest gap list.

## Discovery map

Ask about users, current workflow, baseline metrics, data location/rights/quality, integrations and systems of record, latency/volume, security/privacy/compliance, accessibility, deployment constraints, decision consequence, evaluation cases, buying process, timeline, change capacity, support, and exit.

## Proof-of-value contract

Define hypotheses, representative data, allowed environment, success and failure metrics, comparison baseline, roles, security/data terms, duration, costs, exclusions, deliverables, stop criteria, and what is **not** proven. Avoid a curated demo that cannot survive customer data or process variance.

## Architecture communication

Separate confirmed requirement, assumption, product capability, configuration, custom work, partner dependency, roadmap item, and unknown. Never present roadmap as current capability or a prototype as production commitment.

## Quiz

1. Why ask about the current baseline? 2. What should a proof of value not claim? 3. Why identify systems of record? 4. How should roadmap features be described?

> **Answers**
> 1. It quantifies incremental value and alternative cost. 2. Broad production readiness beyond its data/scope. 3. Integration, authority, writes, reconciliation, and failure recovery depend on them. 4. Explicitly as uncommitted/currently unavailable according to official policy—not existing capability.

## Flashcards

Proof of value:: A bounded test of business/user value and feasibility against agreed evidence.

Solution gap:: A documented difference between requirement and current supported capability.

Discovery assumption:: An unverified belief that can change architecture, value, risk, or timeline.

Next: [AI Solutions Architect](<../04%20Role%20Tracks/Nontechnical/AI%20Solutions%20Architect.md>), [AI Sales Engineer](<../04%20Role%20Tracks/Nontechnical/AI%20Sales%20Engineer.md>), and [AI Customer Success Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Customer%20Success%20Manager.md>).
