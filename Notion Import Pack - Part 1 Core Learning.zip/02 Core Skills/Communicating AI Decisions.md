# Communicating AI Decisions

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: skill
> **Tags:** ai-careers, core-skills, communication

Strong AI communication is calibrated: precise enough for action, plain enough for the audience, and explicit about evidence and uncertainty.

## Decision brief structure

1. **Decision requested** and owner.
2. **Problem and baseline** with affected users.
3. **Options**, including non-AI and do-nothing.
4. **Evidence**: sample, system version, metrics, slices, uncertainty, limitations.
5. **Tradeoffs**: quality, cost, latency, safety, privacy, accessibility, portability.
6. **Recommendation** with conditions and dissent.
7. **Controls and residual risk** with accountable owner.
8. **Next checkpoint** and reversal plan.

Avoid “the AI understands,” “bias-free,” “fully autonomous,” and “95% accurate” without construct, population, threshold, and consequence. Separate fact, model output, inference, forecast, and value judgment.

## Two-altitude explanation

- **Executive:** outcome, evidence, material tradeoff, risk owner, decision.
- **Practitioner:** architecture, data, evaluation design, failure analysis, controls, operational detail.

Both must tell the same truth.

## Quiz

1. Why include a non-AI option? 2. What context must accompany an accuracy number? 3. Distinguish uncertainty from ambiguity. 4. What is residual-risk ownership?

> **Answers**
> 1. It establishes incremental value and prevents solution lock-in. 2. Task, population, dataset, threshold, metric, time, slices, uncertainty, and error consequences. 3. Uncertainty is limited confidence/knowledge; ambiguity allows multiple interpretations. 4. An authorized named person accepts responsibility for risk remaining after controls and response.

## Flashcards

Decision brief:: A concise record of decision, options, evidence, tradeoffs, recommendation, controls, owner, and next checkpoint.

Calibrated language:: Wording whose confidence and specificity match the evidence.

Two-altitude explanation:: Consistent executive and practitioner versions of the same decision.

Use [Decision Record Template](<../09%20Templates/Decision%20Record%20Template.md>) and [AI Interview Playbook](<../07%20Interview%20and%20Portfolio/AI%20Interview%20Playbook.md>).
