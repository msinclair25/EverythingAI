# Everything AI — Notion import

Generated 2026-10-14 from the Obsidian vault. The Obsidian vault remains the source of truth.

**Pack:** Part 1 - Core Learning
**Import set:** Part 1 of 3. Import all parts for full content coverage. Cross-part links may need manual repair after separate imports; use the full pack when practical.

## Start here

- [Everything AI Home](<00%20Start%20Here/Everything%20AI%20-%20Home.md>)
- [Note catalog database](Notion%20Note%20Catalog.csv)

## Import

1. In Notion, open Settings → Import → ZIP, or use the /zip command.
2. Upload this ZIP and choose Convert Zip to pages.
3. Import the CSV separately if you want a searchable Notion database of notes.
4. Open Everything AI Home and use the linked route. Notion does not preserve Obsidian Bases, Canvas files, or anchor links, so static replacements are included.

## Known differences

- Wikilinks become ordinary Markdown links; heading anchors become page links or readable text.
- Obsidian callouts become bold-labeled Markdown blockquotes.
- Mermaid diagrams remain Mermaid code blocks. Render them separately or replace them with Notion images if you want visual diagrams.
- Bases become static Role Explorer and Source Review pages.
- Canvas becomes a linked Markdown landscape page.
- CSS, frontmatter, comments, and Obsidian-only embeds are converted or omitted.

