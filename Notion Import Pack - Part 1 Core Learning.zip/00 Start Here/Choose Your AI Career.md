# Choose Your AI Career

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: guide
> **Tags:** ai-careers, career-choice, learning-path

Choose by the **work you want to repeat**, not by whichever title is fashionable. Then verify your fit against actual job descriptions.

## Fast router

```mermaid
flowchart TD
    A{"What result do you most want to own?"}
    A -->|"New knowledge or model methods"| R["Research & applied science"]
    A -->|"Working AI software"| B{"Where in the stack?"}
    A -->|"A valuable, adopted product"| P["Product, program & transformation"]
    A -->|"A usable human experience"| U["UX, conversation & content design"]
    A -->|"Trust, legality, or control"| G["Governance, risk, policy & assurance"]
    A -->|"Revenue or customer outcomes"| S["Solutions, sales, success & DevRel"]
    A -->|"Images, video, audio, or stories"| C["Creative AI"]
    A -->|"Reliable data or human feedback"| H["Data operations, rating & knowledge"]
    B -->|"Model behavior and features"| E["AI/ML application engineering"]
    B -->|"Data and retrieval"| D["Data, RAG & knowledge engineering"]
    B -->|"Deployment and infrastructure"| O["MLOps, platform, inference & hardware"]
    B -->|"Break, measure, and protect"| T["Evaluation, safety & security"]
```

## Match your preferred work

| You enjoy… | Start with… | Also compare… |
|---|---|---|
| experiments, papers, uncertainty, new methods | [AI ML Research Scientist](<../04%20Role%20Tracks/Technical/AI%20ML%20Research%20Scientist.md>), [Applied Scientist](<../04%20Role%20Tracks/Technical/Applied%20Scientist.md>) | [Research Engineer](<../04%20Role%20Tracks/Technical/Research%20Engineer.md>), [AI Safety and Alignment Researcher](<../04%20Role%20Tracks/Technical/AI%20Safety%20and%20Alignment%20Researcher.md>) |
| shipping model-powered product features | [AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>), [ML Engineer](<../04%20Role%20Tracks/Technical/ML%20Engineer.md>) | [LLM Engineer](<../04%20Role%20Tracks/Technical/LLM%20Engineer.md>), [Agentic AI Engineer](<../04%20Role%20Tracks/Technical/Agentic%20AI%20Engineer.md>) |
| reliable data pipelines and knowledge systems | [ML Data Engineer](<../04%20Role%20Tracks/Technical/ML%20Data%20Engineer.md>), [RAG and Knowledge Engineer](<../04%20Role%20Tracks/Technical/RAG%20and%20Knowledge%20Engineer.md>) | [Taxonomist and Ontology Specialist](<../04%20Role%20Tracks/Nontechnical/Taxonomist%20and%20Ontology%20Specialist.md>), [Knowledge Manager](<../04%20Role%20Tracks/Nontechnical/Knowledge%20Manager.md>) |
| deployment, scaling, cost, latency, reliability | [MLOps Engineer](<../04%20Role%20Tracks/Technical/MLOps%20Engineer.md>), [AI Platform Engineer](<../04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>) | [Inference and Performance Engineer](<../04%20Role%20Tracks/Technical/Inference%20and%20Performance%20Engineer.md>), [AI Hardware and Accelerator Engineer](<../04%20Role%20Tracks/Technical/AI%20Hardware%20and%20Accelerator%20Engineer.md>) |
| attacks, defenses, misuse cases, threat models | [AI Security Engineer](<../04%20Role%20Tracks/Technical/AI%20Security%20Engineer.md>), [AI Red Teamer](<../04%20Role%20Tracks/Technical/AI%20Red%20Teamer.md>) | [Responsible AI Specialist](<../04%20Role%20Tracks/Nontechnical/Responsible%20AI%20Specialist.md>), [AI Evaluation Engineer](<../04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>) |
| metrics, test design, failure analysis | [AI Evaluation Engineer](<../04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>) | [AI Auditor and Assurance Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Auditor%20and%20Assurance%20Specialist.md>), [Model Risk Manager](<../04%20Role%20Tracks/Nontechnical/Model%20Risk%20Manager.md>) |
| deciding what to build and why | [AI Product Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Product%20Manager.md>) | [Technical AI Product Manager](<../04%20Role%20Tracks/Nontechnical/Technical%20AI%20Product%20Manager.md>), [AI Business Analyst](<../04%20Role%20Tracks/Nontechnical/AI%20Business%20Analyst.md>) |
| coordinating complex adoption | [AI Program Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Program%20Manager.md>), [AI Transformation Lead](<../04%20Role%20Tracks/Nontechnical/AI%20Transformation%20Lead.md>) | [AI Strategy Consultant](<../04%20Role%20Tracks/Nontechnical/AI%20Strategy%20Consultant.md>), [AI Automation Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Automation%20Specialist.md>) |
| systems thinking with customers | [AI Solutions Architect](<../04%20Role%20Tracks/Nontechnical/AI%20Solutions%20Architect.md>), [AI Sales Engineer](<../04%20Role%20Tracks/Nontechnical/AI%20Sales%20Engineer.md>) | [AI Customer Success Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Customer%20Success%20Manager.md>), [AI Developer Relations and Advocate](<../04%20Role%20Tracks/Nontechnical/AI%20Developer%20Relations%20and%20Advocate.md>) |
| revenue, positioning, or ecosystem deals | [AI Enterprise Account Executive](<../04%20Role%20Tracks/Nontechnical/AI%20Enterprise%20Account%20Executive.md>), [AI Product Marketing Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Product%20Marketing%20Manager.md>) | [AI Strategic Partnerships Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Strategic%20Partnerships%20Manager.md>), [AI Sales Engineer](<../04%20Role%20Tracks/Nontechnical/AI%20Sales%20Engineer.md>) |
| customer questions, incidents, or platform abuse | [AI Technical Support and User Operations Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Technical%20Support%20and%20User%20Operations%20Specialist.md>), [AI Trust and Safety Operations Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Trust%20and%20Safety%20Operations%20Specialist.md>) | [AI Customer Success Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Customer%20Success%20Manager.md>), [Responsible AI Specialist](<../04%20Role%20Tracks/Nontechnical/Responsible%20AI%20Specialist.md>) |
| enterprise AI executive ownership | [Chief AI Officer and Head of AI](<../04%20Role%20Tracks/Nontechnical/Chief%20AI%20Officer%20and%20Head%20of%20AI.md>) | [AI Transformation Lead](<../04%20Role%20Tracks/Nontechnical/AI%20Transformation%20Lead.md>), [AI Program Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Program%20Manager.md>), [AI Governance Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Governance%20Specialist.md>) |
| human behavior and interaction design | [AI UX and Product Designer](<../04%20Role%20Tracks/Nontechnical/AI%20UX%20and%20Product%20Designer.md>), [AI UX Researcher](<../04%20Role%20Tracks/Nontechnical/AI%20UX%20Researcher.md>) | [Conversation Designer](<../04%20Role%20Tracks/Nontechnical/Conversation%20Designer.md>), [AI Content Designer](<../04%20Role%20Tracks/Nontechnical/AI%20Content%20Designer.md>) |
| rapid workflow improvement with little code | [AI Automation Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Automation%20Specialist.md>) | [AI Business Analyst](<../04%20Role%20Tracks/Nontechnical/AI%20Business%20Analyst.md>), [Prompt and Context Engineer](<../04%20Role%20Tracks/Nontechnical/Prompt%20and%20Context%20Engineer.md>) |
| making visual, video, voice, or music work | [Generative AI Creative Director](<../04%20Role%20Tracks/Nontechnical/Generative%20AI%20Creative%20Director.md>) | [AI Image and Graphic Creator](<../04%20Role%20Tracks/Nontechnical/AI%20Image%20and%20Graphic%20Creator.md>), [AI Video Producer](<../04%20Role%20Tracks/Nontechnical/AI%20Video%20Producer.md>), [AI Audio and Music Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Audio%20and%20Music%20Specialist.md>) |
| policy, control design, documentation, evidence | [AI Governance Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Governance%20Specialist.md>), [AI Policy Analyst](<../04%20Role%20Tracks/Nontechnical/AI%20Policy%20Analyst.md>) | [AI Compliance and Privacy Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Compliance%20and%20Privacy%20Specialist.md>), [AI Auditor and Assurance Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Auditor%20and%20Assurance%20Specialist.md>) |
| labeling, rating, feedback quality, operations | [Data Annotator and AI Rater](<../04%20Role%20Tracks/Nontechnical/Data%20Annotator%20and%20AI%20Rater.md>), [Human Feedback Specialist](<../04%20Role%20Tracks/Nontechnical/Human-Feedback%20Specialist.md>) | [AI Data Operations Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Data%20Operations%20Manager.md>), [Synthetic Data Engineer](<../04%20Role%20Tracks/Technical/Synthetic%20Data%20Engineer.md>) |
| teaching and community enablement | [AI Trainer and Educator](<../04%20Role%20Tracks/Nontechnical/AI%20Trainer%20and%20Educator.md>) | [AI Developer Relations and Advocate](<../04%20Role%20Tracks/Nontechnical/AI%20Developer%20Relations%20and%20Advocate.md>), [AI Talent and Recruiting Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Talent%20and%20Recruiting%20Specialist.md>) |

## Match your starting background

> **No technical background yet**
> Start with [01 AI Systems and Vocabulary](<../01%20Foundations/01%20AI%20Systems%20and%20Vocabulary.md>), [08 Generative AI Systems](<../01%20Foundations/08%20Generative%20AI%20Systems.md>), [12 Evaluation Testing and Observability](<../01%20Foundations/12%20Evaluation%20Testing%20and%20Observability.md>), and [15 Product UX Business and Change](<../01%20Foundations/15%20Product%20UX%20Business%20and%20Change.md>). Strong first comparisons: [AI Business Analyst](<../04%20Role%20Tracks/Nontechnical/AI%20Business%20Analyst.md>), [AI Automation Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Automation%20Specialist.md>), [AI Product Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Product%20Manager.md>), [Conversation Designer](<../04%20Role%20Tracks/Nontechnical/Conversation%20Designer.md>), [AI Trainer and Educator](<../04%20Role%20Tracks/Nontechnical/AI%20Trainer%20and%20Educator.md>), [Data Annotator and AI Rater](<../04%20Role%20Tracks/Nontechnical/Data%20Annotator%20and%20AI%20Rater.md>), and governance roles. Technical roles remain open; add [03 Python SQL Git and Software Foundations](<../01%20Foundations/03%20Python%20SQL%20Git%20and%20Software%20Foundations.md>) and [02 Math and Statistics for AI](<../01%20Foundations/02%20Math%20and%20Statistics%20for%20AI.md>).

> **Software engineer**
> Bridge through [05 Machine Learning](<../01%20Foundations/05%20Machine%20Learning.md>), [07 Transformers and Foundation Models](<../01%20Foundations/07%20Transformers%20and%20Foundation%20Models.md>), [09 Prompt Context and Tool Use](<../01%20Foundations/09%20Prompt%20Context%20and%20Tool%20Use.md>), [10 RAG and Knowledge Systems](<../01%20Foundations/10%20RAG%20and%20Knowledge%20Systems.md>), [12 Evaluation Testing and Observability](<../01%20Foundations/12%20Evaluation%20Testing%20and%20Observability.md>), and [13 Deployment MLOps and Economics](<../01%20Foundations/13%20Deployment%20MLOps%20and%20Economics.md>). Compare [AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>), [ML Engineer](<../04%20Role%20Tracks/Technical/ML%20Engineer.md>), [Agentic AI Engineer](<../04%20Role%20Tracks/Technical/Agentic%20AI%20Engineer.md>), [AI Platform Engineer](<../04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>), and [AI Security Engineer](<../04%20Role%20Tracks/Technical/AI%20Security%20Engineer.md>).

> **Analyst, scientist, or quantitative professional**
> Add [04 Data Foundations](<../01%20Foundations/04%20Data%20Foundations.md>), [05 Machine Learning](<../01%20Foundations/05%20Machine%20Learning.md>), causal and experimental thinking, SQL/Python, and evaluation. Compare [Data Scientist - AI ML](<../04%20Role%20Tracks/Technical/Data%20Scientist%20-%20AI%20ML.md>), [Applied Scientist](<../04%20Role%20Tracks/Technical/Applied%20Scientist.md>), [AI Evaluation Engineer](<../04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>), [AI Business Analyst](<../04%20Role%20Tracks/Nontechnical/AI%20Business%20Analyst.md>), and [Model Risk Manager](<../04%20Role%20Tracks/Nontechnical/Model%20Risk%20Manager.md>).

> **Designer, writer, or creator**
> Add [AI Interaction and UX](<../02%20Core%20Skills/AI%20Interaction%20and%20UX.md>), multimodal model literacy, evaluation, provenance, accessibility, and U.S. copyright basics. Compare design, conversation, content, and creative-media roles.

> **Product, operations, consulting, or leadership**
> Add [AI Product Discovery and Delivery](<../02%20Core%20Skills/AI%20Product%20Discovery%20and%20Delivery.md>), workflow analysis, adoption measurement, economics, governance, and enough architecture to challenge assumptions. Compare product, program, strategy, transformation, solutions, automation, go-to-market, support, trust-and-safety operations, and executive-ownership roles. [Chief AI Officer and Head of AI](<../04%20Role%20Tracks/Nontechnical/Chief%20AI%20Officer%20and%20Head%20of%20AI.md>) is a senior destination reached through substantial operating leadership, not a first AI job.

> **Legal, risk, audit, privacy, or public policy**
> Add [14 Security Privacy Safety and Responsible AI](<../01%20Foundations/14%20Security%20Privacy%20Safety%20and%20Responsible%20AI.md>), [US AI Law and Policy Orientation](<../02%20Core%20Skills/US%20AI%20Law%20and%20Policy%20Orientation.md>), model/data lifecycle literacy, control testing, and evidence design. Compare governance, responsible AI, compliance/privacy, model risk, assurance, ethics, and policy roles.

## Three-posting test

Before committing to a title:

1. Collect three current U.S. postings from different employers.
2. Ignore the title; highlight deliverables, decisions, stakeholders, minimum evidence, and tool categories.
3. Map each to [Job Title Crosswalk](<../03%20Career%20Map/Job%20Title%20Crosswalk.md>).
4. Choose the role profile that covers at least two-thirds of the recurring work.
5. Put employer-specific tools in a small gap list; do not rebuild your whole curriculum around one posting.

## If you are split between two roles

Pick a **primary role** that owns the outcome and a **secondary edge** that differentiates you. Useful combinations include:

- AI Product Manager + evaluation
- AI Engineer + security
- RAG and Knowledge Engineer + ontology
- AI UX Designer + conversation design
- AI Governance Specialist + technical evaluation
- Creative Director + provenance and copyright operations
- AI Sales Engineer + a regulated-industry overlay

Next: [Learning Path Builder](<Learning%20Path%20Builder.md>).
