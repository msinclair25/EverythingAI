# Everything AI

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: release-3 · Verified: 2026-10-13 · Review by: 2026-10-27 · Type: hub
> **Tags:** ai-careers, hub, learning-path
> **Aliases:** Home, Start Here, Everything AI

> **Learn the field. Choose a role. Build evidence. Prepare for the interview.**
> A U.S.-focused, beginner-to-advanced learning vault for the major job functions in the AI economy. Latest research refresh: **October 13, 2026**. Individual notes retain their own verification scope and dates.

> **A living field**
> AI titles are not standardized. Employers frequently rename or combine jobs. This vault maps work by **function**, then supplies title aliases so you can recognize the same work in job postings. See [Coverage, Evidence, and Limits](<Coverage%2C%20Evidence%2C%20and%20Limits.md>).

## Vault inventory · 2026-10-13

| Material | Included |
|---|---:|
| Obsidian Markdown notes | 235 |
| Full role tracks | 63 |
| Foundations + bridge-skill modules | 33 |
| Technical concept notes | 16 (frozen) |
| Technical studio cases + drills | 12 + 10 |
| Tool categories | 22 |
| U.S. industry overlays | 10 (3 teaching-length) |
| Flashcards | 1052 |
| Notes with quizzes or knowledge checks | 145 |
| Mermaid diagrams + interactive Canvas | 148 + 1 |

Counts describe the current vault inventory, not an official census of AI occupations. Role coverage follows the functional method in [Coverage, Evidence, and Limits](<Coverage%2C%20Evidence%2C%20and%20Limits.md>). Studio cases are teaching scenarios, not measured deployments.

Reproduce structural counts with `ruby scripts/validate_vault.rb`. Cards count non-code question/answer lines; checks count explicit quiz/knowledge-check headings. Counts are inventory, not a claim of unique or independently validated assessment items.

## Current update · 2026-10-13

Start with [October 2026 Research Refresh](<../10%20Research/October%202026%20Research%20Refresh.md>) for the source ledger, corrections, and honest review limits.

| Study layer | What you will learn |
|---|---|
| [Model and Agent Lifecycle Management](<../05%20Tool%20Atlas/Model%20and%20Agent%20Lifecycle%20Management.md>) | Provider and hosted-service retirements, paired evaluation, migration and safe fallback |
| [Cloud AI Operations — October 2026](<../05%20Tool%20Atlas/Cloud%20AI%20Operations%20%E2%80%94%20October%202026.md>) | Foundry maturity, Azure DevOps federation, AWS identity, and cloud role ownership |
| [MCP Contract Testing and Upgrade Readiness](<../05%20Tool%20Atlas/MCP%20Contract%20Testing%20and%20Upgrade%20Readiness.md>) | Compatibility, authorization, retry ambiguity, and application state |
| [Case - Agent Memory Incident](<../12%20Technical%20Studio/Case%20-%20Agent%20Memory%20Incident.md>) | Containment, provenance, durable-state repair, and recovery evidence |
| [Case - Routing Quality and Capacity](<../12%20Technical%20Studio/Case%20-%20Routing%20Quality%20and%20Capacity.md>) | Classifiers, admission control, high-risk recall, and cost per successful task |
| [Technical Role Practice Workbook — October 2026](<../12%20Technical%20Studio/Technical%20Role%20Practice%20Workbook%20%E2%80%94%20October%202026.md>) | A distinct decision, artifact, and reviewer challenge for all 23 technical roles |
| [US Career and Governance Update — October 2026](<../10%20Research/US%20Career%20and%20Governance%20Update%20%E2%80%94%20October%202026.md>) | Updated BLS context and practical exercises for nontechnical/hybrid roles |
| [AI Change Impact Review Template](<../09%20Templates/AI%20Change%20Impact%20Review%20Template.md>) | A reusable record of source status, tests, release decisions, and uncertainty |

All 63 role profiles link to the new learning layer. The OWASP dossier's LLM edition, IDs, and flashcards have been corrected to the canonical 2025 taxonomy; Agentic 2026 remains separate. Older prices, legal tables, and job-market claims are not silently restamped.

## Previous update · 2026-08-24

| Added | What it gives you |
|---|---|
| Visual and language polish · 2026-08-25 | A calmer reading width, clearer hierarchy, more consistent table/callout rhythm, responsive sizing, and an explicit route through the AI infrastructure/DevOps section |
| [Notion Import Guide](<../Notion%20Import%20Guide.md>) | Notion-ready derivative: full and split ZIP packs, standard Markdown links/callouts, copied visuals, static Base/Canvas replacements, and a CSV note catalog |
| [AI Tools and Practices Update — 2026-08-24](<../10%20Research/AI%20Tools%20and%20Practices%20Update%20%E2%80%94%202026-08-24.md>) | Eight transferable technical practices, current protocol/API/evaluation signals, role-specific evidence, a 10-question knowledge check, 12 flashcards, and four project briefs |
| Technical role overlays | All 23 technical profiles now include an August 24 practice checkpoint linked to the update layer |
| [Tool Atlas — 2026-08-24 Update](<../05%20Tool%20Atlas/Tool%20Atlas%20%E2%80%94%202026-08-24%20Update.md>) | Current free/open versus managed tool paths, a 90-minute proof-of-concept protocol, a reusable tool card, and a decision rubric |
| [Microsoft Azure DevOps and Foundry](<../05%20Tool%20Atlas/Microsoft%20Azure%20DevOps%20and%20Foundry.md>) | Azure delivery layer: DevOps work/review/pipelines/environments plus Foundry hosted agents, MCP/Toolboxes, WIF, evaluation gates, traces, and rollback |
| [Case - Azure DevOps Foundry Release Gate](<../12%20Technical%20Studio/Case%20-%20Azure%20DevOps%20Foundry%20Release%20Gate.md>) | Worked release decision for a synthetic claims agent, with identities, thresholds, failure injects, quiz, flashcards, and interview transfer |
| [Azure DevOps Foundry Release Dossier Template](<../09%20Templates/Azure%20DevOps%20Foundry%20Release%20Dossier%20Template.md>) | Reusable release evidence record for identities, pipeline gates, MCP/Toolbox review, staging traces, approval, and rollback |
| [Cloudflare and Vercel AI](<../05%20Tool%20Atlas/Cloudflare%20and%20Vercel%20AI.md>) | Current edge/web AI platform comparison: Workers AI, Agents, AI Gateway, AI Search, Workflows, AI SDK 7, WorkflowAgent, Sandbox, Connect, and Fluid Compute |
| [Case - Edge AI Platform Choice](<../12%20Technical%20Studio/Case%20-%20Edge%20AI%20Platform%20Choice.md>) | Worked Cloudflare/Vercel decision for a multi-tenant agent with retrieval, approvals, generated-code isolation, budgets, fallback, and cross-platform traces |
| [AI Expansion Atlas — 2026-08-24](<../05%20Tool%20Atlas/AI%20Expansion%20Atlas%20%E2%80%94%202026-08-24.md>) | Twelve next-wave domains: agent interoperability, AI SRE, on-device/private AI, provenance, reasoning compute, document intelligence, privacy, sustainability, coding agents, physical AI, AI for science, and realtime interaction |
| [MCP Deep Dive — 2026-08-24](<../05%20Tool%20Atlas/MCP%20Deep%20Dive%20%E2%80%94%202026-08-24.md>) | End-to-end MCP study layer: 2026 protocol migration, primitives, transports, OAuth, security, conformance, operations, quizzes, flashcards, and projects |
| [AI DevOps and Cloud Engineering — 2026-08-24](<../05%20Tool%20Atlas/AI%20DevOps%20and%20Cloud%20Engineering%20%E2%80%94%202026-08-24.md>) | AI × DevOps/cloud engineering track: delivery lifecycle, cloud comparison, IaC, OIDC/WIF, evaluation gates, Kubernetes, observability, supply chain, FinOps, role practice, projects, interview prep, quiz, and flashcards |
| [OWASP and AI Security — 2026](<../05%20Tool%20Atlas/OWASP%20and%20AI%20Security%20%E2%80%94%202026.md>) | Deep LLM/Agentic Top 10 study layer with data security, secure MCP, AIBOM, COMPASS, control stack, quizzes, flashcards, and projects |
| [Case - OWASP Agentic Security Review](<../12%20Technical%20Studio/Case%20-%20OWASP%20Agentic%20Security%20Review.md>) | Worked OWASP pilot decision with injection, identity, tool, memory, MCP, output, denial-of-wallet, recovery, and release gates |
| Research refresh | Official documentation checked for MCP, OpenAI Agents SDK, Gemini Interactions and caching, Microsoft Foundry, vLLM, OpenTelemetry GenAI conventions, and NIST TEVV |

> **Start with the newest layer**
> Use the dated update notes for volatile tools and practices, then return to the stable role tracks and concept spine. Keep older dated notes as evidence of what was true at the time instead of erasing the learning trail.

> **If you are pursuing AI infrastructure, DevOps, or cloud engineering**
> Follow [AI DevOps and Cloud Engineering — 2026-08-24](<../05%20Tool%20Atlas/AI%20DevOps%20and%20Cloud%20Engineering%20%E2%80%94%202026-08-24.md>) → [Microsoft Azure DevOps and Foundry](<../05%20Tool%20Atlas/Microsoft%20Azure%20DevOps%20and%20Foundry.md>) or [Cloudflare and Vercel AI](<../05%20Tool%20Atlas/Cloudflare%20and%20Vercel%20AI.md>) → [Case - Azure DevOps Foundry Release Gate](<../12%20Technical%20Studio/Case%20-%20Azure%20DevOps%20Foundry%20Release%20Gate.md>) or [Case - Edge AI Platform Choice](<../12%20Technical%20Studio/Case%20-%20Edge%20AI%20Platform%20Choice.md>) → [Technical Interview Drills](<../12%20Technical%20Studio/Technical%20Interview%20Drills.md>). This route moves from system boundaries to delivery evidence, then to a provider-specific case and interview transfer.

## Start in three steps

1. Read [How to Use This Vault](<How%20to%20Use%20This%20Vault.md>).
2. Take the [AI Career Diagnostic](<../06%20Assessment%20Center/AI%20Career%20Diagnostic.md>) or use [Choose Your AI Career](<Choose%20Your%20AI%20Career.md>).
3. Generate your route with [Learning Path Builder](<Learning%20Path%20Builder.md>) or the [Builder 4-Week Syllabus](<Builder%204-Week%20Syllabus.md>), then open a role profile in [AI Career Atlas](<../03%20Career%20Map/AI%20Career%20Atlas.md>). Builders should complete [Technical Skills Hub](<../12%20Technical%20Studio/Technical%20Skills%20Hub.md>) and two cases in [Technical Studio](<../12%20Technical%20Studio/Technical%20Studio.md>) before treating a role track as complete.

```mermaid
flowchart TB
    A["Orient"] --> B["Diagnose"]
    B --> C["Universal foundations"]
    C --> D["Bridge skills"]
    D --> E["Role track"]
    E --> F["Suggested projects"]
    F --> G["Interview preparation"]
    G --> H["Apply + keep learning"]
```

## The vault

| Area | Use it for |
|---|---|
| [Foundations Hub](<../01%20Foundations/Foundations%20Hub.md>) | AI literacy through production-system concepts |
| [Core Skills Hub](<../02%20Core%20Skills/Core%20Skills%20Hub.md>) | Transferable practice: prompting, research, evaluation, communication, and workflow design |
| [Technical Studio](<../12%20Technical%20Studio/Technical%20Studio.md>) | Frozen 16 concepts + jargon, then worked cases |
| [Visual Maps Hub](<../11%20Visual%20Maps/Visual%20Maps%20Hub.md>) | Infographics for the builder path, spine, and RAG autopsy |
| [AI Career Atlas](<../03%20Career%20Map/AI%20Career%20Atlas.md>) | Role families, profiles, title aliases, and adjacent-role boundaries |
| [AI Tool Atlas](<../05%20Tool%20Atlas/AI%20Tool%20Atlas.md>) | Free-first and paid tool choices by job and task |
| [Assessment Center](<../06%20Assessment%20Center/Assessment%20Center.md>) | Diagnostic quizzes, answer keys, flashcards, and readiness checks |
| [Interview and Portfolio Hub](<../07%20Interview%20and%20Portfolio/Interview%20and%20Portfolio%20Hub.md>) | Interview patterns, question banks, portfolio strategy, and project selection |
| [Industry Overlay Hub](<../08%20Industry%20Overlays/Industry%20Overlay%20Hub.md>) | What changes in healthcare, finance, government, education, manufacturing, and other U.S. sectors |
| [AI Glossary](<../AI%20Glossary.md>) | Plain-language vocabulary and acronyms |
| [Research Method and Source Policy](<../10%20Research/Research%20Method%20and%20Source%20Policy.md>) | How information was selected, dated, and verified |

## Choose a depth

> **Explorer — 8–15 hours**
> Learn [01 AI Systems and Vocabulary](<../01%20Foundations/01%20AI%20Systems%20and%20Vocabulary.md>), [08 Generative AI Systems](<../01%20Foundations/08%20Generative%20AI%20Systems.md>), [12 Evaluation Testing and Observability](<../01%20Foundations/12%20Evaluation%20Testing%20and%20Observability.md>), and [14 Security Privacy Safety and Responsible AI](<../01%20Foundations/14%20Security%20Privacy%20Safety%20and%20Responsible%20AI.md>), then survey three role profiles.

> **Career switcher — 80–180 hours**
> Complete universal foundations, your bridge modules, one role profile, its flashcards and quiz, two suggested projects, and the appropriate interview pathway.

> **Advanced practitioner — targeted**
> Use the diagnostic to skip mastered material. Concentrate on architecture, evaluation, reliability, security, economics, governance, and the advanced sections of your role profile.

## Visual navigation

- [Visual Maps Hub](<../11%20Visual%20Maps/Visual%20Maps%20Hub.md>)
- Open the visual AI career landscape
- [AI System Lifecycle Map](<../03%20Career%20Map/AI%20System%20Lifecycle%20Map.md>)
- [Job Title Crosswalk](<../03%20Career%20Map/Job%20Title%20Crosswalk.md>)
- [Free-First Tool Paths](<../11%20Visual%20Maps/Free-First%20Tool%20Paths.md>)

## Dynamic explorers

[Notion Index - Role Explorer](<../Notion%20Index%20-%20Role%20Explorer.md>)

[Notion Index - Source Review](<../Notion%20Index%20-%20Source%20Review.md>)

## Research status

The vault uses **as-of dates**, source links near claims, and a review queue. Start with [AI Tools and Practices Update — 2026-08-24](<../10%20Research/AI%20Tools%20and%20Practices%20Update%20%E2%80%94%202026-08-24.md>) for the latest technical layer, [August 2026 Research Brief](<../10%20Research/August%202026%20Research%20Brief.md>) for the market and policy context, then consult [Source Registry](<../10%20Research/Source%20Registry.md>) for primary references.

> **The durable advantage**
> Do not memorize product menus. Learn how to define a problem, choose an approach, test behavior, quantify tradeoffs, document risk, and communicate decisions. Those abilities transfer when models and tools change.
