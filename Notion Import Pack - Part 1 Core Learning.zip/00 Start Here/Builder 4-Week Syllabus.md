# Builder 4-week syllabus

> **Metadata:** Scope: United States · Level: beginner, intermediate · Status: current · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: guide
> **Tags:** technical-studio, curriculum, learning-path
> **Aliases:** Technical Builder Syllabus, Four Week Builder Path

> **Outcome**
> In four weeks a builder-track learner can unpack the frozen jargon, pass the cumulative check, and complete two studio cases at rubric ≥ 10/12. This is a **sequence**, not more content.

Skip a week-1 concept only if you can teach it to someone else with a number. Use [AI Career Diagnostic](<../06%20Assessment%20Center/AI%20Career%20Diagnostic.md>) if you are not on the builder bridge.

## Pass bar

| Gate | Bar |
|---|---|
| Concept flashcards | Idea preserved aloud, not wording |
| Each assigned case | ≥ 10/12 on [How to Study a Technical Case](<../12%20Technical%20Studio/How%20to%20Study%20a%20Technical%20Case.md>) |
| [Technical Cumulative Check](<../06%20Assessment%20Center/Technical%20Cumulative%20Check.md>) | ≥ 16/20, plus a written why on every miss |
| Week 4 project brief | One page using [Project Brief Template](<../09%20Templates/Project%20Brief%20Template.md>) — original domain, not Northline |

Time: **10–15 hours/week**. Less than 8 hours: stretch to six weeks; do not skip cases.

## Week 1 — Measure before you generate · 10–12 h

**Concepts:** [Tokens, Context, and Cost](<../12%20Technical%20Studio/Tokens%2C%20Context%2C%20and%20Cost.md>) · [Leakage and Contamination](<../12%20Technical%20Studio/Leakage%20and%20Contamination.md>) · [Metrics That Decide](<../12%20Technical%20Studio/Metrics%20That%20Decide.md>) · [Attention, Memory, and Inference](<../12%20Technical%20Studio/Attention%2C%20Memory%2C%20and%20Inference.md>) · [Context Engineering](<../12%20Technical%20Studio/Context%20Engineering.md>) · [Structured Outputs and Contracts](<../12%20Technical%20Studio/Structured%20Outputs%20and%20Contracts.md>)

**Do:** hide flashcards; recompute the token bill and the precision/recall table.

**Case:** none yet.

**Exit:** you can say what a token, a held-out set, and a bound argument are without opening the note.

## Week 2 — Find, adapt, train · 10–12 h

**Concepts:** [Retrieval Quality](<../12%20Technical%20Studio/Retrieval%20Quality.md>) · [Adaptation Methods](<../12%20Technical%20Studio/Adaptation%20Methods.md>) · [Embeddings and Similarity](<../12%20Technical%20Studio/Embeddings%20and%20Similarity.md>) · [The Training Loop](<../12%20Technical%20Studio/The%20Training%20Loop.md>) · [The Agent Loop](<../12%20Technical%20Studio/The%20Agent%20Loop.md>) · [Untrusted Context and Injection](<../12%20Technical%20Studio/Untrusted%20Context%20and%20Injection.md>)

**Case (closed-note):** [Case - Split Integrity](<../12%20Technical%20Studio/Case%20-%20Split%20Integrity.md>) *or* [Case - Evaluation Harness](<../12%20Technical%20Studio/Case%20-%20Evaluation%20Harness.md>) — pick one.

**Exit:** 10/12 on that case. If below, restudy the weak rubric row; do not start week 3.

## Week 3 — Serve, sample, see · 10–14 h

**Concepts:** [Sampling and Decoding](<../12%20Technical%20Studio/Sampling%20and%20Decoding.md>) · [Calibration](<../12%20Technical%20Studio/Calibration.md>) · [Quantization](<../12%20Technical%20Studio/Quantization.md>) · [Vision and Multimodal Systems](<../12%20Technical%20Studio/Vision%20and%20Multimodal%20Systems.md>)

**Cases (closed-note):** [Case - Prompt RAG Fine-Tune](<../12%20Technical%20Studio/Case%20-%20Prompt%20RAG%20Fine-Tune.md>) **and** one of [Case - Retrieval Failure Autopsy](<../12%20Technical%20Studio/Case%20-%20Retrieval%20Failure%20Autopsy.md>), [Case - Serving Capacity](<../12%20Technical%20Studio/Case%20-%20Serving%20Capacity.md>), [Case - Agent Permissions](<../12%20Technical%20Studio/Case%20-%20Agent%20Permissions.md>), [Case - Vision Field Slice](<../12%20Technical%20Studio/Case%20-%20Vision%20Field%20Slice.md>).

**Exit:** two cases at ≥ 10/12. Take [Technical Cumulative Check](<../06%20Assessment%20Center/Technical%20Cumulative%20Check.md>) at the end of the week (or first day of week 4).

## Week 4 — Own a role · 10–15 h

1. Open one profile from [Technical AI Careers](<../03%20Career%20Map/Technical/Technical%20AI%20Careers.md>).
2. Draw its operating loop from [Technical Role Deep Dive Framework](<../03%20Career%20Map/Technical/Technical%20Role%20Deep%20Dive%20Framework.md>) without looking.
3. Run four drills from [Technical Interview Drills](<../12%20Technical%20Studio/Technical%20Interview%20Drills.md>) (include drills 9 and 10).
4. File a [Project Brief Template](<../09%20Templates/Project%20Brief%20Template.md>) for one beginner or intermediate project on that role. No Northline copy-paste.
5. Optional overlay: if the job is healthcare, finance, or government, read the matching thickened note in [Industry Overlay Hub](<../08%20Industry%20Overlays/Industry%20Overlay%20Hub.md>).

**Exit:** brief + two interview stories using [Interview Story Template](<../09%20Templates/Interview%20Story%20Template.md>).

```mermaid
gantt
    title Builder 4-week sequence
    dateFormat X
    axisFormat %s
    section Week1
    Concepts 1-6           :a1, 0, 1
    section Week2
    Concepts 7-12          :a2, 1, 1
    One split or eval case :a3, 1, 1
    section Week3
    Concepts 13-16         :a4, 2, 1
    Two studio cases       :a5, 2, 1
    Cumulative check       :a6, 2, 1
    section Week4
    Role + drills + brief  :a7, 3, 1
```

The gantt units are weeks, not dates. Start any Monday.

## If you fail a gate

- Missed check items: restudy only those concept notes; retake after one sleep.
- Case < 10/12: rewrite the six closed-note items; do not read the worked path a second time until you have a new draft.
- No time for week 4: stop after the check. A role profile without cases is a map, not evidence.

## Visuals

- [Builder Path Infographic](<../11%20Visual%20Maps/Builder%20Path%20Infographic.md>)
- [Concept Spine Infographic](<../11%20Visual%20Maps/Concept%20Spine%20Infographic.md>)
- [RAG Autopsy Infographic](<../11%20Visual%20Maps/RAG%20Autopsy%20Infographic.md>)

## Not this syllabus

Explorers: [Everything AI - Home](<Everything%20AI%20-%20Home.md>) depth “Explorer.”  
Non-builders: [Learning Path Builder](<Learning%20Path%20Builder.md>) Layer 2 for your bridge — do not force these 16 notes.

Spine policy: [Concept Spine Freeze](<../12%20Technical%20Studio/Concept%20Spine%20Freeze.md>).
