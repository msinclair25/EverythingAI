# Learning Path Builder

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: guide
> **Tags:** ai-careers, curriculum, learning-path

A complete path has four layers, plus a builder-only studio layer. Skip content only when the [AI Career Diagnostic](<../06%20Assessment%20Center/AI%20Career%20Diagnostic.md>) shows that you can **recall, explain, and apply** it.

```mermaid
flowchart TB
    U["Layer 1 · Universal AI literacy"] --> B["Layer 2 · Background bridge"]
    B --> S["Layer 2b · Technical studio, builders"]
    S --> R["Layer 3 · Role profile"]
    B --> R
    R --> E["Layer 4 · Evidence + interview"]
    E --> C["Continuous update loop"]
```

## Layer 1 — universal foundations

Everyone should understand these, although depth varies by role:

1. [01 AI Systems and Vocabulary](<../01%20Foundations/01%20AI%20Systems%20and%20Vocabulary.md>)
2. [04 Data Foundations](<../01%20Foundations/04%20Data%20Foundations.md>)
3. [05 Machine Learning](<../01%20Foundations/05%20Machine%20Learning.md>)
4. [08 Generative AI Systems](<../01%20Foundations/08%20Generative%20AI%20Systems.md>)
5. [09 Prompt Context and Tool Use](<../01%20Foundations/09%20Prompt%20Context%20and%20Tool%20Use.md>)
6. [12 Evaluation Testing and Observability](<../01%20Foundations/12%20Evaluation%20Testing%20and%20Observability.md>)
7. [13 Deployment MLOps and Economics](<../01%20Foundations/13%20Deployment%20MLOps%20and%20Economics.md>)
8. [14 Security Privacy Safety and Responsible AI](<../01%20Foundations/14%20Security%20Privacy%20Safety%20and%20Responsible%20AI.md>)
9. [15 Product UX Business and Change](<../01%20Foundations/15%20Product%20UX%20Business%20and%20Change.md>)

## Layer 2 — choose a bridge

| Bridge | Add these modules | Typical destinations |
|---|---|---|
| Builder | [02 Math and Statistics for AI](<../01%20Foundations/02%20Math%20and%20Statistics%20for%20AI.md>), [03 Python SQL Git and Software Foundations](<../01%20Foundations/03%20Python%20SQL%20Git%20and%20Software%20Foundations.md>), [06 Deep Learning](<../01%20Foundations/06%20Deep%20Learning.md>), [07 Transformers and Foundation Models](<../01%20Foundations/07%20Transformers%20and%20Foundation%20Models.md>), [10 RAG and Knowledge Systems](<../01%20Foundations/10%20RAG%20and%20Knowledge%20Systems.md>), [11 Agents and Automation](<../01%20Foundations/11%20Agents%20and%20Automation.md>), then [Builder 4-Week Syllabus](<Builder%204-Week%20Syllabus.md>) | engineering, research, data, platform, evaluation, security |
| Decision-maker | [AI Product Discovery and Delivery](<../02%20Core%20Skills/AI%20Product%20Discovery%20and%20Delivery.md>), [AI Economics and FinOps](<../02%20Core%20Skills/AI%20Economics%20and%20FinOps.md>), [AI Adoption and Change](<../02%20Core%20Skills/AI%20Adoption%20and%20Change.md>), [Communicating AI Decisions](<../02%20Core%20Skills/Communicating%20AI%20Decisions.md>) | product, program, consulting, transformation, business analysis, executive AI leadership |
| Human experience | [AI Interaction and UX](<../02%20Core%20Skills/AI%20Interaction%20and%20UX.md>), [Conversation and Content Design](<../02%20Core%20Skills/Conversation%20and%20Content%20Design.md>), [AI Accessibility](<../02%20Core%20Skills/AI%20Accessibility.md>), [Creative AI Provenance and Rights](<../02%20Core%20Skills/Creative%20AI%20Provenance%20and%20Rights.md>) | UX, research, conversation, content, creative roles |
| Trust | [US AI Law and Policy Orientation](<../02%20Core%20Skills/US%20AI%20Law%20and%20Policy%20Orientation.md>), [AI Risk and Control Design](<../02%20Core%20Skills/AI%20Risk%20and%20Control%20Design.md>), [AI Assurance Evidence](<../02%20Core%20Skills/AI%20Assurance%20Evidence.md>), [AI Threat Modeling](<../02%20Core%20Skills/AI%20Threat%20Modeling.md>) | governance, policy, compliance, risk, audit, trust and safety, security |
| Knowledge and operations | [Data Quality and Annotation](<../02%20Core%20Skills/Data%20Quality%20and%20Annotation.md>), [Knowledge Architecture](<../02%20Core%20Skills/Knowledge%20Architecture.md>), [Workflow Analysis and Automation](<../02%20Core%20Skills/Workflow%20Analysis%20and%20Automation.md>), [Human Feedback Operations](<../02%20Core%20Skills/Human%20Feedback%20Operations.md>) | data operations, rating, ontology, knowledge, automation |
| Customer-facing | [AI Solution Discovery](<../02%20Core%20Skills/AI%20Solution%20Discovery.md>), [AI Demonstration and Enablement](<../02%20Core%20Skills/AI%20Demonstration%20and%20Enablement.md>), [Communicating AI Decisions](<../02%20Core%20Skills/Communicating%20AI%20Decisions.md>), [AI Adoption and Change](<../02%20Core%20Skills/AI%20Adoption%20and%20Change.md>) | solutions architecture, sales engineering, account leadership, product marketing, partnerships, success, support, DevRel, training |

## Layer 3 — role track

Open one role from [AI Career Atlas](<../03%20Career%20Map/AI%20Career%20Atlas.md>). Follow its sequence in order:

1. mission and boundaries;
2. level ladder and prerequisites;
3. competency map;
4. study sequence;
5. matching [Technical Studio](<../12%20Technical%20Studio/Technical%20Studio.md>) cases, if any;
6. tool categories;
7. quiz and flashcards;
8. interview preparation plus [Technical Interview Drills](<../12%20Technical%20Studio/Technical%20Interview%20Drills.md>) for technical roles;
9. suggested projects.

## Layer 4 — evidence and interview

- Select one small and one substantial idea from [Project Selection Guide](<../07%20Interview%20and%20Portfolio/Project%20Selection%20Guide.md>) plus the role profile.
- Document decisions with [Project Brief Template](<../09%20Templates/Project%20Brief%20Template.md>), [Evaluation Report Template](<../09%20Templates/Evaluation%20Report%20Template.md>), and—where relevant—[AI System Card Template](<../09%20Templates/AI%20System%20Card%20Template.md>).
- Practice with [AI Interview Playbook](<../07%20Interview%20and%20Portfolio/AI%20Interview%20Playbook.md>), [Behavioral Interview Bank](<../07%20Interview%20and%20Portfolio/Behavioral%20Interview%20Bank.md>), and the family-specific interview guide.
- Use [Role Readiness Check](<../06%20Assessment%20Center/Role%20Readiness%20Check.md>) to identify gaps.

## Suggested pacing

| Pace | Weekly time | Pattern |
|---|---:|---|
| Sustainable | 4–6 hours | 2 study sessions + 1 recall/interview session |
| Career-switch sprint | 10–15 hours | foundations and project work in parallel |
| Immersive | 25–35 hours | treat as structured training; protect review and recovery time |

Time is not mastery. Use retrieval and explanation quality, quiz performance, and the ability to make defensible project decisions.

## A reusable weekly cycle

| Day | Focus |
|---|---|
| 1 | Read one concept section; make your own example |
| 2 | Read the next section; connect it to the target role |
| 3 | Closed-note flashcards and quiz questions |
| 4 | Improve a suggested project artifact |
| 5 | Explain one design choice and one failure mode aloud |
| 6 | Re-test misses; scan official updates relevant to the role |
| 7 | Rest or light review |

> **Progress rule**
> Advance when you score at least 80%, can explain each missed alternative, and can connect the concept to a real role decision. Memorizing an answer key is not progression.
