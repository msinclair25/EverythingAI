# How an AI assistant should use this vault

> **Metadata:** Scope: United States · Status: current · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: guide
> **Tags:** ai-careers, orientation, agents
> **Aliases:** Agent Instructions for This Vault

Read this before editing Anything AI / EverythingAI. The human owner’s contract beats this page if they conflict.

## What this vault is

A US-focused **career map + taught jargon + worked decisions**. It is not a lab school, not legal advice, and not a live model leaderboard.

## Do

1. Open [Everything AI - Home](<Everything%20AI%20-%20Home.md>), [Coverage, Evidence, and Limits](<Coverage%2C%20Evidence%2C%20and%20Limits.md>), and [Concept Spine Freeze](<../12%20Technical%20Studio/Concept%20Spine%20Freeze.md>) first.
2. Prefer **patching** an existing note over creating a 17th concept. Spine is frozen at 16.
3. New teaching notes use the existing templates: concept (plain idea → why → jargon → teaching numbers → quiz → transfer) or case (Northline teaching envelope, labeled constructed).
4. Keep `as_of` / `last_verified` honest. Do not invent statutes or prices.
5. After material adds, update [Vault Changelog](<../10%20Research/Vault%20Changelog.md>), Home counts (by counting files, not guessing), and the relevant hub.
6. Wikilink related roles and concepts. A wikilink must match a note filename or its `title:` field.
7. Propose vault updates when you finish a task. Do not leave orphan notes.

## Do not

- Do not add prescriptive labs or copy-paste tutorial tracks.
- Do not cite teaching numbers as measured results.
- Do not thicken all ten industry overlays because three were thickened. Exception: a user asks for a specific sector.
- Do not expand the 47 nontechnical roles unless asked.
- Do not commit secrets, PHI, or live customer data into examples.
- Do not treat EOs or OMB memos as statutes.

## Where new work goes

| Kind of work | Put it here |
|---|---|
| Jargon + why | [Technical Skills Hub](<../12%20Technical%20Studio/Technical%20Skills%20Hub.md>) only via freeze exception |
| Decision rehearsal | `12 Technical Studio/Case - …` |
| Builder sequence | [Builder 4-Week Syllabus](<Builder%204-Week%20Syllabus.md>) |
| Exam items | [Technical Cumulative Check](<../06%20Assessment%20Center/Technical%20Cumulative%20Check.md>) |
| Sector depth | `08 Industry Overlays/` |
| Pictures | `11 Visual Maps/` |
| Glossary row | [AI Glossary](<../AI%20Glossary.md>) |

## Visuals

HTML infographics live under `11 Visual Maps/` and are linked from markdown notes. They are teaching pictures, not evidence.

## If you are lost

Builder human: [Builder 4-Week Syllabus](<Builder%204-Week%20Syllabus.md>).  
Any human: [How to Use This Vault](<How%20to%20Use%20This%20Vault.md>).
