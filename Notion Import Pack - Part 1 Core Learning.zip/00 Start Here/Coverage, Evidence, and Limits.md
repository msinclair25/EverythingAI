# Coverage, Evidence, and Limits

> **Metadata:** Scope: United States · Level: beginner · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: guide
> **Tags:** ai-careers, methodology, limitations
> **Aliases:** Scope and Limitations

## What “all AI jobs” means

There is no official, exhaustive list of AI job titles. Titles are created faster than occupational taxonomies update, and the same title can describe different work at different employers. This vault therefore covers:

1. the major **functions** required to research, build, deploy, evaluate, secure, govern, sell, market, partner, support, operate safely, adopt, lead, design, teach, and create with AI;
2. individual profiles for widely advertised or functionally distinct roles;
3. aliases and adjacent-role boundaries in [Job Title Crosswalk](<../03%20Career%20Map/Job%20Title%20Crosswalk.md>);
4. industry overlays for domain-specific variants.

If a posting's title is absent, match its deliverables to a role profile. A “Generative AI Architect,” for example, may be closest to [AI Solutions Architect](<../04%20Role%20Tracks/Nontechnical/AI%20Solutions%20Architect.md>), [AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>), or [RAG and Knowledge Engineer](<../04%20Role%20Tracks/Technical/RAG%20and%20Knowledge%20Engineer.md>) depending on the work.

## Evidence tiers

| Tier | Preferred use | Examples |
|---|---|---|
| A — primary/official | policy, standards, product capabilities, occupational data | NIST, BLS, EEOC, White House/OMB, Copyright Office, official product docs |
| B — original research | technical mechanisms and empirical findings | peer-reviewed papers, conference proceedings, documented research reports |
| C — strong synthesis | market interpretation and practice patterns | Stanford AI Index, reputable curricula, standards organizations |
| D — discovery only | identify terminology or candidate sources | job boards, blogs, social posts; not used alone for consequential claims |

See [Research Method and Source Policy](<../10%20Research/Research%20Method%20and%20Source%20Policy.md>) and [Source Registry](<../10%20Research/Source%20Registry.md>).

## Time boundary

- **Cutoff:** August 12, 2026.
- Time-sensitive notes carry `last_verified` and `review_by`.
- Model rankings, prices, quotas, product features, and laws can change immediately after verification.
- Draft guidance is labeled **draft**; proposed bills are not described as law.

## U.S. boundary

Employment context, regulation, and market discussion are U.S.-focused. Global technical standards may appear when U.S. employers use them, but this vault does not teach compliance with every non-U.S. jurisdiction.

## Important limits

> **Not legal, medical, financial, or employment advice**
> The material teaches issue-spotting and professional practice. For a consequential decision, consult qualified organizational experts and current primary law or policy.

- Tool inclusion is not endorsement.
- A suggested project is not evidence that a system is safe for production.
- A quiz score is not a certification.
- Education requirements are employer- and role-dependent; demonstrated skill may substitute in some contexts, while research and regulated work may require formal credentials.
- Salary is intentionally not generalized across fluid titles. Use current BLS occupational mappings, location-specific data, and actual postings.

## Maintenance rule

When a source conflicts with this vault, prefer the current primary source and update the note. Record material changes in [Vault Changelog](<../10%20Research/Vault%20Changelog.md>).
