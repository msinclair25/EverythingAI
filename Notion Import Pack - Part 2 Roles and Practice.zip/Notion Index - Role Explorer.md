# Role Explorer

> This is the static Notion equivalent of the Obsidian Role Explorer Base. Import the Markdown pages first, then use this page as the role directory.

| Role | Family | Page |
|---|---|---|
| AI Automation Specialist | Experience Content and Automation | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Automation%20Specialist.md>) |
| AI Content Designer | Experience Content and Automation | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Content%20Designer.md>) |
| AI UX Researcher | Experience Content and Automation | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20UX%20Researcher.md>) |
| AI UX and Product Designer | Experience Content and Automation | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20UX%20and%20Product%20Designer.md>) |
| Conversation Designer | Experience Content and Automation | [Open role](<04%20Role%20Tracks/Nontechnical/Conversation%20Designer.md>) |
| Prompt and Context Engineer | Experience Content and Automation | [Open role](<04%20Role%20Tracks/Nontechnical/Prompt%20and%20Context%20Engineer.md>) |
| AI Audio and Music Specialist | Generative Creative and Education | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Audio%20and%20Music%20Specialist.md>) |
| AI Image and Graphic Creator | Generative Creative and Education | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Image%20and%20Graphic%20Creator.md>) |
| AI Trainer and Educator | Generative Creative and Education | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Trainer%20and%20Educator.md>) |
| AI Video Producer | Generative Creative and Education | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Video%20Producer.md>) |
| Generative AI Creative Director | Generative Creative and Education | [Open role](<04%20Role%20Tracks/Nontechnical/Generative%20AI%20Creative%20Director.md>) |
| AI Auditor and Assurance Specialist | Governance Risk Policy and Ethics | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Auditor%20and%20Assurance%20Specialist.md>) |
| AI Compliance and Privacy Specialist | Governance Risk Policy and Ethics | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Compliance%20and%20Privacy%20Specialist.md>) |
| AI Ethics Researcher | Governance Risk Policy and Ethics | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Ethics%20Researcher.md>) |
| AI Governance Specialist | Governance Risk Policy and Ethics | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Governance%20Specialist.md>) |
| AI Policy Analyst | Governance Risk Policy and Ethics | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Policy%20Analyst.md>) |
| AI Trust and Safety Operations Specialist | Governance Risk Policy and Ethics | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Trust%20and%20Safety%20Operations%20Specialist.md>) |
| Model Risk Manager | Governance Risk Policy and Ethics | [Open role](<04%20Role%20Tracks/Nontechnical/Model%20Risk%20Manager.md>) |
| Responsible AI Specialist | Governance Risk Policy and Ethics | [Open role](<04%20Role%20Tracks/Nontechnical/Responsible%20AI%20Specialist.md>) |
| AI Data Operations Manager | Human Data and Knowledge Operations | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Data%20Operations%20Manager.md>) |
| AI Talent and Recruiting Specialist | Human Data and Knowledge Operations | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Talent%20and%20Recruiting%20Specialist.md>) |
| Data Annotator and AI Rater | Human Data and Knowledge Operations | [Open role](<04%20Role%20Tracks/Nontechnical/Data%20Annotator%20and%20AI%20Rater.md>) |
| Human-Feedback Specialist | Human Data and Knowledge Operations | [Open role](<04%20Role%20Tracks/Nontechnical/Human-Feedback%20Specialist.md>) |
| Knowledge Manager | Human Data and Knowledge Operations | [Open role](<04%20Role%20Tracks/Nontechnical/Knowledge%20Manager.md>) |
| Taxonomist and Ontology Specialist | Human Data and Knowledge Operations | [Open role](<04%20Role%20Tracks/Nontechnical/Taxonomist%20and%20Ontology%20Specialist.md>) |
| AI Business Analyst | Product Program and Business | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Business%20Analyst.md>) |
| AI Product Manager | Product Program and Business | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Product%20Manager.md>) |
| AI Program Manager | Product Program and Business | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Program%20Manager.md>) |
| AI Strategy Consultant | Product Program and Business | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Strategy%20Consultant.md>) |
| AI Transformation Lead | Product Program and Business | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Transformation%20Lead.md>) |
| Chief AI Officer and Head of AI | Product Program and Business | [Open role](<04%20Role%20Tracks/Nontechnical/Chief%20AI%20Officer%20and%20Head%20of%20AI.md>) |
| Technical AI Product Manager | Product Program and Business | [Open role](<04%20Role%20Tracks/Nontechnical/Technical%20AI%20Product%20Manager.md>) |
| AI Customer Success Manager | Solutions Go-to-Market and Developer Relations | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Customer%20Success%20Manager.md>) |
| AI Developer Relations and Advocate | Solutions Go-to-Market and Developer Relations | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Developer%20Relations%20and%20Advocate.md>) |
| AI Enterprise Account Executive | Solutions Go-to-Market and Developer Relations | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Enterprise%20Account%20Executive.md>) |
| AI Product Marketing Manager | Solutions Go-to-Market and Developer Relations | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Product%20Marketing%20Manager.md>) |
| AI Sales Engineer | Solutions Go-to-Market and Developer Relations | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Sales%20Engineer.md>) |
| AI Solutions Architect | Solutions Go-to-Market and Developer Relations | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Solutions%20Architect.md>) |
| AI Strategic Partnerships Manager | Solutions Go-to-Market and Developer Relations | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Strategic%20Partnerships%20Manager.md>) |
| AI Technical Support and User Operations Specialist | Solutions Go-to-Market and Developer Relations | [Open role](<04%20Role%20Tracks/Nontechnical/AI%20Technical%20Support%20and%20User%20Operations%20Specialist.md>) |
| AI Red Teamer | Technical AI Safety and Security | [Open role](<04%20Role%20Tracks/Technical/AI%20Red%20Teamer.md>) |
| AI Safety and Alignment Researcher | Technical AI Safety and Security | [Open role](<04%20Role%20Tracks/Technical/AI%20Safety%20and%20Alignment%20Researcher.md>) |
| AI Security Engineer | Technical AI Safety and Security | [Open role](<04%20Role%20Tracks/Technical/AI%20Security%20Engineer.md>) |
| AI Platform Engineer | Technical Data Platform and MLOps | [Open role](<04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>) |
| Data Scientist - AI ML | Technical Data Platform and MLOps | [Open role](<04%20Role%20Tracks/Technical/Data%20Scientist%20-%20AI%20ML.md>) |
| ML Data Engineer | Technical Data Platform and MLOps | [Open role](<04%20Role%20Tracks/Technical/ML%20Data%20Engineer.md>) |
| MLOps Engineer | Technical Data Platform and MLOps | [Open role](<04%20Role%20Tracks/Technical/MLOps%20Engineer.md>) |
| AI Evaluation Engineer | Technical Evaluation Knowledge and Data | [Open role](<04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>) |
| RAG and Knowledge Engineer | Technical Evaluation Knowledge and Data | [Open role](<04%20Role%20Tracks/Technical/RAG%20and%20Knowledge%20Engineer.md>) |
| Synthetic Data Engineer | Technical Evaluation Knowledge and Data | [Open role](<04%20Role%20Tracks/Technical/Synthetic%20Data%20Engineer.md>) |
| AI Hardware and Accelerator Engineer | Technical Infrastructure and Performance | [Open role](<04%20Role%20Tracks/Technical/AI%20Hardware%20and%20Accelerator%20Engineer.md>) |
| Inference and Performance Engineer | Technical Infrastructure and Performance | [Open role](<04%20Role%20Tracks/Technical/Inference%20and%20Performance%20Engineer.md>) |
| Computer Vision Engineer | Technical Modality Engineering | [Open role](<04%20Role%20Tracks/Technical/Computer%20Vision%20Engineer.md>) |
| NLP Engineer | Technical Modality Engineering | [Open role](<04%20Role%20Tracks/Technical/NLP%20Engineer.md>) |
| Robotics and Embodied AI Engineer | Technical Modality Engineering | [Open role](<04%20Role%20Tracks/Technical/Robotics%20and%20Embodied%20AI%20Engineer.md>) |
| Speech AI Engineer | Technical Modality Engineering | [Open role](<04%20Role%20Tracks/Technical/Speech%20AI%20Engineer.md>) |
| AI Engineer | Technical Model and Application Engineering | [Open role](<04%20Role%20Tracks/Technical/AI%20Engineer.md>) |
| Agentic AI Engineer | Technical Model and Application Engineering | [Open role](<04%20Role%20Tracks/Technical/Agentic%20AI%20Engineer.md>) |
| LLM Engineer | Technical Model and Application Engineering | [Open role](<04%20Role%20Tracks/Technical/LLM%20Engineer.md>) |
| ML Engineer | Technical Model and Application Engineering | [Open role](<04%20Role%20Tracks/Technical/ML%20Engineer.md>) |
| AI ML Research Scientist | Technical Research and Applied Science | [Open role](<04%20Role%20Tracks/Technical/AI%20ML%20Research%20Scientist.md>) |
| Applied Scientist | Technical Research and Applied Science | [Open role](<04%20Role%20Tracks/Technical/Applied%20Scientist.md>) |
| Research Engineer | Technical Research and Applied Science | [Open role](<04%20Role%20Tracks/Technical/Research%20Engineer.md>) |
