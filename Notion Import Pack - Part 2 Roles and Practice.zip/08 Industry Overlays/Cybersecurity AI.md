# Cybersecurity AI

> **Metadata:** Scope: United States · Level: advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: industry-overlay
> **Tags:** ai-careers, industry, cybersecurity

AI can support detection, triage, analysis, secure coding, simulation, identity, and response, while attackers use it for reconnaissance, persuasion, evasion, vulnerability work, and scalable operations. Work only with authorization and clear rules of engagement.

Add threat intelligence provenance, adversarial evaluation, secure tool permissions, secrets handling, sandboxing, false-positive/alert capacity, evidence preservation, incident response, dual-use controls, and model/provider supply chain.

## Suggested projects

- Beginner: threat-model a code assistant and rank five abuse paths.
- Intermediate: evaluate a defensive alert summarizer for omission, fabricated evidence, and injection.
- Advanced: build a read-only incident-analysis agent design with containment, audit, and adversarial cases.

Sources: [NIST Cybersecurity Framework](https://www.nist.gov/cyberframework), [NIST AI security](https://www.nist.gov/artificial-intelligence), [MITRE ATLAS](https://atlas.mitre.org/), and [CISA AI](https://www.cisa.gov/topics/artificial-intelligence), verified 2026-08-12.
