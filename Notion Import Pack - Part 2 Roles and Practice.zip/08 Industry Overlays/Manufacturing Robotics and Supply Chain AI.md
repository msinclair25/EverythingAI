# Manufacturing, Robotics, and Supply Chain AI

> **Metadata:** Scope: United States · Level: intermediate, advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: industry-overlay
> **Tags:** ai-careers, industry, manufacturing, robotics

Add physical safety, controls engineering, sensor calibration, edge/real-time constraints, quality systems, simulation-to-real gaps, maintenance, cybersecurity/OT boundaries, human factors, downtime economics, traceability, and supplier risk.

Common uses: inspection, predictive maintenance, planning, forecasting, scheduling, robotics, digital twins, process control, procurement, and worker assistance. A model recommendation can create physical or inventory effects; preserve interlocks, safe states, manual continuity, and change control.

## Suggested projects

- Beginner: error-cost analysis for visual defect detection under class imbalance.
- Intermediate: design monitoring and safe fallback for predictive maintenance using public/synthetic sensor data.
- Advanced: threat/evaluation plan for a vision-language robot in a constrained cell—no physical deployment required.

Start with relevant [NIST manufacturing resources](https://www.nist.gov/topics/manufacturing), OSHA, sector cybersecurity, and applicable engineering/robot safety standards.
