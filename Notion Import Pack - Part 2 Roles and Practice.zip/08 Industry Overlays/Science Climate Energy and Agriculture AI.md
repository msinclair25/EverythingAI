# Science, Climate, Energy, and Agriculture AI

> **Metadata:** Scope: United States · Level: advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: industry-overlay
> **Tags:** ai-careers, industry, science, climate, energy, agriculture

Add domain theory, measurement uncertainty, causal/physical constraints, geospatial/time-series/sensor data, out-of-distribution conditions, reproducibility, scientific computing, uncertainty communication, field validation, safety, infrastructure/cyber risk, environmental impact, and stakeholder/local knowledge.

AI can support simulation, surrogate modeling, weather/climate analysis, grid and energy optimization, materials, remote sensing, crop/soil/animal systems, and scientific literature/data. A predictive fit that violates conservation, fails under extreme events, or lacks field transfer may be unusable.

## Suggested projects

- Beginner: compare forecast error metrics and show how one aggregate hides extreme conditions.
- Intermediate: design an uncertainty and field-validation plan for a public remote-sensing dataset.
- Advanced: propose a physics-informed or hybrid modeling study with ablations, reproducibility, compute/environment accounting, and decision limits.

Use authoritative domain agencies/labs and peer-reviewed work, plus [NIST AI measurement resources](https://www.nist.gov/artificial-intelligence/nist-information-technology-laboratory-itl-ai-program).
