# Industry Overlay Hub

> **Metadata:** Scope: United States · Level: intermediate, advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: hub
> **Tags:** ai-careers, industry, hub

Choose a functional role first, then add a domain overlay. Domain expertise changes acceptable evidence, data, workflow, regulation, and consequences; it does not create an entirely separate AI profession.

| Overlay | Key additions |
|---|---|
| [Healthcare and Life Sciences AI](<Healthcare%20and%20Life%20Sciences%20AI.md>) | clinical workflow, patient safety, FDA/health privacy boundaries, validation — **thickened teaching note** |
| [Financial Services and Insurance AI](<Financial%20Services%20and%20Insurance%20AI.md>) | model risk, consumer/credit rules, fraud, explainability, records — **thickened teaching note** |
| [US Government and Public Sector AI](<US%20Government%20and%20Public%20Sector%20AI.md>) | public authority, procurement, records, accessibility, civil rights, OMB/agency policy — **thickened teaching note** |
| [Education AI](<Education%20AI.md>) | learners/minors, accessibility, academic integrity, FERPA, instructional evidence |
| [Legal and Professional Services AI](<Legal%20and%20Professional%20Services%20AI.md>) | confidentiality, competence, citations, privilege, supervision |
| [Manufacturing Robotics and Supply Chain AI](<Manufacturing%20Robotics%20and%20Supply%20Chain%20AI.md>) | physical safety, controls, sensor quality, downtime, simulation |
| [Cybersecurity AI](<Cybersecurity%20AI.md>) | adversarial actors, secure tooling, incident operations, dual use |
| [Media Marketing and Entertainment AI](<Media%20Marketing%20and%20Entertainment%20AI.md>) | provenance, copyright, likeness, disclosure, brand and factual review |
| [Retail Ecommerce and Customer Service AI](<Retail%20Ecommerce%20and%20Customer%20Service%20AI.md>) | recommendation, personalization, consumer protection, inventory, customer effort |
| [Science Climate Energy and Agriculture AI](<Science%20Climate%20Energy%20and%20Agriculture%20AI.md>) | scientific validity, physical constraints, geospatial/sensor data, environmental impact |

## Overlay method

For any sector, answer:

1. Which decisions can harm rights, safety, health, finances, or opportunity?
2. Which domain professional owns final judgment?
3. Which data is sensitive, regulated, sparse, shifted, or costly?
4. What counts as valid evidence and external validation?
5. Which human review, recourse, and continuity paths are mandatory?
6. Which regulator, law, standard, contract, or professional duty must be verified now?
7. How will incidents and model/provider changes be handled?

> **Three overlays are teaching-length**
> Healthcare, financial services, and US government now include a contract, illegal shortcuts, a worked decision, quiz, and flashcards. The other seven remain short issue maps. Do not thicken them in a batch unless a learner is entering that sector.

> **Domain overlay is not a credential**
> Reading a note does not qualify someone to practice medicine, law, engineering, accounting, or another regulated profession.
