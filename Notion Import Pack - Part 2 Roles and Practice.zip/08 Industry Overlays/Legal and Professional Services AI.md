# Legal and Professional Services AI

> **Metadata:** Scope: United States · Level: advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-09-12 · Type: industry-overlay
> **Tags:** ai-careers, industry, legal, professional-services

Add professional competence, confidentiality/privilege, conflicts, supervision, billing/representation accuracy, records, citation verification, client consent/communication, and jurisdiction-specific duties.

Legal research generation must verify every proposition and source in authoritative databases; fluent invented citations are a known severe failure. Contract review needs clause context, governing law, document version, materiality, and qualified review. Accounting, engineering, and other professional work has parallel domain standards and licensed responsibility.

## Suggested projects

- Beginner: create a citation-verification rubric using public court/government sources.
- Intermediate: design a contract-review evaluation set with ambiguity, exceptions, and escalation—using fictional documents.
- Advanced: build an assurance and supervision plan for a professional-services copilot.

Verify current state bar/professional guidance and court rules. Never present an educational project as professional advice.
