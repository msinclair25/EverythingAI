# Quiz Index

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: current · Verified: 2026-08-24 · Review by: 2026-11-24 · Type: index
> **Tags:** ai-careers, quiz, index

## Whole-curriculum checks

- [Foundations Pretest](<Foundations%20Pretest.md>)
- [Foundations Final Check](<Foundations%20Final%20Check.md>)
- [Technical Cumulative Check](<Technical%20Cumulative%20Check.md>)

## Module quizzes

Each note in [Foundations Hub](<../01%20Foundations/Foundations%20Hub.md>) and [Core Skills Hub](<../02%20Core%20Skills/Core%20Skills%20Hub.md>) contains a quiz immediately before a collapsed answer callout. Each [Technical Studio](<../12%20Technical%20Studio/Technical%20Studio.md>) case includes a decision quiz.

### Delivery and operations quiz

- [AI DevOps and Cloud Engineering — 2026-08-24 — Quiz](<../05%20Tool%20Atlas/AI%20DevOps%20and%20Cloud%20Engineering%20%E2%80%94%202026-08-24.md>) — AI for DevOps and DevOps for AI; cloud, CI/CD, identity, evaluation, Kubernetes, observability, supply chain, and FinOps.

## Role quizzes

Every role profile in [AI Career Atlas](<../03%20Career%20Map/AI%20Career%20Atlas.md>) includes role decisions, tool choices, boundaries, and scenario questions with answers.

```query
path:"04 Role Tracks" (line:"## Quiz" OR line:"## Knowledge check")
```

## Review method

For each miss record: concept, your wrong assumption, correct rule, one new example, and a case where the rule would not apply. Re-take with reordered or self-created examples.
