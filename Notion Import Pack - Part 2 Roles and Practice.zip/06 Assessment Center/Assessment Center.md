# Assessment Center

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: hub
> **Tags:** ai-careers, assessment, hub

Assessments are for routing and retrieval practice, not credentials.

```mermaid
flowchart LR
    D["Career diagnostic"] --> P["Foundations pretest"] --> S["Study + flashcards"] --> Q["Module/role quizzes"] --> F["Foundations final check"] --> R["Role readiness check"] --> I["Interview practice"]
```

## Start

- [AI Career Diagnostic](<AI%20Career%20Diagnostic.md>) — interests, working style, and current foundation.
- [Foundations Pretest](<Foundations%20Pretest.md>) — 30 questions across the shared curriculum.
- [Flashcard Index](<Flashcard%20Index.md>) — locate foundation, bridge, and role decks.
- [Quiz Index](<Quiz%20Index.md>) — locate quizzes and answer keys.
- [Foundations Final Check](<Foundations%20Final%20Check.md>) — scenario-based integration.
- [Role Readiness Check](<Role%20Readiness%20Check.md>) — test whether you can explain, decide, and show evidence.
- [Technical Cumulative Check](<Technical%20Cumulative%20Check.md>) — 20 closed-note items across the frozen 16 concepts; pass ≥ 16/20.
- [Technical Studio](<../12%20Technical%20Studio/Technical%20Studio.md>) — worked decision cases; builders treat two cases as a readiness gate.
- [AI DevOps and Cloud Engineering — 2026-08-24](<../05%20Tool%20Atlas/AI%20DevOps%20and%20Cloud%20Engineering%20%E2%80%94%202026-08-24.md>) — delivery/operations study track with 20-question quiz and 41-card deck.
- [Technical Interview Drills](<../12%20Technical%20Studio/Technical%20Interview%20Drills.md>) — timed interview versions of the same cases.
- [Builder 4-Week Syllabus](<../00%20Start%20Here/Builder%204-Week%20Syllabus.md>) — the calendar that uses the check.

## Assessment rules

1. Answer closed-note first.
2. State why rejected choices are wrong.
3. Use 80% as a routing signal, not proof of mastery.
4. Re-study by concept and failure category, not by memorizing letters.
5. Re-test after time and in a new scenario.

> **Mastery test**
> You can retrieve the idea, explain it at two altitudes, apply it to an unfamiliar case, name a limitation, and recognize when it does not apply.
