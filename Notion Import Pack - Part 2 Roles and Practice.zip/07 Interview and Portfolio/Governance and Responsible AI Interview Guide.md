# Governance and Responsible AI Interview Guide

> **Metadata:** Scope: United States · Level: intermediate, advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: guide
> **Tags:** ai-careers, interview, governance

## Core questions

- Build an AI inventory and tiering method.
- Translate a principle into an operating control.
- Assess an employment, credit, health, education, or government use.
- Distinguish legal compliance, ethics, security, privacy, fairness, safety, and assurance.
- Evaluate a vendor with limited evidence.
- Respond to an incident and notify appropriate stakeholders.
- Design exception and residual-risk acceptance.
- Explain how NIST AI RMF applies without turning it into a checklist.
- Handle conflict between product speed and insufficient evidence.

## Answer pattern

Context/actor/jurisdiction → affected people/assets → claim or risk → current authority/criteria → lifecycle controls → evidence/test → residual uncertainty → decision owner → monitoring/recourse/update.

## Evidence exercise

Expect to critique a system card, impact assessment, evaluation report, policy, control matrix, vendor questionnaire, audit sample, or incident record. Identify scope, version, source quality, missing population/slices, unsupported claims, independence, and operating evidence.

Never improvise legal conclusions. Demonstrate issue spotting, current-source verification, and appropriate escalation.
