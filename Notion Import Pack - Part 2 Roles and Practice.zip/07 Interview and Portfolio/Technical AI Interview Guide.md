# Technical AI Interview Guide

> **Metadata:** Scope: United States · Level: intermediate, advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: guide
> **Tags:** ai-careers, interview, technical

## Domains

- coding, data structures, debugging, testing, APIs, SQL, and software design;
- probability, statistics, experiment design, and metrics;
- ML framing, data/splits, algorithms, generalization, and error analysis;
- deep learning, transformers, training/adaptation, and optimization;
- RAG, agents, evaluation, security, deployment, reliability, and economics;
- research depth or systems depth according to the role.

## Design prompts

- Design a grounded support assistant with permissioned documents.
- Design an evaluation platform for model and prompt changes.
- Design a low-latency multimodal endpoint under a fixed budget.
- Design an agent that can take reversible account actions.
- Design a training-data pipeline with lineage and deletion handling.
- Diagnose a model whose offline score improves while production degrades.

For each, cover requirements, baseline, architecture, data, interfaces, evaluation, threat model, SLOs, cost, rollout, incident response, and tradeoffs.

## Research interviews

Be ready to derive objectives, critique a paper, identify assumptions, design an ablation, handle negative results, estimate uncertainty, discuss compute/data constraints, and propose a falsifiable follow-up. Explain the gap between a benchmark result and a scientific claim.

## Coding practice

Practice writing readable functions, tests, SQL, data validation, metric calculations, batching/retry logic, a retrieval baseline, and a small evaluation runner without relying entirely on frameworks. Explain complexity and failure handling.

## Role-specific guide

Use the interview section in the selected profile under [AI Career Atlas](<../03%20Career%20Map/AI%20Career%20Atlas.md>).

## Studio drills

Work the timed prompts in [Technical Interview Drills](<../12%20Technical%20Studio/Technical%20Interview%20Drills.md>) after at least two [Technical Studio](<../12%20Technical%20Studio/Technical%20Studio.md>) cases. The drills reuse the same contracts: adaptation choice, ship-or-stop, agent permissions, capacity arithmetic, and retrieval autopsies.
