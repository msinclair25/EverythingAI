# Interview and Portfolio Hub

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: hub
> **Tags:** ai-careers, interview, portfolio, hub

Your evidence should mirror the role's real decisions.

- [Project Selection Guide](<Project%20Selection%20Guide.md>) — choose useful project evidence without following a lab.
- [Project Bank](<Project%20Bank.md>) — cross-role suggested projects by difficulty.
- [AI Interview Playbook](<AI%20Interview%20Playbook.md>) — answer architecture, product, evaluation, governance, creative, and operational questions.
- [Behavioral Interview Bank](<Behavioral%20Interview%20Bank.md>) — build decision-rich stories.
- [Technical AI Interview Guide](<Technical%20AI%20Interview%20Guide.md>) — coding, ML, systems, evaluation, security, and research.
- [Technical Interview Drills](<../12%20Technical%20Studio/Technical%20Interview%20Drills.md>) — timed studio decisions with strong/weak answer shapes.
- [Product and Business AI Interview Guide](<Product%20and%20Business%20AI%20Interview%20Guide.md>) — product sense, strategy, adoption, solutions, economics.
- [Governance and Responsible AI Interview Guide](<Governance%20and%20Responsible%20AI%20Interview%20Guide.md>) — risk, policy, controls, assurance, ethics.
- [Creative UX and Human Operations Interview Guide](<Creative%20UX%20and%20Human%20Operations%20Interview%20Guide.md>) — UX, conversation, media, annotation, knowledge, training.

Use [Project Brief Template](<../09%20Templates/Project%20Brief%20Template.md>), [Evaluation Report Template](<../09%20Templates/Evaluation%20Report%20Template.md>), [AI System Card Template](<../09%20Templates/AI%20System%20Card%20Template.md>), and [Decision Record Template](<../09%20Templates/Decision%20Record%20Template.md>) to structure artifacts.

```mermaid
flowchart LR
    J["Target role decisions"] --> P["Project evidence"] --> S["Story bank"] --> M["Mock questions"] --> G["Gap repair"] --> A["Applications + interviews"]
```
