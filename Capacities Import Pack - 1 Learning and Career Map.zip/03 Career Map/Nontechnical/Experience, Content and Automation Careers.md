---
title: Experience, Content and Automation Careers
type: Page
tags: ai-careers/nontechnical, career-family/experience-automation
source_path: 03 Career Map/Nontechnical/Experience, Content and Automation Careers.md
source_type: career-map
scope: United States
level: beginner, intermediate, advanced
last_verified: '2026-08-12'
review_by: '2026-11-12'
---

# Experience, Content and Automation Careers

> **Source record:** [Vault source](https://github.com/msinclair25/EverythingAI/blob/main/03%20Career%20Map/Nontechnical/Experience%2C%20Content%20and%20Automation%20Careers.md) · last verified 2026-08-12 · review by 2026-11-12.

These roles shape how people understand, control, and recover from probabilistic systems—and how work moves through them.

```mermaid
flowchart LR
    Research["AI UX Researcher\nneeds and behavior"] --> Design["AI UX and Product Designer\ninteraction and control"]
    Design --> Conv["Conversation Designer\ndialogue and repair"]
    Design --> Content["AI Content Designer\nwords and comprehension"]
    Conv --> Prompt["Prompt and Context Engineer\ninstructions, context, evals"]
    Prompt --> Auto["AI Automation Specialist\nworkflow and operations"]
```

| Role | Optimizes | Typical evidence |
|---|---|---|
| [[AI UX and Product Designer]] | Whole human-AI interaction | Prototype with uncertainty, override, feedback, and recovery states |
| [[AI UX Researcher]] | Understanding of people and context | Research plan, moderated study, findings linked to decisions |
| [[Conversation Designer]] | Turns, voice, clarification, repair, escalation | Dialogue map and adversarial test transcript |
| [[AI Content Designer]] | Clarity, guidance, labels, error and consent language | Content system and comprehension test |
| [[Prompt and Context Engineer]] | Reproducible model behavior | Versioned prompt/context package and evaluation set |
| [[AI Automation Specialist]] | Reliable movement of work across systems | Diagram, workflow, test matrix, logs, runbook |

## Non-negotiables

- Design the human’s authority: review, edit, override, retry, escalate, and exit.
- Test with representative users and realistic failures—not only happy paths.
- Meet accessibility needs; WCAG 2.2 remains the practical baseline for web content and interaction.
- Treat prompts, retrieved context, tools, and output handling as one system.

## Sources

Checked **2026-08-12**.

- [NIST — Human Centered Design](https://www.nist.gov/itl/iad/human-centered-technologies/human-factors-human-centered-design).
- [W3C — WCAG 2.2 Overview](https://www.w3.org/WAI/standards-guidelines/wcag/).
- [NIST — AI RMF FAQs](https://www.nist.gov/itl/ai-risk-management-framework/ai-risk-management-framework-faqs) — trustworthiness across design, deployment, use, and evaluation.
