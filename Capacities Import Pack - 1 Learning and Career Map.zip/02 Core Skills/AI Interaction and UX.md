---
title: AI Interaction and UX
type: Concept
tags: ai-careers, core-skills, ux
source_path: 02 Core Skills/AI Interaction and UX.md
source_type: skill
scope: United States
level: beginner, intermediate, advanced
last_verified: '2026-08-12'
review_by: '2026-11-12'
---

# AI Interaction and UX

> **Source record:** [Vault source](https://github.com/msinclair25/EverythingAI/blob/main/02%20Core%20Skills/AI%20Interaction%20and%20UX.md) · last verified 2026-08-12 · review by 2026-11-12.

AI UX designs a relationship among user intent, uncertain system behavior, evidence, and control.

## State model

Design at least: empty/onboarding, input, working/progress, result, low confidence, insufficient evidence, refusal, partial completion, tool permission, human review, error, recovery, feedback, and history/memory control.

## Interaction principles

- set expectations at use, not in buried terms;
- show what source, model action, or tool produced a result;
- distinguish recommendation, draft, and executed action;
- support inspect/edit/reject/undo/escalate;
- confirm irreversible, external, financial, sensitive, or identity actions;
- preserve accessibility and a non-AI route where needed;
- avoid anthropomorphic design that induces misplaced trust;
- expose memory and give correction/deletion control;
- design feedback that captures the failing case and desired outcome.

## Research

Test mental models, trust calibration, error detection, review burden, accessibility, recourse, and longitudinal adaptation—not only task completion. Include people affected by outputs even when they are not direct users.

## Quiz

1. Why distinguish draft from executed action? 2. What is trust calibration? 3. Name four non-happy-path states. 4. Why research affected non-users?

> **Answers:**
> 1. It preserves agency and prevents mistaken external effects. 2. User reliance that appropriately tracks actual capability and limits. 3. Low evidence, refusal, partial result, permission, error, recovery, escalation, or conflict. 4. They can experience consequences without interacting with the interface.

## Flashcards

Trust calibration:: Aligning user reliance with actual system capability and uncertainty.

Recourse:: A meaningful path to question, correct, appeal, or remedy an outcome.

AI state model:: The complete set of visible states across request, evidence, action, failure, and recovery.

Next: [[AI UX and Product Designer]], [[AI UX Researcher]], or [[Conversation Designer]].
