# Interview Story — {{short title}}

> **Metadata:** Scope: United States · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: template
> **Tags:** ai-careers, template, interview

## Competencies demonstrated

## Situation

## Task and your ownership

## Actions and decisions

- alternatives considered:
- evidence used:
- stakeholders and disagreement:
- risk/ethics/escalation:

## Result

Use verified evidence; separate team and individual contribution.

## Evolution

What changed, what you learned, and what you would do now.

## Versions

- 30-second summary:
- 2-minute answer:
- deep follow-ups:
