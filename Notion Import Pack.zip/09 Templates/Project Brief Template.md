# {{project}}

> **Metadata:** Scope: United States · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: template
> **Tags:** ai-careers, template, projects

## Decision and audience

- Target role:
- User/affected group:
- Decision this evidence supports:

## Problem and baseline

## Scope and non-goals

## Constraints

- Data rights/privacy:
- Security/safety:
- Accessibility:
- Cost/time:
- Tools:

## Options and choice

| Option | Evidence for | Evidence against | Decision |
|---|---|---|---|

## Architecture or workflow

```mermaid
flowchart LR
    A["Input"] --> B["Process"] --> C["Validation"] --> D["Outcome"]
```

## Evaluation plan

- System/version:
- Population/cases:
- Baseline:
- Metrics/rubric:
- Slices:
- Failure severity:
- Release/stop threshold:

## Results and error analysis

## Risks, controls, and residual limits

## Cost/operations/adoption

## Artifacts

- [ ] README/brief
- [ ] data/source record
- [ ] architecture/process map
- [ ] evaluation report
- [ ] decision log
- [ ] demo/sample

## Next decision
