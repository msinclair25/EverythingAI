# Case — {{name}}

> **Metadata:** Scope: United States · Level: intermediate, advanced · Status: current · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: template
> **Tags:** ai-careers, template, technical-studio

> **Decision**
> One sentence: what choice this case forces.

## Situation and contract

- User / system:
- Task:
- Unacceptable outcomes:
- Latency / cost envelope:
- Escalation rule:

## Teaching envelope

Label all numbers as constructed. Include units and the review date.

| Quantity | Value | Unit | Why it matters |
|---|---|---|---|

## Closed-note prompt

Write contract, baseline, options, measurement, decision, and disproof before reading the worked path.

## Worked path

### Baseline

### Options compared

| Option | Gap it could close | Evidence required | Reject when |
|---|---|---|---|

### Decision

## Inspectable artifact

Paste a schema, trace, capacity table, policy, or eval spec. Critique it; do not treat it as a lab.

## Failure modes and reversal test

## Quiz

>

> **Answer key**
>

## Flashcards

Prompt:: Answer

## Transfer

- Roles:
- Interview drill:
- Portfolio translation:
