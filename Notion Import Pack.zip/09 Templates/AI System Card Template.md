# AI System Card — {{system}}

> **Metadata:** Scope: United States · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: template
> **Tags:** ai-careers, template, documentation

## Purpose, owner, and status

- Business/public owner:
- Technical owner:
- Risk owner:
- Lifecycle status:
- Last review / next review:

## Intended users, affected groups, uses, and prohibited uses

## System boundary

- Models/services:
- Data and retrieval:
- Tools/actions:
- Human decisions:
- Vendors/infrastructure:

## Data and rights

Sources, provenance, personal/sensitive data, permissions, retention, deletion, licenses, limitations.

## Behavior and evaluation

Claims, populations, cases, metrics, slices, thresholds, results, uncertainty, known failures.

## Controls

Security, privacy, safety, fairness/civil rights, accessibility, human review/recourse, monitoring, incident, change, retirement.

## Operation

SLOs, fallback, support, cost, logging, alert owners, rollback/compensation.

## Limitations and residual risk acceptance

## Change history
