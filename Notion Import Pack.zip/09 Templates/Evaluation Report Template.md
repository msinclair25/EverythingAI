# Evaluation Report — {{system}}

> **Metadata:** Scope: United States · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: template
> **Tags:** ai-careers, template, evaluation

## Decision and claim

- Decision informed:
- Claim tested:
- Criteria/threshold:

## System under test

- Code/config:
- Model/provider/version:
- Prompt/context:
- Retrieval corpus/index:
- Tools/permissions:
- Environment/date:

## Intended use and exclusions

## Evaluation design

- Target population and sampling:
- Cases and provenance:
- Baseline/comparator:
- Metrics/rubrics:
- Repeated trials and uncertainty:
- Human/model judges and validation:
- Slices and severity:

## Results

| Measure | Overall | Slice | Uncertainty | Threshold | Result |
|---|---:|---|---|---:|---|

## Failure analysis

| Category | Count/rate | Severity | Example ID | Cause hypothesis | Action |
|---|---:|---|---|---|---|

## Security, privacy, safety, accessibility, and rights checks

## Operational performance and cost

## Limitations and scope

## Recommendation, owner, and next checkpoint
