# Decision — {{decision}}

> **Metadata:** Scope: United States · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: template
> **Tags:** ai-careers, template, decisions

- Date:
- Owner:
- Status: proposed | accepted | superseded | retired
- Review trigger/date:

## Decision requested

## Context and constraints

## Options

| Option | Benefits | Costs/risks | Evidence | Unknowns |
|---|---|---|---|---|

## Decision and rationale

## Assumptions

## Controls and residual risk owner

## Success/stop criteria

## Consequences and follow-up

## Links

- Evaluation:
- System card:
- Sources:
