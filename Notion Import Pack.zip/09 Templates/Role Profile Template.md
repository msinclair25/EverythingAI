# {{role}}

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: release-1 · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: template
> **Tags:** ai-careers, template

> **Mission**
> One-sentence outcome ownership.

## Title reality and aliases

## Responsibilities and recurring decisions

## Level ladder

## Boundaries with adjacent roles

## Prerequisites and entry routes

## Competency map

## Study sequence

## Tool stack — free first and paid context

## Quiz

> **Answer key**

## Flashcards

Question:: Answer

## Interview preparation

## Suggested projects

### Beginner

### Intermediate

### Advanced

## Sources

Include official/primary sources and `Verified 2026-08-12`.
