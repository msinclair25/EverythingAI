# Source Review Queue

> Static snapshot generated 2026-10-14. The Obsidian Base remains the live review queue.

| Note | Type | Last verified | Review by | Status |
|---|---|---|---|---|
| [US Policy Source Register](<10%20Research/US%20Policy%20Source%20Register.md>) | source-register | 2026-08-12 | 2026-09-12 | release-1 |
| [Education AI](<08%20Industry%20Overlays/Education%20AI.md>) | industry-overlay | 2026-08-12 | 2026-09-12 | release-1 |
| [Financial Services and Insurance AI](<08%20Industry%20Overlays/Financial%20Services%20and%20Insurance%20AI.md>) | industry-overlay | 2026-08-12 | 2026-09-12 | current |
| [Healthcare and Life Sciences AI](<08%20Industry%20Overlays/Healthcare%20and%20Life%20Sciences%20AI.md>) | industry-overlay | 2026-08-12 | 2026-09-12 | current |
| [Legal and Professional Services AI](<08%20Industry%20Overlays/Legal%20and%20Professional%20Services%20AI.md>) | industry-overlay | 2026-08-12 | 2026-09-12 | release-1 |
| [Media Marketing and Entertainment AI](<08%20Industry%20Overlays/Media%20Marketing%20and%20Entertainment%20AI.md>) | industry-overlay | 2026-08-12 | 2026-09-12 | release-1 |
| [US Government and Public Sector AI](<08%20Industry%20Overlays/US%20Government%20and%20Public%20Sector%20AI.md>) | industry-overlay | 2026-08-12 | 2026-09-12 | current |
| [US AI Law and Policy Orientation](<02%20Core%20Skills/US%20AI%20Law%20and%20Policy%20Orientation.md>) | skill | 2026-08-12 | 2026-09-12 | release-1 |
