# Everything AI — Notion import

Generated 2026-08-25 from the Obsidian vault. The Obsidian vault remains the source of truth.

**Pack:** Full vault

## Start here

- [Everything AI Home](<00%20Start%20Here/Everything%20AI%20-%20Home.md>)
- [Note catalog database](Notion%20Note%20Catalog.csv)
- [Role Explorer](Notion%20Index%20-%20Role%20Explorer.md)
- [Source Review Queue](Notion%20Index%20-%20Source%20Review.md)

## Import

1. In Notion, open Settings → Import → ZIP, or use the /zip command.
2. Upload this ZIP and choose Convert Zip to pages.
3. Import the CSV separately if you want a searchable Notion database of notes.
4. Open Everything AI Home and use the linked route. Notion does not preserve Obsidian Bases, Canvas files, or anchor links, so static replacements are included.

## Known differences

- Wikilinks become ordinary Markdown links; heading anchors become page links or readable text.
- Obsidian callouts become bold-labeled Markdown blockquotes.
- Mermaid diagrams remain Mermaid code blocks. Render them separately or replace them with Notion images if you want visual diagrams.
- Bases become static Role Explorer and Source Review pages.
- Canvas becomes a linked Markdown landscape page.
- CSS, frontmatter, comments, and Obsidian-only embeds are converted or omitted.

