# AI Tool Atlas

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: published · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: hub
> **Tags:** atlas/tools, hub
> **Aliases:** Tool Atlas

Use this atlas to choose a tool class, shortlist products, and run a small proof of concept before committing money or sensitive data. It is a curated map of representative tools available to U.S. users—not an endorsement or an exhaustive directory.

> **Pricing and availability change often**
> Access labels were checked against official product, documentation, license, and pricing pages on **August 12, 2026**. A “free tier” may have quotas, feature restrictions, training/data-use terms, or require a payment method. Follow each official link immediately before purchasing.

> **Current addendum · 2026-08-24**
> Read [Tool Atlas — 2026-08-24 Update](<Tool%20Atlas%20%E2%80%94%202026-08-24%20Update.md>) for the current shortlist, free/open versus managed routes, a 90-minute proof-of-concept protocol, and a reusable tool decision card. Technical practices and role evidence live in [AI Tools and Practices Update — 2026-08-24](<../10%20Research/AI%20Tools%20and%20Practices%20Update%20%E2%80%94%202026-08-24.md>).
>
> For the Microsoft delivery path, use [Microsoft Azure DevOps and Foundry](<Microsoft%20Azure%20DevOps%20and%20Foundry.md>) and the worked [Case - Azure DevOps Foundry Release Gate](<../12%20Technical%20Studio/Case%20-%20Azure%20DevOps%20Foundry%20Release%20Gate.md>). It covers Azure DevOps MCP, Foundry hosted agents, WIF, environments, evaluation gates, traces, and rollback.
>
> For edge/web AI platforms, use [Cloudflare and Vercel AI](<Cloudflare%20and%20Vercel%20AI.md>) and the worked [Case - Edge AI Platform Choice](<../12%20Technical%20Studio/Case%20-%20Edge%20AI%20Platform%20Choice.md>). It compares Workers AI, AI Gateway, Agents, AI Search, Workflows, AI SDK 7, WorkflowAgent, Sandbox, Connect, and Fluid Compute.
>
> For the expanded technical domains, use [AI Expansion Atlas — 2026-08-24](<AI%20Expansion%20Atlas%20%E2%80%94%202026-08-24.md>). For the interoperability path, use [MCP Deep Dive — 2026-08-24](<MCP%20Deep%20Dive%20%E2%80%94%202026-08-24.md>). For the security path, use [OWASP and AI Security — 2026](<OWASP%20and%20AI%20Security%20%E2%80%94%202026.md>) and [Case - OWASP Agentic Security Review](<../12%20Technical%20Studio/Case%20-%20OWASP%20Agentic%20Security%20Review.md>).
>
> For the delivery and operations intersection, use [AI DevOps and Cloud Engineering — 2026-08-24](<AI%20DevOps%20and%20Cloud%20Engineering%20%E2%80%94%202026-08-24.md>). It connects AI-assisted DevOps with DevOps for AI: cloud architecture, IaC, CI/CD, identity federation, evaluation gates, Kubernetes, OpenTelemetry, supply chain, FinOps, roles, and portfolio projects.

## Start here

1. Read [Tool Selection and Access Guide](<Tool%20Selection%20and%20Access%20Guide.md>).
2. Choose the category that matches the job-to-be-done.
3. Start with the note's free-first path.
4. Compare on a representative task and fixed evaluation set.
5. Record security, privacy, accessibility, IP, support, and exit requirements before production use.

```mermaid
flowchart TD
    A["What are you trying to do?"] --> B{"Use a model or build one?"}
    B -->|"Use"| C{"Local control required?"}
    C -->|"Yes"| D["Local and Open Model Runtimes"]
    C -->|"No"| E["Foundation Model and API Providers"]
    B -->|"Build or adapt"| F{"Need training?"}
    F -->|"Yes"| G["Model Training and Fine-Tuning"]
    F -->|"No"| H{"Need a workflow or agent?"}
    H -->|"Agent code"| I["Agent and Orchestration Frameworks"]
    H -->|"Visual automation"| J["Automation and No-Code"]
    G --> K["MLOps and Platforms"]
    I --> L["Evaluation and Observability"]
    J --> L
    L --> M["Security and Red Teaming"]
    M --> N["Governance and Compliance"]
```

## Categories

| Need | Atlas note | Typical roles |
|---|---|---|
| Hosted general-purpose models and APIs | [Foundation Model and API Providers](<Foundation%20Model%20and%20API%20Providers.md>) | [AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>), [Prompt and Context Engineer](<../04%20Role%20Tracks/Nontechnical/Prompt%20and%20Context%20Engineer.md>), [AI Product Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Product%20Manager.md>) |
| Private/offline or self-hosted inference | [Local and Open Model Runtimes](<Local%20and%20Open%20Model%20Runtimes.md>) | [ML Engineer](<../04%20Role%20Tracks/Technical/ML%20Engineer.md>), [AI Infrastructure Engineer](<../04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>) |
| Code completion, review, and agents | [AI Coding Tools](<AI%20Coding%20Tools.md>) | [AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>), [Software Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>) |
| Stateful agents, tools, and workflows | [Agent and Orchestration Frameworks](<Agent%20and%20Orchestration%20Frameworks.md>) | [AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>), [Agentic AI Engineer](<../04%20Role%20Tracks/Technical/Agentic%20AI%20Engineer.md>) |
| Analysis environments and notebooks | [Data and Notebooks](<Data%20and%20Notebooks.md>) | [Data Scientist](<../04%20Role%20Tracks/Technical/Data%20Scientist%20-%20AI%20ML.md>), [AI Research Scientist](<../04%20Role%20Tracks/Technical/AI%20ML%20Research%20Scientist.md>) |
| Retrieval, semantic search, and memory | [Vector Search and RAG](<Vector%20Search%20and%20RAG.md>) | [RAG Engineer](<../04%20Role%20Tracks/Technical/LLM%20Engineer.md>), [AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>) |
| Adapt or align model behavior | [Model Training and Fine-Tuning](<Model%20Training%20and%20Fine-Tuning.md>) | [ML Engineer](<../04%20Role%20Tracks/Technical/ML%20Engineer.md>), [AI Research Scientist](<../04%20Role%20Tracks/Technical/AI%20ML%20Research%20Scientist.md>) |
| Track, deploy, register, and operate models | [MLOps and Platforms](<MLOps%20and%20Platforms.md>) | [MLOps Engineer](<../04%20Role%20Tracks/Technical/MLOps%20Engineer.md>), [ML Engineer](<../04%20Role%20Tracks/Technical/ML%20Engineer.md>) |
| AI × DevOps and cloud engineering delivery and operations | [AI DevOps and Cloud Engineering — 2026-08-24](<AI%20DevOps%20and%20Cloud%20Engineering%20%E2%80%94%202026-08-24.md>) | DevOps/cloud engineer, [AI Platform Engineer](<../04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>), [MLOps Engineer](<../04%20Role%20Tracks/Technical/MLOps%20Engineer.md>), SRE/AI SRE |
| Azure DevOps + Foundry delivery | [Microsoft Azure DevOps and Foundry](<Microsoft%20Azure%20DevOps%20and%20Foundry.md>) | [AI Platform Engineer](<../04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>), [MLOps Engineer](<../04%20Role%20Tracks/Technical/MLOps%20Engineer.md>), [Agentic AI Engineer](<../04%20Role%20Tracks/Technical/Agentic%20AI%20Engineer.md>), [AI Evaluation Engineer](<../04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>) |
| Edge/web AI application platforms | [Cloudflare and Vercel AI](<Cloudflare%20and%20Vercel%20AI.md>) | [AI Platform Engineer](<../04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>), [Agentic AI Engineer](<../04%20Role%20Tracks/Technical/Agentic%20AI%20Engineer.md>), [MLOps Engineer](<../04%20Role%20Tracks/Technical/MLOps%20Engineer.md>), [AI Security Engineer](<../04%20Role%20Tracks/Technical/AI%20Security%20Engineer.md>), [AI Product Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Product%20Manager.md>) |
| Expanded AI domains: protocols, reliability, device, provenance, reasoning, documents, privacy, sustainability, coding agents, physical AI, science, realtime | [AI Expansion Atlas — 2026-08-24](<AI%20Expansion%20Atlas%20%E2%80%94%202026-08-24.md>) | [AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>), [Agentic AI Engineer](<../04%20Role%20Tracks/Technical/Agentic%20AI%20Engineer.md>), [AI Platform Engineer](<../04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>), [MLOps Engineer](<../04%20Role%20Tracks/Technical/MLOps%20Engineer.md>), [AI Security Engineer](<../04%20Role%20Tracks/Technical/AI%20Security%20Engineer.md>), [AI ML Research Scientist](<../04%20Role%20Tracks/Technical/AI%20ML%20Research%20Scientist.md>) |
| MCP protocol, servers, clients, transports, OAuth, conformance, and operations | [MCP Deep Dive — 2026-08-24](<MCP%20Deep%20Dive%20%E2%80%94%202026-08-24.md>) | [Agentic AI Engineer](<../04%20Role%20Tracks/Technical/Agentic%20AI%20Engineer.md>), [AI Platform Engineer](<../04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>), [AI Security Engineer](<../04%20Role%20Tracks/Technical/AI%20Security%20Engineer.md>), [MLOps Engineer](<../04%20Role%20Tracks/Technical/MLOps%20Engineer.md>), [AI Evaluation Engineer](<../04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>) |
| Measure quality, traces, drift, and cost | [Evaluation and Observability](<Evaluation%20and%20Observability.md>) | [AI Evaluation Engineer](<../02%20Core%20Skills/AI%20Assurance%20Evidence.md>), [MLOps Engineer](<../04%20Role%20Tracks/Technical/MLOps%20Engineer.md>) |
| Probe abuse paths and vulnerabilities | [Security and Red Teaming](<Security%20and%20Red%20Teaming.md>) | [AI Security Engineer](<../02%20Core%20Skills/AI%20Threat%20Modeling.md>), [AI Red Team Specialist](<../02%20Core%20Skills/AI%20Threat%20Modeling.md>) |
| OWASP LLM, agentic, data, MCP, supply-chain, and incident controls | [OWASP and AI Security — 2026](<OWASP%20and%20AI%20Security%20%E2%80%94%202026.md>) | [AI Security Engineer](<../04%20Role%20Tracks/Technical/AI%20Security%20Engineer.md>), [AI Red Teamer](<../04%20Role%20Tracks/Technical/AI%20Red%20Teamer.md>), [Agentic AI Engineer](<../04%20Role%20Tracks/Technical/Agentic%20AI%20Engineer.md>), [AI Evaluation Engineer](<../04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>), [MLOps Engineer](<../04%20Role%20Tracks/Technical/MLOps%20Engineer.md>) |
| Create and review training/evaluation data | [Data Labeling and Human Feedback](<Data%20Labeling%20and%20Human%20Feedback.md>) | [AI Data Specialist](<../04%20Role%20Tracks/Technical/ML%20Data%20Engineer.md>), [RLHF Specialist](<../02%20Core%20Skills/Human%20Feedback%20Operations.md>) |
| Connect business apps with low/no code | [Automation and No-Code](<Automation%20and%20No-Code.md>) | [AI Automation Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Automation%20Specialist.md>), [AI Operations Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Program%20Manager.md>) |
| Generate and edit still visuals | [Image and Design](<Image%20and%20Design.md>) | [Generative AI Designer](<../04%20Role%20Tracks/Nontechnical/AI%20Image%20and%20Graphic%20Creator.md>), [AI Creative Director](<../04%20Role%20Tracks/Nontechnical/Generative%20AI%20Creative%20Director.md>) |
| Generate, edit, translate, or avatarize video | [Video and Avatars](<Video%20and%20Avatars.md>) | [AI Video Producer](<../04%20Role%20Tracks/Nontechnical/AI%20Video%20Producer.md>), [Instructional Designer](<../04%20Role%20Tracks/Nontechnical/AI%20Trainer%20and%20Educator.md>) |
| Speech, transcription, voice, and music | [Audio Speech and Music](<Audio%20Speech%20and%20Music.md>) | [Conversational AI Designer](<../04%20Role%20Tracks/Nontechnical/Conversation%20Designer.md>), [AI Audio Producer](<../04%20Role%20Tracks/Nontechnical/AI%20Audio%20and%20Music%20Specialist.md>) |
| General assistance and source-grounded research | [Productivity and Research](<Productivity%20and%20Research.md>) | [AI Research Analyst](<../04%20Role%20Tracks/Nontechnical/AI%20Business%20Analyst.md>), [Knowledge Manager](<../02%20Core%20Skills/Knowledge%20Architecture.md>) |
| Inventory, evidence, risk, policy, and controls | [Governance and Compliance](<Governance%20and%20Compliance.md>) | [AI Governance Specialist](<../03%20Career%20Map/Nontechnical/Governance%2C%20Risk%2C%20Policy%20and%20Ethics%20Careers.md>), [Responsible AI Lead](<../03%20Career%20Map/Nontechnical/Governance%2C%20Risk%2C%20Policy%20and%20Ethics%20Careers.md>) |
| GPUs, accelerators, hosting, and capacity | [Cloud Compute and Hardware](<Cloud%20Compute%20and%20Hardware.md>) | [AI Infrastructure Engineer](<../04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>), [MLOps Engineer](<../04%20Role%20Tracks/Technical/MLOps%20Engineer.md>) |

## Access legend

| Label | Meaning in this atlas |
|---|---|
| **Open source** | Source is published under an identified license. Hosting, support, model weights, and third-party services can still cost money. |
| **Open weights** | Model weights are downloadable under their own license; this does **not** automatically mean OSI open source or unrestricted commercial use. |
| **Free** | A usable no-fee product or self-hosted software is offered; you still supply hardware and labor where applicable. |
| **Free tier / trial** | A limited hosted allowance or time-limited evaluation exists; quotas and eligibility can change. |
| **Paid** | Subscription, usage-based billing, credit consumption, or paid compute is the normal production posture. |
| **Enterprise** | Contract, sales-assisted, private deployment, governance, indemnity, or enhanced support options are offered. |

## Cross-cutting rules

> **Free-first does not mean risk-free**
> Use public or synthetic data during learning. Treat prompts, uploads, logs, generated media, embeddings, and traces as data flows. Confirm retention, training use, deletion, region, subprocessors, accessibility, and commercial-use terms before using employer or client data.

- Separate **model quality** from the quality of retrieval, tools, prompts, and UX.
- Price a complete workflow: model tokens, tool calls, storage, vector operations, egress, GPU idle time, seats, observability, and human review.
- Prefer exportable artifacts and standard interfaces when switching costs matter.
- Require regression tests before changing a model, prompt, index, runtime, or provider.
- Keep a human approval gate for high-impact, irreversible, financial, legal, hiring, health, or safety actions.

## Research provenance

The official-source ledger is [Tool Source Registry](<../10%20Research/Tools/Tool%20Source%20Registry.md>). Research conventions and caveats are in [Tool Atlas Research Method](<../10%20Research/Tools/Tool%20Atlas%20Research%20Method.md>).
