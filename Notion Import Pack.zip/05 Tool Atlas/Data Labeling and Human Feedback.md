# Data Labeling and Human Feedback

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: published · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: tool-category
> **Tags:** atlas/tools, ai/data-labeling, ai/human-feedback

Labeling tools manage tasks, taxonomies, annotation interfaces, reviewers, consensus, and exports. Quality comes from clear definitions, calibrated annotators, adjudication, sampling, and documented provenance—not the UI alone.

## Representative comparison

| Tool/service | Access posture | Best fit | Main trade-off | Official |
|---|---|---|---|---|
| Label Studio | Apache-2.0 open-source Community Edition plus paid Enterprise/Cloud | Flexible text, image, audio, video, and LLM annotation | Self-host operations or enterprise cost | [open source](https://labelstud.io/) · [enterprise](https://humansignal.com/pricing/) |
| CVAT | MIT-licensed open source plus paid Online/Enterprise | Image and video computer-vision annotation | Specialized toward visual data | [GitHub](https://github.com/cvat-ai/cvat) · [online pricing](https://www.cvat.ai/pricing/cvat-online) |
| doccano | MIT-licensed open source | Lightweight text classification, sequence labeling, translation | Smaller workflow/governance feature set | [GitHub](https://github.com/doccano/doccano) |
| Argilla | Apache-2.0 open source | Human/LLM feedback datasets and iterative NLP workflows | Hosting/integration responsibility | [docs](https://docs.argilla.io/) · [GitHub](https://github.com/argilla-io/argilla) |
| Prodigy | Paid commercial license | Developer-controlled active learning and local annotation | Up-front license; narrower collaboration model | [pricing](https://prodi.gy/buy) · [docs](https://prodi.gy/docs) |
| Labelbox | Free, Starter, and Enterprise postures documented; usage/add-ons can be paid | Managed multimodal data and model-evaluation workflows | Usage-unit complexity and platform dependency | [plan limits](https://docs.labelbox.com/docs/limits) · [billing docs](https://docs.labelbox.com/docs/billing) |
| Scale AI | Limited no-cost entry where official pricing offers it; paid/enterprise services | Managed workforce/data engine and enterprise GenAI evaluation | Vendor cost, data handling, worker/process transparency | [pricing](https://scale.com/pricing) |
| Snorkel Flow | Paid enterprise platform | Programmatic labeling and data-centric AI at enterprise scale | Sales-led platform and methodology learning curve | [product](https://snorkel.ai/platform/) |

## Selection criteria

- Modality, ontology complexity, span/box/segmentation/ranking/pairwise interfaces.
- Bring-your-own workforce vs managed workforce; U.S. location/background requirements.
- Calibration, gold tasks, overlap, inter-annotator agreement, adjudication, and audit.
- PII/PHI/proprietary data, least privilege, export, deletion, and retention.
- Model-assisted labeling without anchoring reviewers to bad prelabels.
- Worker accessibility, compensation, psychological safety, and harmful-content support.
- Standard export format and versioned relation between source item, instruction, label, and reviewer.

## Free-first path

1. Draft the guideline and label 50 examples yourself.
2. Pilot with doccano, Argilla, CVAT, or Label Studio on public/synthetic data.
3. Use at least two annotators on a subset; measure disagreement and revise definitions.
4. Add adjudication and hidden gold items before scaling.
5. Buy a platform or workforce service for throughput, sensitive-data controls, specialist labor, or audit—not to compensate for an unclear taxonomy.

```mermaid
flowchart TD
    A["Need labeled data"] --> B["Define task, ontology, and examples"]
    B --> C["Small double-labeled pilot"]
    C --> D{"Agreement and downstream utility acceptable?"}
    D -->|"No"| E["Revise guideline, taxonomy, training"]
    E --> C
    D -->|"Yes"| F{"Sensitive or high-volume?"}
    F -->|"No"| G["Open-source/self-managed tool"]
    F -->|"Yes"| H["Approved enterprise platform/workforce"]
    G --> I["Ongoing QA and adjudication"]
    H --> I
```

## Role connections

[AI Data Specialist](<../04%20Role%20Tracks/Technical/ML%20Data%20Engineer.md>), [Data Annotation Lead](<../02%20Core%20Skills/Data%20Quality%20and%20Annotation.md>), [RLHF Specialist](<../02%20Core%20Skills/Human%20Feedback%20Operations.md>), [Data Scientist](<../04%20Role%20Tracks/Technical/Data%20Scientist%20-%20AI%20ML.md>), [AI Evaluation Engineer](<../02%20Core%20Skills/AI%20Assurance%20Evidence.md>), and [Responsible AI Lead](<../03%20Career%20Map/Nontechnical/Governance%2C%20Risk%2C%20Policy%20and%20Ethics%20Careers.md>).

## Official-source record

Verified **2026-08-12**. See [Tool Source Registry — Data labeling and human feedback](<../10%20Research/Tools/Tool%20Source%20Registry.md>).
