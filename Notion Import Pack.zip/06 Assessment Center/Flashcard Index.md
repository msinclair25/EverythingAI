# Flashcard Index

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: current · Verified: 2026-08-24 · Review by: 2026-11-24 · Type: index
> **Tags:** ai-careers, flashcards, index

> **October 13, 2026 update**
> New cards: [October 2026 Research Refresh](<../10%20Research/October%202026%20Research%20Refresh.md>), [Model and Agent Lifecycle Management](<../05%20Tool%20Atlas/Model%20and%20Agent%20Lifecycle%20Management.md>), [Cloud AI Operations — October 2026](<../05%20Tool%20Atlas/Cloud%20AI%20Operations%20%E2%80%94%20October%202026.md>), [MCP Contract Testing and Upgrade Readiness](<../05%20Tool%20Atlas/MCP%20Contract%20Testing%20and%20Upgrade%20Readiness.md>), [Case - Agent Memory Incident](<../12%20Technical%20Studio/Case%20-%20Agent%20Memory%20Incident.md>), [Case - Routing Quality and Capacity](<../12%20Technical%20Studio/Case%20-%20Routing%20Quality%20and%20Capacity.md>), [Technical Role Practice Workbook — October 2026](<../12%20Technical%20Studio/Technical%20Role%20Practice%20Workbook%20%E2%80%94%20October%202026.md>), and [US Career and Governance Update — October 2026](<../10%20Research/US%20Career%20and%20Governance%20Update%20%E2%80%94%20October%202026.md>).

Every foundation, bridge, and role note uses `Question:: Answer`. Hide text after `::`, answer aloud, then compare the idea.

## Foundations

1. [01 AI Systems and Vocabulary — Flashcards](<../01%20Foundations/01%20AI%20Systems%20and%20Vocabulary.md>)
2. [02 Math and Statistics for AI — Flashcards](<../01%20Foundations/02%20Math%20and%20Statistics%20for%20AI.md>)
3. [03 Python SQL Git and Software Foundations — Flashcards](<../01%20Foundations/03%20Python%20SQL%20Git%20and%20Software%20Foundations.md>)
4. [04 Data Foundations — Flashcards](<../01%20Foundations/04%20Data%20Foundations.md>)
5. [05 Machine Learning — Flashcards](<../01%20Foundations/05%20Machine%20Learning.md>)
6. [06 Deep Learning — Flashcards](<../01%20Foundations/06%20Deep%20Learning.md>)
7. [07 Transformers and Foundation Models — Flashcards](<../01%20Foundations/07%20Transformers%20and%20Foundation%20Models.md>)
8. [08 Generative AI Systems — Flashcards](<../01%20Foundations/08%20Generative%20AI%20Systems.md>)
9. [09 Prompt Context and Tool Use — Flashcards](<../01%20Foundations/09%20Prompt%20Context%20and%20Tool%20Use.md>)
10. [10 RAG and Knowledge Systems — Flashcards](<../01%20Foundations/10%20RAG%20and%20Knowledge%20Systems.md>)
11. [11 Agents and Automation — Flashcards](<../01%20Foundations/11%20Agents%20and%20Automation.md>)
12. [12 Evaluation Testing and Observability — Flashcards](<../01%20Foundations/12%20Evaluation%20Testing%20and%20Observability.md>)
13. [13 Deployment MLOps and Economics — Flashcards](<../01%20Foundations/13%20Deployment%20MLOps%20and%20Economics.md>)
14. [14 Security Privacy Safety and Responsible AI — Flashcards](<../01%20Foundations/14%20Security%20Privacy%20Safety%20and%20Responsible%20AI.md>)
15. [15 Product UX Business and Change — Flashcards](<../01%20Foundations/15%20Product%20UX%20Business%20and%20Change.md>)

## Technical studio — concepts (frozen 16)

16. [Tokens, Context, and Cost — Flashcards](<../12%20Technical%20Studio/Tokens%2C%20Context%2C%20and%20Cost.md>)
17. [Leakage and Contamination — Flashcards](<../12%20Technical%20Studio/Leakage%20and%20Contamination.md>)
18. [Metrics That Decide — Flashcards](<../12%20Technical%20Studio/Metrics%20That%20Decide.md>)
19. [Attention, Memory, and Inference — Flashcards](<../12%20Technical%20Studio/Attention%2C%20Memory%2C%20and%20Inference.md>)
20. [Context Engineering — Flashcards](<../12%20Technical%20Studio/Context%20Engineering.md>)
21. [Structured Outputs and Contracts — Flashcards](<../12%20Technical%20Studio/Structured%20Outputs%20and%20Contracts.md>)
22. [Retrieval Quality — Flashcards](<../12%20Technical%20Studio/Retrieval%20Quality.md>)
23. [Adaptation Methods — Flashcards](<../12%20Technical%20Studio/Adaptation%20Methods.md>)
24. [Embeddings and Similarity — Flashcards](<../12%20Technical%20Studio/Embeddings%20and%20Similarity.md>)
25. [The Training Loop — Flashcards](<../12%20Technical%20Studio/The%20Training%20Loop.md>)
26. [The Agent Loop — Flashcards](<../12%20Technical%20Studio/The%20Agent%20Loop.md>)
27. [Untrusted Context and Injection — Flashcards](<../12%20Technical%20Studio/Untrusted%20Context%20and%20Injection.md>)
28. [Sampling and Decoding — Flashcards](<../12%20Technical%20Studio/Sampling%20and%20Decoding.md>)
29. [Calibration — Flashcards](<../12%20Technical%20Studio/Calibration.md>)
30. [Quantization — Flashcards](<../12%20Technical%20Studio/Quantization.md>)
31. [Vision and Multimodal Systems — Flashcards](<../12%20Technical%20Studio/Vision%20and%20Multimodal%20Systems.md>)

## AI delivery and operations

32. [AI DevOps and Cloud Engineering — 2026-08-24 — Flashcards](<../05%20Tool%20Atlas/AI%20DevOps%20and%20Cloud%20Engineering%20%E2%80%94%202026-08-24.md>)

## Technical studio — cases

33. [Case - Prompt RAG Fine-Tune — Flashcards](<../12%20Technical%20Studio/Case%20-%20Prompt%20RAG%20Fine-Tune.md>)
34. [Case - Evaluation Harness — Flashcards](<../12%20Technical%20Studio/Case%20-%20Evaluation%20Harness.md>)
35. [Case - Agent Permissions — Flashcards](<../12%20Technical%20Studio/Case%20-%20Agent%20Permissions.md>)
36. [Case - Serving Capacity — Flashcards](<../12%20Technical%20Studio/Case%20-%20Serving%20Capacity.md>)
37. [Case - Retrieval Failure Autopsy — Flashcards](<../12%20Technical%20Studio/Case%20-%20Retrieval%20Failure%20Autopsy.md>)
38. [Case - Split Integrity — Flashcards](<../12%20Technical%20Studio/Case%20-%20Split%20Integrity.md>)
39. [Case - Vision Field Slice — Flashcards](<../12%20Technical%20Studio/Case%20-%20Vision%20Field%20Slice.md>)

## Thickened overlays

40. [Healthcare and Life Sciences AI — Flashcards](<../08%20Industry%20Overlays/Healthcare%20and%20Life%20Sciences%20AI.md>)
41. [Financial Services and Insurance AI — Flashcards](<../08%20Industry%20Overlays/Financial%20Services%20and%20Insurance%20AI.md>)
42. [US Government and Public Sector AI — Flashcards](<../08%20Industry%20Overlays/US%20Government%20and%20Public%20Sector%20AI.md>)

## Bridge skills

Open [Core Skills Hub](<../02%20Core%20Skills/Core%20Skills%20Hub.md>); every skill note includes a compact deck.

## Role decks

Open [AI Career Atlas](<../03%20Career%20Map/AI%20Career%20Atlas.md>) or the dynamic table below, choose a role, then jump to its **Flashcards** heading.

[Notion Index - Role Explorer](<../Notion%20Index%20-%20Role%20Explorer.md>)

## Search all cards

```query
"::" (path:"01 Foundations" OR path:"02 Core Skills" OR path:"04 Role Tracks" OR path:"12 Technical Studio")
```

## Spaced retrieval pattern

- Day 0: immediately after learning.
- Day 1: missed and low-confidence cards.
- Day 3: whole deck in random order.
- Day 7: scenario/example for each weak card.
- Day 14 and 30: mixed deck across modules.

Retire cards you can explain and apply consistently; do not optimize for deck size.
