# Builder path infographic

> **Metadata:** Scope: United States · Status: current · Verified: 2026-08-13 · Review by: 2026-11-12 · Type: visual-map
> **Tags:** ai-careers, visual-map, infographic

Four-week builder sequence. Generated with Grok Imagine (`grok-imagine-image-quality`, 16:9, 2K). Teaching graphic, not a credential.

![Builder path infographic](builder-4-week-path.png)

HTML fallback (crisp type, no model spelling risk): `builder-4-week-path.html`

Companion: [Builder 4-Week Syllabus](<../00%20Start%20Here/Builder%204-Week%20Syllabus.md>) · [Concept Spine Infographic](<Concept%20Spine%20Infographic.md>)
