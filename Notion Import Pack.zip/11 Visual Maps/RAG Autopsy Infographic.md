# RAG autopsy infographic

> **Metadata:** Scope: United States · Status: current · Verified: 2026-08-13 · Review by: 2026-11-12 · Type: visual-map
> **Tags:** ai-careers, visual-map, infographic

Layer-by-layer fail on the constructed stipend trace. Gold $175 / cited $130. Grok Imagine 2K.

![RAG autopsy infographic](rag-autopsy-infographic.png)

HTML fallback: `rag-autopsy-infographic.html`

Companion: [Case - Retrieval Failure Autopsy](<../12%20Technical%20Studio/Case%20-%20Retrieval%20Failure%20Autopsy.md>) · [Retrieval Quality](<../12%20Technical%20Studio/Retrieval%20Quality.md>)
