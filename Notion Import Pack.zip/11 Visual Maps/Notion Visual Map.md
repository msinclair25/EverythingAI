# AI Career Landscape

> Static Markdown replacement for the Obsidian Canvas. Use the linked role and hub pages after import.

# Everything AI - Home

# Technical AI Careers

# Build AI systems
[AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>) · [ML Engineer](<../04%20Role%20Tracks/Technical/ML%20Engineer.md>) · [LLM Engineer](<../04%20Role%20Tracks/Technical/LLM%20Engineer.md>) · [Agentic AI Engineer](<../04%20Role%20Tracks/Technical/Agentic%20AI%20Engineer.md>) · perception and robotics roles

# Data & knowledge
[Data Scientist - AI ML](<../04%20Role%20Tracks/Technical/Data%20Scientist%20-%20AI%20ML.md>) · [ML Data Engineer](<../04%20Role%20Tracks/Technical/ML%20Data%20Engineer.md>) · [RAG and Knowledge Engineer](<../04%20Role%20Tracks/Technical/RAG%20and%20Knowledge%20Engineer.md>) · [Taxonomist and Ontology Specialist](<../04%20Role%20Tracks/Nontechnical/Taxonomist%20and%20Ontology%20Specialist.md>) · [Knowledge Manager](<../04%20Role%20Tracks/Nontechnical/Knowledge%20Manager.md>)

# Operate & optimize
[MLOps Engineer](<../04%20Role%20Tracks/Technical/MLOps%20Engineer.md>) · [AI Platform Engineer](<../04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>) · [Inference and Performance Engineer](<../04%20Role%20Tracks/Technical/Inference%20and%20Performance%20Engineer.md>) · [AI Hardware and Accelerator Engineer](<../04%20Role%20Tracks/Technical/AI%20Hardware%20and%20Accelerator%20Engineer.md>)

# Evaluate, secure & govern
[AI Evaluation Engineer](<../04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>) · [AI Security Engineer](<../04%20Role%20Tracks/Technical/AI%20Security%20Engineer.md>) · [AI Red Teamer](<../04%20Role%20Tracks/Technical/AI%20Red%20Teamer.md>) · [AI Trust and Safety Operations Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Trust%20and%20Safety%20Operations%20Specialist.md>) · governance, risk, compliance and assurance roles

# Product & transformation
[AI Product Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Product%20Manager.md>) · [AI Program Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Program%20Manager.md>) · [AI Business Analyst](<../04%20Role%20Tracks/Nontechnical/AI%20Business%20Analyst.md>) · [AI Strategy Consultant](<../04%20Role%20Tracks/Nontechnical/AI%20Strategy%20Consultant.md>) · [AI Transformation Lead](<../04%20Role%20Tracks/Nontechnical/AI%20Transformation%20Lead.md>) · [Chief AI Officer and Head of AI](<../04%20Role%20Tracks/Nontechnical/Chief%20AI%20Officer%20and%20Head%20of%20AI.md>) · [AI Automation Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Automation%20Specialist.md>)

# Go-to-market, customer & education
[AI Solutions Architect](<../04%20Role%20Tracks/Nontechnical/AI%20Solutions%20Architect.md>) · [AI Sales Engineer](<../04%20Role%20Tracks/Nontechnical/AI%20Sales%20Engineer.md>) · [AI Enterprise Account Executive](<../04%20Role%20Tracks/Nontechnical/AI%20Enterprise%20Account%20Executive.md>) · [AI Product Marketing Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Product%20Marketing%20Manager.md>) · [AI Strategic Partnerships Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Strategic%20Partnerships%20Manager.md>) · [AI Customer Success Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Customer%20Success%20Manager.md>) · [AI Technical Support and User Operations Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Technical%20Support%20and%20User%20Operations%20Specialist.md>) · [AI Developer Relations and Advocate](<../04%20Role%20Tracks/Nontechnical/AI%20Developer%20Relations%20and%20Advocate.md>) · [AI Trainer and Educator](<../04%20Role%20Tracks/Nontechnical/AI%20Trainer%20and%20Educator.md>)

# UX, conversation & content
[AI UX and Product Designer](<../04%20Role%20Tracks/Nontechnical/AI%20UX%20and%20Product%20Designer.md>) · [AI UX Researcher](<../04%20Role%20Tracks/Nontechnical/AI%20UX%20Researcher.md>) · [Conversation Designer](<../04%20Role%20Tracks/Nontechnical/Conversation%20Designer.md>) · [AI Content Designer](<../04%20Role%20Tracks/Nontechnical/AI%20Content%20Designer.md>) · [Prompt and Context Engineer](<../04%20Role%20Tracks/Nontechnical/Prompt%20and%20Context%20Engineer.md>)

# Creative media
[Generative AI Creative Director](<../04%20Role%20Tracks/Nontechnical/Generative%20AI%20Creative%20Director.md>) · [AI Image and Graphic Creator](<../04%20Role%20Tracks/Nontechnical/AI%20Image%20and%20Graphic%20Creator.md>) · [AI Video Producer](<../04%20Role%20Tracks/Nontechnical/AI%20Video%20Producer.md>) · [AI Audio and Music Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Audio%20and%20Music%20Specialist.md>)

# Human data & talent operations
[Data Annotator and AI Rater](<../04%20Role%20Tracks/Nontechnical/Data%20Annotator%20and%20AI%20Rater.md>) · [Human Feedback Specialist](<../04%20Role%20Tracks/Nontechnical/Human-Feedback%20Specialist.md>) · [AI Data Operations Manager](<../04%20Role%20Tracks/Nontechnical/AI%20Data%20Operations%20Manager.md>) · [AI Talent and Recruiting Specialist](<../04%20Role%20Tracks/Nontechnical/AI%20Talent%20and%20Recruiting%20Specialist.md>)

# Choose Your AI Career

# AI Tool Atlas

# Foundations Hub
