# Sampling and decoding

> **Metadata:** Scope: United States · Level: beginner, intermediate · Status: current · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: technical-concept
> **Tags:** technical-studio, concept/decoding, jargon
> **Aliases:** Temperature, Top-p Top-k

> **Plain idea**
> After the model scores the next token, **decoding** picks which token actually appears. That knob changes *variety*, not *knowledge*. Lowering temperature cannot insert a stipend amount that is not in the weights or the window. It can only make the model more stubborn about whatever it already believes.

## Why this concept exists

“Just turn the temperature down” is the most common fake factuality fix in interviews and Slack. Decoding exists because language is not one path: you need a way to choose among high-scoring next tokens. The jargon names those choosers so you can say what you changed when output got more repetitive, more random, or more wrong in a new way.

## Jargon

| Term | What it names | Common mix-up |
|---|---|---|
| **Logits** | Raw scores for each vocabulary item, before softmax. | Not probabilities yet. |
| **Softmax** | Turns logits into a probability distribution over the next token. | A high probability is still “likely under the model,” not “true.” |
| **Greedy decoding** | Always pick the current top token. | Deterministic-ish; can be bland and still wrong. |
| **Temperature \(T\)** | Divide logits by \(T\) before softmax. \(T<1\) sharpens; \(T>1\) flattens. | Not a truth dial. Not the same thing as **temperature scaling** in [Calibration](<Calibration.md>). |
| **Top-k** | Keep only the \(k\) highest-probability tokens, then sample. | Small \(k\) ≈ near-greedy. |
| **Top-p / nucleus** | Keep the smallest set whose probabilities sum to \(p\), then sample. | Adapts the set size; 0.9 is a common teaching default, not a law. |
| **Seed** | Fixes the random number generator. | Same seed + same inputs ≈ same sample. Different hardware can still drift. |
| **Beam search** | Keep several partial sequences and expand the best. | Useful for some structured tasks; not the default for chat. |
| **Repetition / presence penalty** | Extra score pressure against repeating tokens. | Can fix loops; can also block legal repeats (“2026 2026 policy”). |

## Worked teaching distribution

> **Constructed three-token vocabulary so the arithmetic is visible.**

Logits for the next token: `stipend=2.0`, `refund=1.0`, `banana=0.0`.

Softmax at \(T=1\):

\[
p \propto e^{2},\; e^{1},\; e^{0} \approx 7.39,\; 2.72,\; 1.00
\]

Share: **0.67 / 0.24 / 0.09**.

At \(T=0.5\) (sharper): logits become 4.0, 2.0, 0.0 → ≈ **0.87 / 0.12 / 0.02**.

At \(T=2.0\) (flatter): 1.0, 0.5, 0.0 → ≈ **0.51 / 0.31 / 0.18**.

If the *correct* next token is a number that is **not in this distribution at all**, no \(T\) will invent it. You need retrieval, a tool, or different weights. See [Adaptation Methods](<Adaptation%20Methods.md>).

If you need a JSON field to be one of three enums, do not “hope greedy is enough.” Use a [Structured Outputs and Contracts](<Structured%20Outputs%20and%20Contracts.md>) schema. Decoding is the wrong control.

## What to practice saying

- “Temperature changes the shape of the next-token distribution. It does not add facts.”
- “I will report \(T\), top-p, and whether the run was sampled, when I quote an eval.”
- “For money or labels, I constrain the schema, not the temperature.”
- “A single lucky sample is not a quality metric; repeat the draw.”

## Quiz

1. What does \(T < 1\) do to the next-token distribution?
2. Why can greedy decoding still be factually wrong?
3. When is top-p a better first knob than temperature?
4. Why must an eval name the decoding settings?
5. Decoding vs calibration “temperature” — what is different?

> **Answer key**
> 1. It sharpens: more mass on already-likely tokens. 2. The top token can be a fluent falsehood. 3. When you want to drop the long tail of nonsense without collapsing to one token. 4. Because sampled systems are random variables; unreplicated scores are not comparable. 5. Decoding \(T\) reshapes generation. Calibration temperature (see [Calibration](<Calibration.md>)) rescales *confidence scores* after the fact and does not pick tokens.

## Flashcards

Decoding:: The rule that turns next-token scores into an actual token.

Temperature (decoding):: A sharpness knob on the next-token distribution; not a factuality control.

Greedy decoding:: Always emit the current highest-scoring token.

Top-p / nucleus:: Sample from the smallest set of tokens whose probabilities sum to p.

Top-k:: Sample only from the k highest-scoring tokens.

Logits:: Unnormalized next-token scores, before softmax.

Softmax:: Map logits to a probability distribution over the vocabulary.

## Transfer

- Next concept: [Calibration](<Calibration.md>).
- Cases: [Case - Evaluation Harness](<Case%20-%20Evaluation%20Harness.md>) (repeat sampled runs), [Case - Prompt RAG Fine-Tune](<Case%20-%20Prompt%20RAG%20Fine-Tune.md>).
- Foundation: [07 Transformers and Foundation Models](<../01%20Foundations/07%20Transformers%20and%20Foundation%20Models.md>).
