# Concept spine freeze

> **Metadata:** Scope: United States · Level: beginner, intermediate, advanced · Status: current · Verified: 2026-08-12 · Review by: 2026-11-12 · Type: guide
> **Tags:** technical-studio, curriculum
> **Aliases:** Frozen Concept Spine

> **Policy**
> The builder concept spine is **frozen at 16 notes**. New concept notes are allowed only under the exception rule below. Depth now comes from cases, overlays, syllabus, and exams — not from note 17.

## Frozen set (do not grow)

The ordered list in [Technical Skills Hub](<Technical%20Skills%20Hub.md>) is the spine. Do not insert a 17th “also important” concept because a blog post used a new word. Add the word to [AI Glossary](<../AI%20Glossary.md>) and point at an existing note.

Speech and robotics **roles** already exist. They do not automatically unlock new spine notes. They unlock a note only when you are also shipping a case that cannot be taught with [Vision and Multimodal Systems](<Vision%20and%20Multimodal%20Systems.md>), [The Agent Loop](<The%20Agent%20Loop.md>), or [The Training Loop](<The%20Training%20Loop.md>).

## Exception rule

Open a new `type: technical-concept` note only if **all** of these are true:

1. A technical **role** in this vault has no concept that unpacks its core jargon.
2. You are shipping a **case** in the same change that uses that jargon under a contract.
3. The term cannot be a glossary row plus a paragraph on an existing note.
4. The note will follow the six-part template (plain idea, why, jargon, teaching numbers, quiz, transfer).

If any item is false, patch an existing note or the glossary.

## Why freeze

Sixteen notes already cover the terms that show up in AI/ML/LLM design reviews: tokens, leakage, metrics, KV, context, contracts, retrieval, adaptation, embeddings, training, agents, injection, decoding, calibration, quantization, vision. More notes without a syllabus make the vault harder to *use*.

## Next

Use the set. Open [Builder 4-Week Syllabus](<../00%20Start%20Here/Builder%204-Week%20Syllabus.md>).
