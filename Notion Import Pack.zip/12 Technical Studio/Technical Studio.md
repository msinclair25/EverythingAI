# Technical Studio

> **Metadata:** Scope: United States · Level: intermediate, advanced · Status: current · Verified: 2026-08-24 · Review by: 2026-11-24 · Type: hub
> **Tags:** ai-careers, technical-studio, hub
> **Aliases:** Technical Practice Layer, Worked Technical Cases

> **Outcome**
> Learn the technical ideas, then rehearse the decisions. [Technical Skills Hub](<Technical%20Skills%20Hub.md>) teaches core concepts, why they exist, and the jargon. Each case then gives a bounded problem, a contract, constructed teaching numbers, and a ship/stop choice. This layer sits between [Foundations Hub](<../01%20Foundations/Foundations%20Hub.md>) and a role in [Technical AI Careers](<../03%20Career%20Map/Technical/Technical%20AI%20Careers.md>).

> **Not a lab track**
> Release 1 deliberately excluded prescriptive labs. The studio keeps that rule. You do not follow steps to produce a demo. You work a case the way a senior engineer would: define the contract, compare interventions, measure, choose, and write the decision. Code appears only as an **inspectable artifact** you can critique.

## Why this layer exists

[Foundations Hub](<../01%20Foundations/Foundations%20Hub.md>) names the ideas. [Technical Skills Hub](<Technical%20Skills%20Hub.md>) explains why they exist and what the jargon means. [Technical AI Careers](<../03%20Career%20Map/Technical/Technical%20AI%20Careers.md>) teaches ownership. Cases force a choice under incomplete evidence.

```mermaid
flowchart TB
    F["Foundations: name the idea"] --> C["Concepts: why + jargon"]
    C --> S["Cases: decide under a contract"]
    S --> R["Role track: own the loop"]
    R --> I["Interview + portfolio"]
```

## How to use it

1. Walk the concept spine in [Technical Skills Hub](<Technical%20Skills%20Hub.md>) (sixteen notes, in order).
2. Keep [AI Glossary](<../AI%20Glossary.md>) open. Say each new word aloud in a non-engineer sentence.
3. Read [How to Study a Technical Case](<How%20to%20Study%20a%20Technical%20Case.md>) once.
4. Work one case closed-note: contract, options, decision, then the worked path.
5. Score yourself with the rubric. File a [Decision Record Template](<../09%20Templates/Decision%20Record%20Template.md>).
6. Only then open the matching role profile.

## Concept spine

Start here if a term is fuzzy. Full order and “why this note” lives in [Technical Skills Hub](<Technical%20Skills%20Hub.md>).

1. [Tokens, Context, and Cost](<Tokens%2C%20Context%2C%20and%20Cost.md>)
2. [Leakage and Contamination](<Leakage%20and%20Contamination.md>)
3. [Metrics That Decide](<Metrics%20That%20Decide.md>)
4. [Attention, Memory, and Inference](<Attention%2C%20Memory%2C%20and%20Inference.md>)
5. [Context Engineering](<Context%20Engineering.md>)
6. [Structured Outputs and Contracts](<Structured%20Outputs%20and%20Contracts.md>)
7. [Retrieval Quality](<Retrieval%20Quality.md>)
8. [Adaptation Methods](<Adaptation%20Methods.md>)
9. [Embeddings and Similarity](<Embeddings%20and%20Similarity.md>)
10. [The Training Loop](<The%20Training%20Loop.md>)
11. [The Agent Loop](<The%20Agent%20Loop.md>)
12. [Untrusted Context and Injection](<Untrusted%20Context%20and%20Injection.md>)
13. [Sampling and Decoding](<Sampling%20and%20Decoding.md>)
14. [Calibration](<Calibration.md>)
15. [Quantization](<Quantization.md>)
16. [Vision and Multimodal Systems](<Vision%20and%20Multimodal%20Systems.md>)

## Case index

| Case | Decision you practice | Primary roles |
|---|---|---|
| [Case - Prompt RAG Fine-Tune](<Case%20-%20Prompt%20RAG%20Fine-Tune.md>) | Which intervention closes the actual gap? | [AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>), [LLM Engineer](<../04%20Role%20Tracks/Technical/LLM%20Engineer.md>), [RAG and Knowledge Engineer](<../04%20Role%20Tracks/Technical/RAG%20and%20Knowledge%20Engineer.md>) |
| [Case - Evaluation Harness](<Case%20-%20Evaluation%20Harness.md>) | What evidence is enough to ship or stop? | [AI Evaluation Engineer](<../04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>), [LLM Engineer](<../04%20Role%20Tracks/Technical/LLM%20Engineer.md>), [AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>) |
| [Case - Agent Permissions](<Case%20-%20Agent%20Permissions.md>) | What can the model request versus what the system may do? | [Agentic AI Engineer](<../04%20Role%20Tracks/Technical/Agentic%20AI%20Engineer.md>), [AI Security Engineer](<../04%20Role%20Tracks/Technical/AI%20Security%20Engineer.md>), [AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>) |
| [Case - Serving Capacity](<Case%20-%20Serving%20Capacity.md>) | Can this SLO be met at the stated cost? | [Inference and Performance Engineer](<../04%20Role%20Tracks/Technical/Inference%20and%20Performance%20Engineer.md>), [LLM Engineer](<../04%20Role%20Tracks/Technical/LLM%20Engineer.md>), [AI Platform Engineer](<../04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>) |
| [Case - Retrieval Failure Autopsy](<Case%20-%20Retrieval%20Failure%20Autopsy.md>) | Which layer actually failed? | [RAG and Knowledge Engineer](<../04%20Role%20Tracks/Technical/RAG%20and%20Knowledge%20Engineer.md>), [AI Evaluation Engineer](<../04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>), [AI Engineer](<../04%20Role%20Tracks/Technical/AI%20Engineer.md>) |
| [Case - Split Integrity](<Case%20-%20Split%20Integrity.md>) | Is this score honest enough to ship? | [ML Engineer](<../04%20Role%20Tracks/Technical/ML%20Engineer.md>), [AI Evaluation Engineer](<../04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>), [Data Scientist - AI ML](<../04%20Role%20Tracks/Technical/Data%20Scientist%20-%20AI%20ML.md>) |
| [Case - Vision Field Slice](<Case%20-%20Vision%20Field%20Slice.md>) | Does the night/camera slice meet the contract? | [Computer Vision Engineer](<../04%20Role%20Tracks/Technical/Computer%20Vision%20Engineer.md>), [AI Evaluation Engineer](<../04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>) |
| [Case - Azure DevOps Foundry Release Gate](<Case%20-%20Azure%20DevOps%20Foundry%20Release%20Gate.md>) | Can this agent change safely reach production? | [AI Platform Engineer](<../04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>), [MLOps Engineer](<../04%20Role%20Tracks/Technical/MLOps%20Engineer.md>), [Agentic AI Engineer](<../04%20Role%20Tracks/Technical/Agentic%20AI%20Engineer.md>), [AI Evaluation Engineer](<../04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>) |
| [Case - Edge AI Platform Choice](<Case%20-%20Edge%20AI%20Platform%20Choice.md>) | Which platform boundary makes this agent safer and more operable? | [AI Platform Engineer](<../04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>), [Agentic AI Engineer](<../04%20Role%20Tracks/Technical/Agentic%20AI%20Engineer.md>), [MLOps Engineer](<../04%20Role%20Tracks/Technical/MLOps%20Engineer.md>), [AI Security Engineer](<../04%20Role%20Tracks/Technical/AI%20Security%20Engineer.md>) |
| [Case - OWASP Agentic Security Review](<Case%20-%20OWASP%20Agentic%20Security%20Review.md>) | Can this tool-using, memory-bearing agent be piloted without crossing unsafe trust boundaries? | [AI Security Engineer](<../04%20Role%20Tracks/Technical/AI%20Security%20Engineer.md>), [Agentic AI Engineer](<../04%20Role%20Tracks/Technical/Agentic%20AI%20Engineer.md>), [AI Evaluation Engineer](<../04%20Role%20Tracks/Technical/AI%20Evaluation%20Engineer.md>), [AI Platform Engineer](<../04%20Role%20Tracks/Technical/AI%20Platform%20Engineer.md>) |

## Interview transfer

After two cases, use [Technical Interview Drills](<Technical%20Interview%20Drills.md>). The drills reuse studio contracts so you practice explaining the same decisions under time pressure.

## What “good” looks like

You are ready to leave a case when you can:

- state the owned outcome without naming a vendor;
- name the baseline and why it is the baseline;
- reject at least one fashionable option with a measurement reason;
- report quality **and** an operational or risk metric;
- list the failure that would reverse the decision;
- write a one-page decision record another engineer could operate from.

The scoring rubric lives in [How to Study a Technical Case](<How%20to%20Study%20a%20Technical%20Case.md>). The spine does not grow: [Concept Spine Freeze](<Concept%20Spine%20Freeze.md>). Sequence: [Builder 4-Week Syllabus](<../00%20Start%20Here/Builder%204-Week%20Syllabus.md>). Exam: [Technical Cumulative Check](<../06%20Assessment%20Center/Technical%20Cumulative%20Check.md>). Pictures: [Visual Maps Hub](<../11%20Visual%20Maps/Visual%20Maps%20Hub.md>).

## Boundaries

- Studio cases are **teaching scenarios**. Numbers are constructed and labeled. They are not production measurements, vendor benchmarks, or salary/cost quotes.
- Tool names are examples of a class. Prefer the selection method in [AI Tool Atlas](<../05%20Tool%20Atlas/AI%20Tool%20Atlas.md>) over memorizing a stack.
- A completed case is not a portfolio project. Use [Project Bank](<../07%20Interview%20and%20Portfolio/Project%20Bank.md>) to produce original evidence.

## Next

Start with [Technical Skills Hub](<Technical%20Skills%20Hub.md>), then [How to Study a Technical Case](<How%20to%20Study%20a%20Technical%20Case.md>). For the delivery/operations path, read [AI DevOps and Cloud Engineering — 2026-08-24](<../05%20Tool%20Atlas/AI%20DevOps%20and%20Cloud%20Engineering%20%E2%80%94%202026-08-24.md>), then compare [Microsoft Azure DevOps and Foundry](<../05%20Tool%20Atlas/Microsoft%20Azure%20DevOps%20and%20Foundry.md>) or [Cloudflare and Vercel AI](<../05%20Tool%20Atlas/Cloudflare%20and%20Vercel%20AI.md>) and work the matching release/architecture case. For the interoperability path, read [MCP Deep Dive — 2026-08-24](<../05%20Tool%20Atlas/MCP%20Deep%20Dive%20%E2%80%94%202026-08-24.md>) and build one of its projects. For the security path, read [OWASP and AI Security — 2026](<../05%20Tool%20Atlas/OWASP%20and%20AI%20Security%20%E2%80%94%202026.md>) and work [Case - OWASP Agentic Security Review](<Case%20-%20OWASP%20Agentic%20Security%20Review.md>); otherwise begin with [Case - Prompt RAG Fine-Tune](<Case%20-%20Prompt%20RAG%20Fine-Tune.md>).
