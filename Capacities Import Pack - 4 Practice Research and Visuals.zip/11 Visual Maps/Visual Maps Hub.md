---
title: Visual Maps Hub
type: Page
tags: ai-careers, visual-map, hub
source_path: 11 Visual Maps/Visual Maps Hub.md
source_type: hub
scope: United States
last_verified: '2026-08-12'
review_by: '2026-11-12'
---

# Visual Maps Hub

> **Source record:** [Vault source](https://github.com/msinclair25/EverythingAI/blob/main/11%20Visual%20Maps/Visual%20Maps%20Hub.md) · last verified 2026-08-12 · review by 2026-11-12.

Pictures for the technical path. They are teaching graphics, not evidence.

> **Easier diagram reading:**
> Mermaid diagrams now fit the available note width and cap their height to the reading viewport. Dense diagrams keep an internal scroll only when necessary. Open the three infographic notes directly for a wider, screen-safe focus layout.

## Infographics (HTML)

- [[Builder Path Infographic]] — four-week sequence
- [[Concept Spine Infographic]] — frozen 16 questions
- [[RAG Autopsy Infographic]] — packing vs authority fail

Open the `.html` files in a browser for the full layout.

## Other maps

- [[Capacities Visual Map]]
- [[Free-First Tool Paths]]
- [[AI System Lifecycle Map]]

## Style

Dark, monospace, vault-native. New graphics go in `11 Visual Maps/` and get a markdown wrapper so they wikilink.
