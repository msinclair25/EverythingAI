---
title: Builder Path Infographic
type: Page
tags: ai-careers, visual-map, infographic
source_path: 11 Visual Maps/Builder Path Infographic.md
source_type: visual-map
scope: United States
last_verified: '2026-08-13'
review_by: '2026-11-12'
---

# Builder path infographic

> **Source record:** [Vault source](https://github.com/msinclair25/EverythingAI/blob/main/11%20Visual%20Maps/Builder%20Path%20Infographic.md) · last verified 2026-08-13 · review by 2026-11-12.

Four-week builder sequence. Generated with Grok Imagine (`grok-imagine-image-quality`, 16:9, 2K). Teaching graphic, not a credential.

![Builder path infographic](builder-4-week-path.png)


Companion: [[Builder 4-Week Syllabus]] · [[Concept Spine Infographic]]
