---
title: RAG Autopsy Infographic
type: Page
tags: ai-careers, visual-map, infographic
source_path: 11 Visual Maps/RAG Autopsy Infographic.md
source_type: visual-map
scope: United States
last_verified: '2026-08-13'
review_by: '2026-11-12'
---

# RAG autopsy infographic

> **Source record:** [Vault source](https://github.com/msinclair25/EverythingAI/blob/main/11%20Visual%20Maps/RAG%20Autopsy%20Infographic.md) · last verified 2026-08-13 · review by 2026-11-12.

Layer-by-layer fail on the constructed stipend trace. Gold $175 / cited $130. Grok Imagine 2K.

![RAG autopsy infographic](rag-autopsy-infographic.png)

HTML fallback: `rag-autopsy-infographic.html`

Companion: [[Case - Retrieval Failure Autopsy]] · [[Retrieval Quality]]
