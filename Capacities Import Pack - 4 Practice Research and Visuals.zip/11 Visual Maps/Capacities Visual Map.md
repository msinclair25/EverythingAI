---
title: Capacities Visual Map
type: Page
tags: everything-ai, import-directory
---

# Capacities Visual Map

Readable index of the Obsidian AI Career Landscape Canvas.

- [[Everything AI - Home]]
- [[Technical AI Careers]]
- # Build AI systems [[AI Engineer]] · [[ML Engineer]] · [[LLM Engineer]] · [[Agentic AI Engineer]] · perception and robotics roles
- # Data & knowledge [[Data Scientist - AI ML]] · [[ML Data Engineer]] · [[RAG and Knowledge Engineer]] · [[Taxonomist and Ontology Specialist]] · [[Knowledge Manager]]
- # Operate & optimize [[MLOps Engineer]] · [[AI Platform Engineer]] · [[Inference and Performance Engineer]] · [[AI Hardware and Accelerator Engineer]]
- # Evaluate, secure & govern [[AI Evaluation Engineer]] · [[AI Security Engineer]] · [[AI Red Teamer]] · [[AI Trust and Safety Operations Specialist]] · governance, risk, compliance and assurance roles
- # Product & transformation [[AI Product Manager]] · [[AI Program Manager]] · [[AI Business Analyst]] · [[AI Strategy Consultant]] · [[AI Transformation Lead]] · [[Chief AI Officer and Head of AI]] · [[AI Automation Specialist]]
- # Go-to-market, customer & education [[AI Solutions Architect]] · [[AI Sales Engineer]] · [[AI Enterprise Account Executive]] · [[AI Product Marketing Manager]] · [[AI Strategic Partnerships Manager]] · [[AI Customer Success Manager]] · [[AI Technical Support and User Operations Specialist]] · [[AI Developer Relations and Advocate]] · [[AI Trainer and Educator]]
- # UX, conversation & content [[AI UX and Product Designer]] · [[AI UX Researcher]] · [[Conversation Designer]] · [[AI Content Designer]] · [[Prompt and Context Engineer]]
- # Creative media [[Generative AI Creative Director]] · [[AI Image and Graphic Creator]] · [[AI Video Producer]] · [[AI Audio and Music Specialist]]
- # Human data & talent operations [[Data Annotator and AI Rater]] · [[Human-Feedback Specialist|Human Feedback Specialist]] · [[AI Data Operations Manager]] · [[AI Talent and Recruiting Specialist]]
- [[Choose Your AI Career]]
- [[AI Tool Atlas]]
- [[Foundations Hub]]
