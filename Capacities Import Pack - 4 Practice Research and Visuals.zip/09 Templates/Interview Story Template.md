---
title: Interview Story Template
type: Page
tags: ai-careers, template, interview
source_path: '09 Templates/Interview Story Template.md'
source_type: template
scope: United States
last_verified: '2026-08-12'
review_by: '2026-11-12'
---

# Interview Story — {{short title}}

> **Source record:** [Vault source](https://github.com/msinclair25/EverythingAI/blob/main/09%20Templates/Interview%20Story%20Template.md) · last verified 2026-08-12 · review by 2026-11-12.

## Competencies demonstrated

## Situation

## Task and your ownership

## Actions and decisions

- alternatives considered:
- evidence used:
- stakeholders and disagreement:
- risk/ethics/escalation:

## Result

Use verified evidence; separate team and individual contribution.

## Evolution

What changed, what you learned, and what you would do now.

## Versions

- 30-second summary:
- 2-minute answer:
- deep follow-ups:
