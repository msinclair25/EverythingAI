---
title: Decision Record Template
type: Page
tags: ai-careers, template, decisions
source_path: '09 Templates/Decision Record Template.md'
source_type: template
scope: United States
last_verified: '2026-08-12'
review_by: '2026-11-12'
---

# Decision — {{decision}}

> **Source record:** [Vault source](https://github.com/msinclair25/EverythingAI/blob/main/09%20Templates/Decision%20Record%20Template.md) · last verified 2026-08-12 · review by 2026-11-12.

- Date:
- Owner:
- Status: proposed | accepted | superseded | retired
- Review trigger/date:

## Decision requested

## Context and constraints

## Options

| Option | Benefits | Costs/risks | Evidence | Unknowns |
|---|---|---|---|---|

## Decision and rationale

## Assumptions

## Controls and residual risk owner

## Success/stop criteria

## Consequences and follow-up

## Links

- Evaluation:
- System card:
- Sources:
