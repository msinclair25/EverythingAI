---
title: Role Profile Template
type: Page
tags: ai-careers, template
source_path: '09 Templates/Role Profile Template.md'
source_type: template
scope: United States
level: beginner, intermediate, advanced
last_verified: '2026-08-12'
review_by: '2026-11-12'
---

# {{role}}

> **Source record:** [Vault source](https://github.com/msinclair25/EverythingAI/blob/main/09%20Templates/Role%20Profile%20Template.md) · last verified 2026-08-12 · review by 2026-11-12.

> **Mission:**
> One-sentence outcome ownership.

## Title reality and aliases

## Responsibilities and recurring decisions

## Level ladder

## Boundaries with adjacent roles

## Prerequisites and entry routes

## Competency map

## Study sequence

## Tool stack — free first and paid context

## Quiz

> **Answer key:**

## Flashcards

Question:: Answer

## Interview preparation

## Suggested projects

### Beginner

### Intermediate

### Advanced

## Sources

Include official/primary sources and `Verified 2026-08-12`.
