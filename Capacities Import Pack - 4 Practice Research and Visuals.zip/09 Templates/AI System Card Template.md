---
title: AI System Card Template
type: Page
tags: ai-careers, template, documentation
source_path: '09 Templates/AI System Card Template.md'
source_type: template
scope: United States
last_verified: '2026-08-12'
review_by: '2026-11-12'
---

# AI System Card — {{system}}

> **Source record:** [Vault source](https://github.com/msinclair25/EverythingAI/blob/main/09%20Templates/AI%20System%20Card%20Template.md) · last verified 2026-08-12 · review by 2026-11-12.

## Purpose, owner, and status

- Business/public owner:
- Technical owner:
- Risk owner:
- Lifecycle status:
- Last review / next review:

## Intended users, affected groups, uses, and prohibited uses

## System boundary

- Models/services:
- Data and retrieval:
- Tools/actions:
- Human decisions:
- Vendors/infrastructure:

## Data and rights

Sources, provenance, personal/sensitive data, permissions, retention, deletion, licenses, limitations.

## Behavior and evaluation

Claims, populations, cases, metrics, slices, thresholds, results, uncertainty, known failures.

## Controls

Security, privacy, safety, fairness/civil rights, accessibility, human review/recourse, monitoring, incident, change, retirement.

## Operation

SLOs, fallback, support, cost, logging, alert owners, rollback/compensation.

## Limitations and residual risk acceptance

## Change history
