---
title: Project Brief Template
type: Page
tags: ai-careers, template, projects
source_path: '09 Templates/Project Brief Template.md'
source_type: template
scope: United States
last_verified: '2026-08-12'
review_by: '2026-11-12'
---

# {{project}}

> **Source record:** [Vault source](https://github.com/msinclair25/EverythingAI/blob/main/09%20Templates/Project%20Brief%20Template.md) · last verified 2026-08-12 · review by 2026-11-12.

## Decision and audience

- Target role:
- User/affected group:
- Decision this evidence supports:

## Problem and baseline

## Scope and non-goals

## Constraints

- Data rights/privacy:
- Security/safety:
- Accessibility:
- Cost/time:
- Tools:

## Options and choice

| Option | Evidence for | Evidence against | Decision |
|---|---|---|---|

## Architecture or workflow

```mermaid
flowchart LR
    A["Input"] --> B["Process"] --> C["Validation"] --> D["Outcome"]
```

## Evaluation plan

- System/version:
- Population/cases:
- Baseline:
- Metrics/rubric:
- Slices:
- Failure severity:
- Release/stop threshold:

## Results and error analysis

## Risks, controls, and residual limits

## Cost/operations/adoption

## Artifacts

- [ ] README/brief
- [ ] data/source record
- [ ] architecture/process map
- [ ] evaluation report
- [ ] decision log
- [ ] demo/sample

## Next decision
