---
title: Education AI
type: Page
tags: ai-careers, industry, education
source_path: '08 Industry Overlays/Education AI.md'
source_type: industry-overlay
scope: United States
level: intermediate, advanced
last_verified: '2026-08-12'
review_by: '2026-09-12'
---

# Education AI

> **Source record:** [Vault source](https://github.com/msinclair25/EverythingAI/blob/main/08%20Industry%20Overlays/Education%20AI.md) · last verified 2026-08-12 · review by 2026-09-12.

Add learning science, educator workflow, student age/development, accessibility, academic integrity, assessment validity, family/community communication, procurement, data governance, and FERPA/COPPA/state rules as applicable.

Distinguish tutoring, teacher support, administrative systems, admissions/enrollment, assessment/proctoring, research, and student surveillance. Measure learning and equitable access—not engagement or output volume alone. Preserve educator/student agency and alternative paths; test multilingual, disability, socioeconomic, and age-related impacts.

## Suggested projects

- Beginner: design a rubric evaluating whether an AI explanation promotes learning rather than answer copying.
- Intermediate: create an accessible classroom AI use policy with scenarios and source-update plan.
- Advanced: design a randomized or quasi-experimental evaluation of a tutoring feature, including contamination and teacher effects.

Start with [U.S. Department of Education AI resources](https://www.ed.gov/), [FERPA](https://studentprivacy.ed.gov/ferpa), [FTC COPPA](https://www.ftc.gov/legal-library/browse/rules/childrens-online-privacy-protection-rule-coppa), and current state/district policy.
