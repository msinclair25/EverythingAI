---
title: Legal and Professional Services AI
type: Page
tags: ai-careers, industry, legal, professional-services
source_path: '08 Industry Overlays/Legal and Professional Services AI.md'
source_type: industry-overlay
scope: United States
level: advanced
last_verified: '2026-08-12'
review_by: '2026-09-12'
---

# Legal and Professional Services AI

> **Source record:** [Vault source](https://github.com/msinclair25/EverythingAI/blob/main/08%20Industry%20Overlays/Legal%20and%20Professional%20Services%20AI.md) · last verified 2026-08-12 · review by 2026-09-12.

Add professional competence, confidentiality/privilege, conflicts, supervision, billing/representation accuracy, records, citation verification, client consent/communication, and jurisdiction-specific duties.

Legal research generation must verify every proposition and source in authoritative databases; fluent invented citations are a known severe failure. Contract review needs clause context, governing law, document version, materiality, and qualified review. Accounting, engineering, and other professional work has parallel domain standards and licensed responsibility.

## Suggested projects

- Beginner: create a citation-verification rubric using public court/government sources.
- Intermediate: design a contract-review evaluation set with ambiguity, exceptions, and escalation—using fictional documents.
- Advanced: build an assurance and supervision plan for a professional-services copilot.

Verify current state bar/professional guidance and court rules. Never present an educational project as professional advice.
