---
title: Interview and Portfolio Hub
type: Page
tags: ai-careers, interview, portfolio, hub
source_path: 07 Interview and Portfolio/Interview and Portfolio Hub.md
source_type: hub
scope: United States
level: beginner, intermediate, advanced
last_verified: '2026-08-12'
review_by: '2026-11-12'
---

# Interview and Portfolio Hub

> **Source record:** [Vault source](https://github.com/msinclair25/EverythingAI/blob/main/07%20Interview%20and%20Portfolio/Interview%20and%20Portfolio%20Hub.md) · last verified 2026-08-12 · review by 2026-11-12.

Your evidence should mirror the role's real decisions.

- [[Project Selection Guide]] — choose useful project evidence without following a lab.
- [[Project Bank]] — cross-role suggested projects by difficulty.
- [[AI Interview Playbook]] — answer architecture, product, evaluation, governance, creative, and operational questions.
- [[Behavioral Interview Bank]] — build decision-rich stories.
- [[Technical AI Interview Guide]] — coding, ML, systems, evaluation, security, and research.
- [[Technical Interview Drills]] — timed studio decisions with strong/weak answer shapes.
- [[Product and Business AI Interview Guide]] — product sense, strategy, adoption, solutions, economics.
- [[Governance and Responsible AI Interview Guide]] — risk, policy, controls, assurance, ethics.
- [[Creative UX and Human Operations Interview Guide]] — UX, conversation, media, annotation, knowledge, training.

Use [[Project Brief Template]], [[Evaluation Report Template]], [[AI System Card Template]], and [[Decision Record Template]] to structure artifacts.

```mermaid
flowchart LR
    J["Target role decisions"] --> P["Project evidence"] --> S["Story bank"] --> M["Mock questions"] --> G["Gap repair"] --> A["Applications + interviews"]
```
