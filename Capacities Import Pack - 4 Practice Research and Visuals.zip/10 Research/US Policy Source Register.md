---
title: US Policy Source Register
type: Research
tags: ai-careers, research, policy, law
source_path: 10 Research/US Policy Source Register.md
source_type: source-register
scope: United States
last_verified: '2026-08-12'
review_by: '2026-09-12'
---

# U.S. Policy Source Register

> **Source record:** [Vault source](https://github.com/msinclair25/EverythingAI/blob/main/10%20Research/US%20Policy%20Source%20Register.md) · last verified 2026-08-12 · review by 2026-09-12.

> **October 13, 2026 update:**
> See [[US Career and Governance Update — October 2026]] for a limited NIST/California refresh. This older federal register is overdue for a full legal review; its entire table was not reverified.

Use this as an update checklist, not a substitute for primary text or counsel.

## Current presidential AI landmarks

| Instrument | Date | Operational reading at the cutoff |
|---|---:|---|
| [EO 14179](https://www.whitehouse.gov/presidential-actions/2025/01/removing-barriers-to-american-leadership-in-artificial-intelligence/) | 2025-01-23 | directed development of the AI Action Plan and revoked EO 14110 |
| [EO 14365](https://www.whitehouse.gov/presidential-actions/2025/12/eliminating-state-law-obstruction-of-national-artificial-intelligence-policy/) | 2025-12-11 | directs executive actions regarding state AI laws and a federal legislative proposal; not itself the requested Act of Congress |
| [EO 14409](https://www.whitehouse.gov/presidential-actions/2026/06/promoting-advanced-artificial-intelligence-innovation-and-security/) | 2026-06-02 | directs federal AI/cybersecurity work and a voluntary covered-frontier-model framework; does not authorize mandatory model licensing/preclearance |
| [NSPM-11](https://www.whitehouse.gov/presidential-actions/2026/06/national-security-presidential-memorandum-nspm-11/) | 2026-06-05 | governs AI in the national-security enterprise and replaces NSM-25; not a general private-sector rule |

Always check amendments, implementation documents, litigation, and agency-specific scope rather than reading this table as a standalone legal conclusion.

| Source | Monitor for |
|---|---|
| [White House presidential actions](https://www.whitehouse.gov/presidential-actions/) | executive orders and memoranda |
| [OMB memoranda](https://www.whitehouse.gov/omb/information-resources/guidance/memoranda/) | federal agency AI use, acquisition, and cross-government policy |
| [NIST AI](https://www.nist.gov/artificial-intelligence) | frameworks, standards, evaluation, security, agent initiatives |
| [Federal Register](https://www.federalregister.gov/) | proposed/final rules, notices, requests for comment |
| [Congress.gov](https://www.congress.gov/) | bill status, enacted text, CRS reports |
| [GAO AI](https://www.gao.gov/artificial-intelligence) | oversight, accountability, federal implementation |
| [EEOC publications](https://www.eeoc.gov/eeoc-publications) | employment discrimination, disability, algorithmic systems |
| [FTC AI](https://www.ftc.gov/industry/technology/artificial-intelligence) | enforcement, policy, consumer/business claims |
| [Copyright Office AI](https://www.copyright.gov/ai/) | replicas, copyrightability, training policy |
| [NCSL AI database](https://www.ncsl.org/financial-services/artificial-intelligence-legislation-database) | state bill discovery; verify state primary text |
| Domain regulators | health, finance, education, transport, communications, labor, energy and sector-specific changes |

## Status language

- **Enacted/signed:** became law; still verify effective date and applicability.
- **Final rule:** verify effective/compliance dates and litigation/stays.
- **Proposed rule/draft:** not final.
- **Guidance:** may explain enforcement/expectations but differs from statute/regulation.
- **Executive order/OMB memo:** binds defined executive actors within authority; not automatically a private-sector statute.
- **Framework/standard:** voluntary unless adopted through law, contract, policy, or accreditation.
- **Bill/recommendation:** not law.
