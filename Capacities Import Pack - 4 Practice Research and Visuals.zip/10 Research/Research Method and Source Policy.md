---
title: Research Method and Source Policy
type: Research
tags: ai-careers, research, methodology
source_path: 10 Research/Research Method and Source Policy.md
source_type: research-method
scope: United States
last_verified: '2026-08-12'
review_by: '2026-11-12'
---

# Research Method and Source Policy

> **Source record:** [Vault source](https://github.com/msinclair25/EverythingAI/blob/main/10%20Research/Research%20Method%20and%20Source%20Policy.md) · last verified 2026-08-12 · review by 2026-11-12.

## Questions researched

1. Which functions constitute the U.S. AI labor ecosystem?
2. What does each role repeatedly own and produce?
3. Which concepts and tools transfer across employers?
4. Which claims are volatile and require dated primary evidence?
5. What must a learner know, recall, show, and explain?

## Source order

1. U.S. statutes/regulations and official agency policy/guidance.
2. NIST, BLS/O*NET, GAO, EEOC, Copyright Office, White House/OMB, and domain regulators.
3. Official tool documentation, security, privacy, pricing, and licensing pages.
4. Original technical papers and maintained official project documentation.
5. Stanford AI Index and other transparent, data-driven synthesis.
6. Employer postings and job boards for title discovery only; employer-specific scope is not generalized from one listing.

## Claim rules

- Date time-sensitive claims and link the page that supports them.
- Label proposed/draft guidance and legislative recommendations; do not call them law.
- Distinguish an official plan or announcement from an implemented standard/product.
- Avoid exact product prices in teaching notes unless necessary; pricing pages change.
- Do not infer job counts or salaries for novel titles from an adjacent BLS occupation.
- Explain uncertainty and title ambiguity.
- Prefer functional competencies over vendor menu memorization.

## Role taxonomy method

Roles were grouped by the outcome owned across the AI lifecycle: research; model/application engineering; data/knowledge; platform/performance; evaluation/security/safety; product/transformation/executive direction; sales/marketing/partnerships/customer/support/education; UX/content; creative media; governance/policy; human data/talent. A role receives its own profile when its recurring decisions, artifacts, prerequisites, or interview evidence are materially distinct. Industry variants are overlays.

## Verification schedule

| Claim type | Default review |
|---|---|
| Law, executive policy, agency guidance, product terms/pricing | monthly–quarterly |
| Tool category and model/provider capability | quarterly |
| Labor-market synthesis and title map | quarterly–semiannual |
| Stable technical foundations | semiannual–annual |
| Every linked source | at note review and before consequential use |

## Update workflow

Use [[Capacities Source Review]] to find due notes. Open the primary source, check update/publication/effective dates and substantive change, revise claims and metadata, then log material changes in [[Vault Changelog]].

## Limits

See [[Coverage, Evidence, and Limits]]. The vault is a researched educational map—not an accreditation, exhaustive census, or substitute for professional advice.
