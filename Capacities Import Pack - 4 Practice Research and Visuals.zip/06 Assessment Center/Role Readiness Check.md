---
title: Role Readiness Check
type: Page
tags: ai-careers, assessment, role-readiness
source_path: 06 Assessment Center/Role Readiness Check.md
source_type: assessment
scope: United States
level: intermediate, advanced
last_verified: '2026-08-12'
review_by: '2026-11-12'
---

# Role Readiness Check

> **Source record:** [Vault source](https://github.com/msinclair25/EverythingAI/blob/main/06%20Assessment%20Center/Role%20Readiness%20Check.md) · last verified 2026-08-12 · review by 2026-11-12.

Pick one role profile. For each item mark **new**, **with support**, or **independent** and attach evidence or an explanation.

## Mission and boundaries

- I can explain the role's outcome in one sentence.
- I can distinguish it from three adjacent roles using ownership and artifacts.
- I can map three current postings to the profile despite title differences.
- I know what this role escalates rather than owns.

## Decisions and skills

- I can describe the recurring work at entry, mid, senior, and lead levels.
- I can make and defend the role's five most common decisions.
- I can explain the underlying AI concepts at the depth the role requires.
- I can recognize poor evidence, unsafe assumptions, and failure modes.
- I can communicate the decision to technical and nontechnical audiences.

## Tools

- I can choose a free-first tool path by task.
- I can explain when a paid/enterprise tool changes security, scale, support, or integration.
- I can transfer the workflow to a second tool rather than depend on one interface.
- I verify current terms, pricing, data use, and capability from official sources.

## Evidence

- I have one small project showing fundamentals and one substantial project showing tradeoffs.
- Each project records problem, baseline, architecture/process, evaluation, failure analysis, risks, and next decision.
- I can demonstrate or explain the work without hiding manual edits or failed attempts.
- I do not expose confidential, personal, or unlicensed data.

## Interview

- I can answer the role profile's knowledge questions concisely.
- I can solve an unfamiliar scenario by clarifying goals and risks before choosing tools.
- I have six STAR stories with concrete decisions and evidence.
- I can discuss one failure, disagreement, ethical escalation, and tradeoff.
- I have questions that test the employer's actual role scope, data, evaluation, ownership, and support.

> **Ready to apply:**
> Apply before every item is “independent.” A reasonable signal is independence on mission/boundaries and core decisions, credible evidence on at least two projects or equivalent prior work, and no critical safety/ethics blind spot. Use interviews and postings as additional data, then close gaps deliberately.
