---
title: Quiz Index
type: Page
tags: ai-careers, quiz, index
source_path: 06 Assessment Center/Quiz Index.md
source_type: index
scope: United States
level: beginner, intermediate, advanced
last_verified: '2026-08-24'
review_by: '2026-11-24'
---

# Quiz Index

> **Source record:** [Vault source](https://github.com/msinclair25/EverythingAI/blob/main/06%20Assessment%20Center/Quiz%20Index.md) · last verified 2026-08-24 · review by 2026-11-24.

## Whole-curriculum checks

- [[Foundations Pretest]]
- [[Foundations Final Check]]
- [[Technical Cumulative Check]]

## Module quizzes

Each note in [[Foundations Hub]] and [[Core Skills Hub]] contains a quiz immediately before a collapsed answer callout. Each [[Technical Studio]] case includes a decision quiz.

### Delivery and operations quiz

- [[AI DevOps and Cloud Engineering — 2026-08-24]] (Quiz) — AI for DevOps and DevOps for AI; cloud, CI/CD, identity, evaluation, Kubernetes, observability, supply chain, and FinOps.

## Role quizzes

Every role profile in [[AI Career Atlas]] includes role decisions, tool choices, boundaries, and scenario questions with answers.

```query
path:"04 Role Tracks" (line:"## Quiz" OR line:"## Knowledge check")
```

## Review method

For each miss record: concept, your wrong assumption, correct rule, one new example, and a case where the rule would not apply. Re-take with reordered or self-created examples.
